* `Abita4Rhino.zip`: **Abita for Rhino** and Grashopper. To use it, extract the archive and execute `install.bat`.
* `AbitaPy.zip`: contains the source code of **AbitaPy** and the auto-generated source-code in Python2 for AbitaPy2.
* `Source code`: contains the source code of the full repository.
