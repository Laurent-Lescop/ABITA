#include "precompiled.h"
#include "Application.h"
#include "textes.h"

IMPLEMENT_APP(Application)

//----------------------------------------------------------------------------

bool Application::OnInit()
{
  wxToolTip::SetDelay(0);
  
	SetVendorName(RS_APP_VENDORNAME);
	SetAppName(RS_APP_NAME);
	SetClassName(RS_APP_CLASSNAME);

#if wxUSE_IMAGE
  wxImage::AddHandler( new wxBMPHandler );
#endif

#if wxUSE_LIBPNG
  wxImage::AddHandler( new wxPNGHandler );
#endif

#if wxUSE_LIBJPEG
  wxImage::AddHandler( new wxJPEGHandler );
#endif

#if wxUSE_LIBTIFF
  wxImage::AddHandler( new wxTIFFHandler );
#endif

#if wxUSE_GIF
  wxImage::AddHandler( new wxGIFHandler );
#endif

#if wxUSE_PCX
  wxImage::AddHandler( new wxPCXHandler );
#endif

#if wxUSE_PNM
  wxImage::AddHandler( new wxPNMHandler );
#endif

#if wxUSE_XPM
  wxImage::AddHandler( new wxXPMHandler );
#endif
 
  m_gridSize = 1.0f;
  m_gridState = false;

  m_a1 = -1;
  m_a2 = -1;
  m_a3 = 100;
  m_a4 = 0.f;

  m_mesureToolEnable = false;
  m_mesureToolvalues.resize(2);

  // create the main application window
  m_frame = new FrameMain(RS_APP_NAME,wxDefaultPosition,wxDefaultSize);

  m_frame->SetTitle(RS_APP_TITLE);

  m_frame->Show();

  return true;
}

//----------------------------------------------------------------------------
