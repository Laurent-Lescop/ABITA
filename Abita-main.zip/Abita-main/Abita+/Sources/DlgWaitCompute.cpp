#include "precompiled.h"
#include "DlgWaitCompute.h"

#include <limits>

#include "InterfaceSolveur.h"
#include "MeshConnected_algorithms.h"
#include "Solveur/Lot.h"
#include "wxUtilities.h"

const wxColour colourT1 = wxColour(255,255,128);
const wxColour colourT2 = wxColour(255,192,128);
const wxColour colourT3 = wxColour(192,128,128);
const wxColour colourT4 = wxColour(192,128,192);
const wxColour colourT5 = wxColour(128,128,255);

//----------------------------------------------------------------------------

BEGIN_EVENT_TABLE(CanvasVisualisationWait, wxScrolledWindow)

EVT_PAINT(        CanvasVisualisationWait::OnPaint)
EVT_SIZE(         CanvasVisualisationWait::OnSize)

END_EVENT_TABLE()

//----------------------------------------------------------------------------

CanvasVisualisationWait::CanvasVisualisationWait( wxWindow *parent, wxWindowID id, const wxPoint &pos, const wxSize &size )
: wxScrolledWindow( parent, id, pos, size,  wxSUNKEN_BORDER /*| wxTAB_TRAVERSAL*/, _T("") )
{
  SetScrollRate( 5, 5 );
  SetBackgroundColour( *wxWHITE );
}

//----------------------------------------------------------------------------

CanvasVisualisationWait::~CanvasVisualisationWait()
{
}

//----------------------------------------------------------------------------

void CanvasVisualisationWait::setSolution(std::auto_ptr<Solution> solution)
{
  m_solution = solution;
  setSize();
  Refresh(false);
}

//----------------------------------------------------------------------------

void CanvasVisualisationWait::setSize()
{
  float xmin = std::numeric_limits<float>::max(), xmax = -std::numeric_limits<float>::max();
  float ymin = std::numeric_limits<float>::max(), ymax = -std::numeric_limits<float>::max();

  if (m_solution.get() != NULL)
  {
    unsigned const numLots = m_solution->numLots();
    for (unsigned lotID=0; lotID<numLots; lotID++)
    {
      Solution::Lot const& lot = m_solution->getLot(lotID);
      MeshConnected const& shape = lot.getShape();
      MeshConnected::vertex_const_iterator vit = shape.vertices_begin();
      MeshConnected::vertex_const_iterator vend = shape.vertices_end();
      while (vit != vend)
      {
        MeshConnected::VertexData const* vdata = shape.getVertexData(*vit);

        xmin = std::min(xmin, vdata->position.x);
        xmax = std::max(xmax, vdata->position.x);
        ymin = std::min(ymin, vdata->position.y);
        ymax = std::max(ymax, vdata->position.y);

        ++vit;
      }
    }
  }

  float dx = (xmax - xmin);
  float dy = (ymax - ymin);

  float const VIEW_MARGIN = 0.05f;
  float viewSize = std::max(dx, dy) * (1.f + VIEW_MARGIN);

  float xcenter = (xmax + xmin) * 0.5f;
  float ycenter = (ymax + ymin) * 0.5f;

  m_minX = xcenter - viewSize*0.5f;
  m_maxX = xcenter + viewSize*0.5f;
  m_minY = ycenter - viewSize*0.5f;
  m_maxY = ycenter + viewSize*0.5f;
}

//----------------------------------------------------------------------------

void CanvasVisualisationWait::OnSize(wxSizeEvent& event)
{
  wxScrolledWindow::OnSize(event);

  wxSize const& size = event.GetSize();

  if (size.y >= size.x)
  {
    unsigned baseSize = size.y-16;
    unsigned otherSize = int( float(baseSize) * theDocument->getSizeX() / theDocument->getSizeY() )+1;
    SetVirtualSize( otherSize, baseSize );
  }
  else
  {
    unsigned baseSize = size.x-16;
    unsigned otherSize = int( float(baseSize) * theDocument->getSizeY() / theDocument->getSizeX() )+1;
    SetVirtualSize( baseSize, otherSize );
  }

  event.Skip();
}

//----------------------------------------------------------------------------

wxPoint CanvasVisualisationWait::convert(wxSize const& clientSize, Point2d const& position) const
{
  int x = ((position.x - m_minX) / (m_maxX - m_minX)) * float(clientSize.x);
  int y = ((position.y - m_minY) / (m_maxY - m_minY)) * float(clientSize.y);
  return wxPoint(x, y);
}

//----------------------------------------------------------------------------

void CanvasVisualisationWait::PrepareDC(wxDC& dc)
{
  wxScrolledWindow::PrepareDC( dc );

  wxSize const size = GetVirtualSize();

  double scaleX = 1.0 / (double(theDocument->getSizeX() * Document::POINT_PRECISION) / double(size.GetWidth()));
  double scaleY = 1.0 / (double(theDocument->getSizeY() * Document::POINT_PRECISION) / double(size.GetHeight()));
  dc.SetUserScale( scaleX, scaleY );  
}

//----------------------------------------------------------------------------

void CanvasVisualisationWait::OnPaint( wxPaintEvent &event )
{
  wxPaintDC dc( this );
  PrepareDC(dc);

  wxSize const clientSize = GetClientSize();

  if (m_solution.get() != NULL)
  {
    unsigned const numLots = m_solution->numLots();
    for (unsigned lotID=0; lotID<numLots; lotID++)
    {
      Solution::Lot const& lot = m_solution->getLot(lotID);
      MeshConnected const& shape = lot.getShape();

      //- draw lot background

      dc.SetPen( *wxTRANSPARENT_PEN );
      {
        MeshConnected::polygon_const_iterator pit = shape.polygons_begin();
        MeshConnected::polygon_const_iterator pend = shape.polygons_end();
        while (pit != pend)
        {
          if (lotID == 0)
          {
            drawPolygon(dc, shape, *pit, P_DONT_CARE);
          }
          else
          {
            _ASSERT( lot.getType() != Solution::Lot::COMMON );
            static wxColour const colors[] = {  colourT1,
              colourT2,
              colourT3,
              colourT4,
              colourT5 };

            unsigned colorIndex = lot.getType() - Solution::Lot::T1;
            dc.SetBrush( wxBrush( colors[colorIndex], wxSOLID ) );
            drawPolygon(dc, shape, *pit, P_USER_COLOR);
          }
          ++pit;
        }
      }

      //- draw lot contour

      dc.SetPen( *wxBLACK_PEN );
      {
        MeshConnected::edge_const_iterator eit = shape.edges_begin();
        MeshConnected::edge_const_iterator eend = shape.edges_end();
        while (eit != eend)
        {
          MeshConnected::EdgeHandle eh = *eit;
          std::vector<MeshConnected::PolygonHandle> polygons;
          shape.findAdjacentPolygons(eh, polygons);
          if (polygons.size() < 2)
          {
            drawEdge(dc, shape, eh, E_DONT_CARE);
          }
          ++eit;
        }
      }
    }
  }
}


/***** Immlementation for class DlgWaitCompute *****/

BEGIN_EVENT_TABLE(DlgWaitCompute, wxFrame)
EVT_MENU( ID_COMPUTE_QUIT,  DlgWaitCompute::OnQuit  )
END_EVENT_TABLE()


DlgWaitCompute::DlgWaitCompute( wxWindow* parent, wxString title )  : wxFrame( parent, -1, title, wxDefaultPosition, wxSize( 400, 400 ), wxTHICK_FRAME |  wxCAPTION)
{ 	
  SetBackgroundColour(*wxWHITE);
  wxBoxSizer *item0 = new wxBoxSizer( wxVERTICAL );

  wsb = new  wxStaticBitmap(this, -1, wxBITMAP(logo_abita), wxDefaultPosition, wxDefaultSize);        
  item0->Add( wsb, 0, wxALIGN_CENTRE|wxALL, 5 );

  wxStaticText *wst0 = new wxStaticText( this, -1, RS_DIALOG_WAIT_SOLUTION_TEXT1, wxDefaultPosition, wxDefaultSize, 0 );
  item0->Add( wst0, 0, wxALIGN_CENTRE|wxALL, 5 );

  visu = new CanvasVisualisationWait(this, -1, wxDefaultPosition, wxSize(256,256));
  item0->Add( visu, 0, wxALIGN_CENTRE|wxALL, 5 );

  wst = new wxStaticText( this, -1, wxT("Nothing"), wxDefaultPosition, wxSize(200,-1), 0 );
  item0->Add( wst, 0, wxALIGN_CENTRE|wxALL, 5 );

  this->SetAutoLayout( TRUE );
  this->SetSizer( item0 );

  item0->Fit( this );
  item0->SetSizeHints( this );

  m_iteration = 0;
}

DlgWaitCompute::~DlgWaitCompute()
{

}


// -------------------------------------------------------------------------------------------

void DlgWaitCompute::DrawSomething(CPopulation &population)
{
  m_iteration++;
  wst->SetLabel(RS_DIALOG_WAIT_SOLUTION_TEXT2 + wxString::Format("%d",m_iteration));

  if ((m_iteration%10) == 0)
  {
    std::auto_ptr<Solution> solution;
    if (population.NbSolutions > 0)
    {
      int solutionID = (rand() * (population.NbSolutions-1)) / RAND_MAX;
      solution = convert( *theDocument, *population.SolutionList[solutionID], 0) ;
    }
    visu->setSolution( solution );
  }
}


void DlgWaitCompute::OnQuit( wxCommandEvent& event )
{
  Show( FALSE ); // TRICK:: hide it, to avoid flickered destruction
  Close(TRUE);
}
