#include "precompiled.h"
#include "CanvasDraw.h"

#include "Application.h"
#include "textes.h"

#include "EditContext.h"
#include "MeshConnected.h"
#include "ModeCreatePolygon.h"
#include "ModeCutShape.h"
#include "ModeMoveVertex.h"
#include "Point2d.h"
#include "wxUtilities.h"

namespace {

  const unsigned ZOOM_PRECISION_EPSILON = 16;

}

//----------------------------------------------------------------------------

IMPLEMENT_DYNAMIC_CLASS(CanvasDraw, wxScrolledWindow)

//----------------------------------------------------------------------------

BEGIN_EVENT_TABLE(CanvasDraw, wxScrolledWindow)

EVT_PAINT(        CanvasDraw::OnPaint)
EVT_SIZE(         CanvasDraw::OnSize)
EVT_MOUSE_EVENTS( CanvasDraw::OnMouseEvent)
EVT_KEY_DOWN(     CanvasDraw::OnKeyDown)
EVT_KEY_UP(       CanvasDraw::OnKeyUp)
EVT_SET_FOCUS(    CanvasDraw::OnSetFocus)
EVT_KILL_FOCUS(   CanvasDraw::OnKillFocus)
EVT_SCROLLWIN(    CanvasDraw::OnScrollWin)
EVT_ACTIVATE_APP( CanvasDraw::OnActivate) 
EVT_ERASE_BACKGROUND( CanvasDraw::OnEraseBackground)

END_EVENT_TABLE()

namespace
{
  wxSize computeVirtualSize()
  {
    Document const& doc = *theDocument;
    return wxSize( doc.getSizeX() * doc.getPixelsPerMeter(), 
                   doc.getSizeY() * doc.getPixelsPerMeter() );
  }
};

//----------------------------------------------------------------------------

CanvasDraw::CanvasDraw( wxWindow *parent, wxWindowID id, const wxPoint &pos, const wxSize &size )
                       : wxScrolledWindow( parent, id, pos, size, wxSUNKEN_BORDER | wxTAB_TRAVERSAL, _T("test canvas") )
{
  SetScrollRate( 10, 10 );
  SetVirtualSize( computeVirtualSize() );

  m_bkgrd_change = true;

  wxSize const clientSize = GetClientSize();
  m_backBufferBitmap = wxBitmap( clientSize.x, clientSize.y );
}

CanvasDraw::~CanvasDraw()
{
}

//----------------------------------------------------------------------------

void drawDocument( wxDC& dc )
{
  Document const& doc = *theDocument;
  MeshConnected const& shape = doc.getShape();

  redrawPolygons(dc, shape, P_DONT_CARE);
  redrawEdges(dc, shape, E_DONT_CARE);
  redrawVertexHandles(dc, VH_DONT_CARE);
}

void drawMesure(wxDC& dc)
{
  if(wxGetApp().isMesureToolEnable())
  {

    //std::auto_ptr<EditSegmentDrawer>  editSegmentDrawer;
    //editSegmentDrawer.reset( new EditSegmentDrawer(owner, wxGetApp().getMesureToolValues()[0], wxGetApp().getMesureToolValues()[1], true) );
    dc.SetPen( wxNullPen );

    unsigned function = dc.GetLogicalFunction();
    dc.SetLogicalFunction(wxINVERT);
    wxPoint a = wxGetApp().getMesureToolValues()[0];
    wxPoint b = wxGetApp().getMesureToolValues()[1];

    Document const& doc = *theDocument;
    unsigned sizecroix = dc.DeviceToLogicalXRel(8);

    dc.DrawLine(wxPoint(a.x-sizecroix,a.y+sizecroix),wxPoint(a.x+sizecroix,a.y-sizecroix));
    dc.DrawLine(wxPoint(a.x+sizecroix,a.y+sizecroix),wxPoint(a.x-sizecroix,a.y-sizecroix));
    dc.DrawLine(wxPoint(b.x-sizecroix,b.y+sizecroix),wxPoint(b.x+sizecroix,b.y-sizecroix));
    dc.DrawLine(wxPoint(b.x+sizecroix,b.y+sizecroix),wxPoint(b.x-sizecroix,b.y-sizecroix));
    dc.DrawLine( a, b );
    dc.SetLogicalFunction(function);

  }
}

//----------------------------------------------------------------------------


void CanvasDraw::OnEraseBackground( wxEraseEvent& event )
{
}

void CanvasDraw::OnMouseEvent( wxMouseEvent& event )
{
  Document& doc = *theDocument;

  wxPoint const pt( event.GetPosition() );
  wxPoint absPt = pt;
  //CalcUnscrolledPosition( pt.x, pt.y, &absPt.x, &absPt.y );

  unsigned sensitivity;
  {
    DCmanager& manager = getDC();
    wxDC& dc = manager.getDC();

    absPt.x = dc.DeviceToLogicalX(absPt.x);
    absPt.y = dc.DeviceToLogicalY(absPt.y);

    sensitivity = computeSensitivity( dc );
  }

  ////-

  //wxSize scrollSize;
  //scrollSize.SetWidth( doc.getSizeX() * doc.getPixelsPerMeter() );
  //scrollSize.SetHeight( doc.getSizeX() * doc.getPixelsPerMeter() );

  //wxPoint editCanvasStartPoint;
  //wxSize const clientSize = GetClientSize();
  //{
  //  editCanvasStartPoint.x = std::max( clientSize.GetWidth() - scrollSize.GetWidth(), 0 ) / 2;
  //  editCanvasStartPoint.y = std::max( clientSize.GetHeight() - scrollSize.GetHeight(), 0) / 2;
  //}

  //-

  m_currentMousePosition = absPt;

  //- find the nearby elements

  theEditContext.populate( m_currentMousePosition, sensitivity );

  //- dispatch event to current mode

  Point2d point = doc.convert( absPt );
  
  if (point.x >= 0 && point.x <= doc.getSizeX() && point.y >= 0 && point.y <= doc.getSizeY())
  {
    if (m_currentMode.get() != NULL)
    {
      wxMouseEvent absEvent( event );
      absEvent.m_x = absPt.x;
      absEvent.m_y = absPt.y;
      m_currentMode->OnEvent( absEvent );
    }
  }
  else
  {
    SetCursor( wxNullCursor );
  }

  int wheelMovement = event.GetWheelRotation();
  if (wheelMovement != 0)
  {
    m_bkgrd_change = true;

    Point2d pointedLocation = doc.convert( absPt );

    float zoom = 1.f + ( float(wheelMovement) / float(event.GetWheelDelta()) ) / 10.f;
    if (zoom < 0.5f) zoom = 0.5f;
    if (zoom > 1.5f) zoom = 1.5f;
    float newPPM = doc.getPixelsPerMeter() * zoom;
    doc.setPixelsPerMeter( newPPM );

    //- zoom so that the mouse cursor doesn't logically move
    {
      SetVirtualSize( computeVirtualSize() );

      wxPoint viewStart;
      GetViewStart( &viewStart.x, &viewStart.y );

      wxSize scrollUnits;
      GetScrollPixelsPerUnit( &scrollUnits.x, &scrollUnits.y );

      viewStart.x *= scrollUnits.x;
      viewStart.y *= scrollUnits.y;

      Point2d topLeftPointed = doc.convert( viewStart );
      
      wxPoint newAbsPt;
      CalcUnscrolledPosition( pt.x, pt.y, &newAbsPt.x, &newAbsPt.y );
      Point2d newPointedLocation = doc.convert( absPt );

      Point2d delta = pointedLocation - newPointedLocation;
      wxPoint wxDelta = doc.convert(delta);

      wxPoint newTopLeft;
      newTopLeft.x = absPt.x - pt.x;
      newTopLeft.y = absPt.y - pt.y;
      newTopLeft.x = int( float(viewStart.x) * zoom );
      newTopLeft.y = int( float(viewStart.y) * zoom );
      newTopLeft.x = viewStart.x + wxDelta.x;
      newTopLeft.y = viewStart.y + wxDelta.y;

      if (scrollUnits.x > 0) newTopLeft.x /= scrollUnits.x;
      if (scrollUnits.y > 0) newTopLeft.y /= scrollUnits.y;

      Scroll( newTopLeft.x, newTopLeft.y );
    }

    Refresh();
  }
  else
  {
    event.Skip();
  }
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

void CanvasDraw::OnPaint( wxPaintEvent &WXUNUSED(event) )
{
  wxPaintDC paintDC(this);    //!< must be contructed or the app will always repaint
  PrepareDC( paintDC );

  Document & doc = *theDocument;

  //-

  wxSize const& scrollSize = computeVirtualSize();
  SetVirtualSize( scrollSize );

  //-

  if(m_bkgrd_change)
  {
    m_bkgrd_change = false;
    m_backDropImage = wxGetApp().m_frame->m_img_fond_ecran;
  }

  {
    wxMemoryDC mdc;
    mdc.SelectObject(m_backBufferBitmap);

    mdc.SetBackground( wxBrush(GetBackgroundColour(), wxSOLID) );
    mdc.Clear();

    if (m_backDropImage.Ok())
    {
      paintBackdropImage( mdc );
    }

    PrepareBackBufferDC( mdc ); 

    if (!m_backDropImage.Ok())
    {
      mdc.SetPen( *wxTRANSPARENT_PEN );
      mdc.SetBrush( *wxWHITE_BRUSH );
      wxPoint workspaceSize = doc.convert( Point2d(doc.getSizeX(), doc.getSizeY()) );
      mdc.DrawRectangle( 0, 0, workspaceSize.x, workspaceSize.y );
    }

    drawDocument( mdc );

    // draw the Mesure tool

    drawMesure(mdc);

    //- dispatch to the current mode
    if (m_currentMode.get() != NULL)
    {
      m_currentMode->OnPaint( mdc );
    }
  }

  //- Draw echelle

  drawEchelle();

  {
    //- just to blit !
    DCmanager& manager = getDC();
    wxDC& dc = manager.getDC();
    manager.paint();
  }
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

void CanvasDraw::OnKeyDown( wxKeyEvent& event )
{
  if (m_currentMode.get() != NULL)
  {
    m_currentMode->OnKeyDown( event );
  }
  event.Skip();
}

//----------------------------------------------------------------------------

void CanvasDraw::OnKeyUp( wxKeyEvent& event )
{
  if (m_currentMode.get() != NULL)
  {
    m_currentMode->OnKeyUp( event );
  }
  event.Skip();
}

//----------------------------------------------------------------------------

void CanvasDraw::OnSetFocus(wxFocusEvent& event)
{
  if (m_currentMode.get() != NULL)
  {
    m_currentMode->OnSetFocus( event );
  }
  event.Skip();
}

void CanvasDraw::OnKillFocus(wxFocusEvent& event)
{
  if (m_currentMode.get() != NULL)
  {
    m_currentMode->OnKillFocus( event );
  }
  event.Skip();
};

void CanvasDraw::OnScrollWin(wxScrollWinEvent& event)
{
  if (m_currentMode.get() != NULL)
  {
    m_currentMode->OnScrollWin(event);
  }
  Refresh( false );
  event.Skip();
}

void CanvasDraw::OnActivate(wxActivateEvent& event)
{
  if (m_currentMode.get() != NULL)
  {
    wxFocusEvent focusEvent;
    m_currentMode->OnKillFocus( focusEvent );
  }
  event.Skip();
}

void CanvasDraw::Refresh(bool eraseBackground /*= TRUE*/, const wxRect* rect /*= NULL*/)
{
  wxScrolledWindow::Refresh(false/*eraseBackground*/, rect);
} 

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

void CanvasDraw::drawEchelle()
{
  wxMemoryDC dc;
  dc.SelectObject( m_backBufferBitmap );

  Document const& doc = *theDocument;

  const unsigned n_metres = 5;
  const unsigned epaisseur_bord = 10;
  const unsigned epaisseur = 5; 

  int sx,sy;
  sx = 16;
  sy = 16;
  unsigned m = doc.getPixelsPerMeter();

  int oldLogicalFunc = dc.GetLogicalFunction();
  dc.SetLogicalFunction( wxXOR );

  dc.SetPen( *wxWHITE_PEN );
  dc.SetBrush( *wxWHITE_BRUSH );
  dc.DrawLine(sx, sy, sx + m*n_metres, sy);
  dc.DrawLine(sx, sy, sx, sy+epaisseur_bord);dc.DrawLine(sx+1, sy, sx+1, sy+epaisseur_bord);
  dc.DrawLine(sx+ m *n_metres, sy, sx+ m*n_metres, sy+epaisseur_bord);dc.DrawLine(sx+1+ m*n_metres, sy, sx+1+ m*n_metres, sy+epaisseur_bord);
  for(unsigned t=1;t<n_metres;t++)
    dc.DrawLine(sx+ m*t, sy, sx + m*t, sy+epaisseur);
  dc.DrawText(wxString::Format(RS_CANVAS_ECHELLE,n_metres), sx, sy+10);

  dc.SetLogicalFunction( wxCOPY );
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

void CanvasDraw::paintBackdropImage(wxDC& dc)
{
  int viewX, viewY;
  GetViewStart(&viewX, &viewY);
  {
    int xUnit, yUnit;
    GetScrollPixelsPerUnit(&xUnit,&yUnit);
    viewX *= xUnit;
    viewY *= yUnit;
  }

  unsigned const bitmapW = m_backDropImage.GetWidth();
  unsigned const bitmapH = m_backDropImage.GetHeight();

  wxSize const& virtualSize = computeVirtualSize();
  wxSize const& scrollSize = GetVirtualSize();
  wxSize const& clientSize = GetClientSize();

  //dc.SetUserScale( double(virtualSize.x) / double(bitmapW), double(virtualSize.y) / double(bitmapH));

  //bool changeDeviceOrigin = false;

  wxPoint editCanvasStartPoint;
  editCanvasStartPoint.x = std::max( clientSize.GetWidth()  - virtualSize.GetWidth(),  0) / 2;
  editCanvasStartPoint.y = std::max( clientSize.GetHeight() - virtualSize.GetHeight(), 0) / 2;

  ////dc.SetLogicalOrigin( editCanvasStartPoint.x, editCanvasStartPoint.y );
  //if (virtualSize.x < scrollSize.x)
  //{
  //  changeDeviceOrigin = true;
  //}
  //else
  //{
  //  editCanvasStartPoint.x = -viewX;
  //}

  //if (virtualSize.y < scrollSize.y)
  //{
  //  changeDeviceOrigin = true;
  //}
  //else
  //{
  //  editCanvasStartPoint.y = -viewY;
  //}

  ////if (changeDeviceOrigin)
  //dc.SetDeviceOrigin( editCanvasStartPoint.x, editCanvasStartPoint.y );

  //dc.SetLogicalFunction( wxCOPY );

  ////----

  wxSize backDropSize;
  backDropSize.x = std::min(clientSize.x, virtualSize.x);
  backDropSize.y = std::min(clientSize.y, virtualSize.y);

  unsigned zoomSizeX = virtualSize.x;
  unsigned zoomSizeY = virtualSize.y;

  if (clientSize.x < virtualSize.x)
  {
    if (viewX + clientSize.x > (virtualSize.x - ZOOM_PRECISION_EPSILON))
      backDropSize.x = (virtualSize.x - ZOOM_PRECISION_EPSILON)-viewX+1;
    zoomSizeX -= ZOOM_PRECISION_EPSILON;
  }
  if (clientSize.y < virtualSize.y)
  {
    if (viewY + clientSize.y > (virtualSize.y - ZOOM_PRECISION_EPSILON))
      backDropSize.y = (virtualSize.y - ZOOM_PRECISION_EPSILON)-viewY+1;
    zoomSizeY -= ZOOM_PRECISION_EPSILON;
  }

  wxImage image( backDropSize.x, backDropSize.y );
  {
    unsigned char* dstBuffer = image.GetData();
    unsigned char const* srcBuffer = m_backDropImage.GetData();
    unsigned srcStride = bitmapW * 3;

    if (clientSize.x != 0 && clientSize.y != 0)
    {
      unsigned const PRECISION = 16384;

      unsigned startY = unsigned(((float(viewY) * float(PRECISION)) / float(zoomSizeY)) * float(bitmapH));
      unsigned deltaY = (bitmapH * PRECISION) / (zoomSizeY);

      unsigned sizeY = backDropSize.y;
      while (sizeY-- != 0)
      {
        unsigned srcY = startY / PRECISION;
        unsigned char const* srcScanline = srcBuffer + (srcY * srcStride);

        unsigned startX = unsigned(((float(viewX) * float(PRECISION)) / float(zoomSizeX)) * float(bitmapW));
        unsigned deltaX = (bitmapW * PRECISION) / (zoomSizeX);

        unsigned sizeX = backDropSize.x;
        while (sizeX-- != 0)
        {
          unsigned x = (startX / PRECISION) * 3;
          *dstBuffer++ = srcScanline[x+0];
          *dstBuffer++ = srcScanline[x+1];
          *dstBuffer++ = srcScanline[x+2];
          startX += deltaX;
        }

        startY += deltaY;
      }
    }
  }
  wxBitmap dstbitmap = image.ConvertToBitmap();
  dc.DrawBitmap(dstbitmap, editCanvasStartPoint.x, editCanvasStartPoint.y);
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

void CanvasDraw::OnSize(wxSizeEvent& event)
{
  wxScrolledWindow::OnSize(event);

  wxSize const clientSize = GetClientSize();
  m_backBufferBitmap = wxBitmap( clientSize.x, clientSize.y );

  Refresh();

  //m_backBufferDC.SelectObject( m_backBufferBitmap );
  //m_backBufferDC.SetMapMode(wxMM_TEXT);
  //m_backBufferDC.SetUserScale( 1, 1 );

  //m_backBufferDC.SetBrush( *wxBLUE_BRUSH );
  //m_backBufferDC.DrawRectangle( wxPoint(0, 0), event.GetSize() );

  //double scaleX, scaleY;
  //scaleX = double(event.GetSize().x) / (theDocument->getSizeX() * 1000.0);
  //scaleY = double(event.GetSize().y) / (theDocument->getSizeY() * 1000.0);
  //m_backBufferDC.SetUserScale( scaleX, scaleY );

  //m_backBufferDC.SetPen( *wxBLACK_PEN );
  //m_backBufferDC.DrawLine( 0, 0, (theDocument->getSizeX() * 1000.0), (theDocument->getSizeY() * 1000.0) );

  //m_backBufferDC.SelectObject( wxNullBitmap );

  event.Skip();
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

void CanvasDraw::PrepareBackBufferDC(wxMemoryDC& mdc)
{
  int viewX, viewY;
  GetViewStart(&viewX, &viewY);
  {
    int xUnit, yUnit;
    GetScrollPixelsPerUnit(&xUnit,&yUnit);
    viewX *= xUnit;
    viewY *= yUnit;
  }

  mdc.SelectObject( m_backBufferBitmap );
  mdc.SetMapMode( wxMM_TEXT );

  wxSize const clientSize = GetClientSize();

  //double scaleX, scaleY;
  //scaleX = double(clientSize.x) / (theDocument->getSizeX() * 1000.0);
  //scaleY = double(clientSize.y) / (theDocument->getSizeY() * 1000.0);
  //mdc.SetUserScale( scaleX, scaleY );

  wxSize const& virtualSize = computeVirtualSize();
  wxSize const& scrollSize  = GetVirtualSize();

  bool changeDeviceOrigin = false;

  wxPoint editCanvasStartPoint;
  editCanvasStartPoint.x = std::max( clientSize.GetWidth()  - virtualSize.GetWidth(),  0) / 2;
  editCanvasStartPoint.y = std::max( clientSize.GetHeight() - virtualSize.GetHeight(), 0) / 2;

  double scaleX, scaleY;

  if (virtualSize.x < scrollSize.x)
  {
    changeDeviceOrigin = true;
    scaleX = double(virtualSize.x) / (theDocument->getSizeX() * Document::POINT_PRECISION);
  }
  else
  {
    editCanvasStartPoint.x = -viewX;
    scaleX = double(scrollSize.x-ZOOM_PRECISION_EPSILON) / (theDocument->getSizeX() * Document::POINT_PRECISION);
  }

  if (virtualSize.y < scrollSize.y)
  {
    changeDeviceOrigin = true;
    scaleY = double(virtualSize.y) / (theDocument->getSizeY() * Document::POINT_PRECISION);
  }
  else
  {
    editCanvasStartPoint.y = -viewY;
    scaleY = double(scrollSize.y-ZOOM_PRECISION_EPSILON) / (theDocument->getSizeY() * Document::POINT_PRECISION);
  }

  mdc.SetUserScale( scaleX, scaleY );

  //mdc.SetLogicalOrigin( editCanvasStartPoint.x, editCanvasStartPoint.y );

  if (changeDeviceOrigin)
    mdc.SetDeviceOrigin( editCanvasStartPoint.x, editCanvasStartPoint.y );
  else
  {
    mdc.SetDeviceOrigin( -viewX, -viewY );
  }

  {
    int testX = mdc.DeviceToLogicalX( 0 );
    int testY = mdc.DeviceToLogicalY( 0 );
  }
  {
    int testX = mdc.DeviceToLogicalX( clientSize.x-1 );
    int testY = mdc.DeviceToLogicalY( clientSize.y-1 );
  }
}

//----------------------------------------------------------------------------

void CanvasDraw::paintBackBuffer(wxMemoryDC& mdc)
{
  mdc.SelectObject( wxNullBitmap );
  wxClientDC dc(this);
  dc.DrawBitmap(m_backBufferBitmap, 0, 0, false);
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
