#ifndef MG_GUIWAITCOMPUTE
#define MG_GUIWAITCOMPUTE

#include "Solution.h"
#include "textes.h"
#include "Solveur/Population.h"


class CanvasVisualisationWait : public wxScrolledWindow
{
public:
  CanvasVisualisationWait() {};
  CanvasVisualisationWait( wxWindow *parent, wxWindowID, const wxPoint &pos, const wxSize &size );
  virtual ~CanvasVisualisationWait();

  void setSolution(std::auto_ptr<Solution> solution);

private:
  //void OnEraseBackground(wx
  void OnPaint( wxPaintEvent &event );
  void OnSize(wxSizeEvent& event);

  void PrepareDC(wxDC& dc);

  void  setSize();

  wxPoint convert(wxSize const& clientSize, Point2d const& position) const;

  DECLARE_EVENT_TABLE()

  std::auto_ptr<Solution> m_solution;

  float m_minX, m_minY;
  float m_maxX, m_maxY;
};



enum ID_CONTROLS_COMPUTE
{
  ID_COMPUTE_QUIT = 10000,
};

class DlgWaitCompute: public wxFrame
{
protected:

  wxStaticText* wst;
  wxStaticBitmap* wsb;
  CanvasVisualisationWait* visu;
  int m_iteration;

public:
  DlgWaitCompute( wxWindow* parent, wxString title );
  ~DlgWaitCompute();

  void DrawSomething(CPopulation& population);

  void OnQuit( wxCommandEvent& event );    
  bool OnClose(void) { return TRUE; }

  DECLARE_EVENT_TABLE()
};



#endif