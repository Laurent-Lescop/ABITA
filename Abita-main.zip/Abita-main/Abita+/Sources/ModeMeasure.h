#ifndef ABITA_MODE_MESURE_H
#define ABITA_MODE_MESURE_H

#include "Application.h"

#include "EditContext.h"
#include "intersections.h"
#include "MeshConnected.h"
#include "Point2d.h"
#include "wxUtilities.h"
#include "textes.h"



//----------------------------------------------------------------------------

class ModeMeasure : public InputMode
{
public:

  ModeMeasure(CanvasDraw& owner) : InputMode(owner), m_drawing(false),m_stay(false)
  {
    m_firstPosition = wxPoint(0,0);
  };

  virtual ~ModeMeasure()
  {
//    cancelDrawing();
//    m_owner.SetCursor( NULL );
  }

  virtual void OnEvent(wxMouseEvent& event)
  {
    wxPoint newMousePosition = event.GetPosition();

    if (wxGetApp().isGridEnabled())
    {
      //--- apply the grid
      Document const& doc = *theDocument;
      newMousePosition = doc.snapToGrid( newMousePosition );
    }

    if(!m_stay)
      m_currentPosition = newMousePosition;

    if (event.LeftDown())
    {
      if(m_stay)
      {
        // out of the stay state
        cancelDrawing();
      }

      if( ( !m_drawing ) || (m_stay) )
      {
        // first drawing
        m_firstPosition = newMousePosition;
        m_drawing = true;

        if(wxGetApp().isMesureToolEnable())
        {
            m_editSegmentDrawer.reset( new EditSegmentDrawer(m_owner, wxGetApp().getMesureToolValues()[0], wxGetApp().getMesureToolValues()[1]) );
            m_editSegmentDrawer->draw(true);
            m_editSegmentDrawer.reset( NULL );
        }

      }else
      {
        // go to stay state

        m_drawing = false;
        m_stay = true;
      }
    }

    // define the cursor to use

    if ( (m_drawing) || (m_stay) )
    {
      m_owner.SetCursor( *wxCROSS_CURSOR );      
      m_editSegmentDrawer.reset( new EditSegmentDrawer(m_owner, m_firstPosition, m_currentPosition) );

      wxGetApp().enableMesureTool(true);
      wxGetApp().setMesureToolValues(m_firstPosition, m_currentPosition);
    }
  };

//--------------------------------------------------------------------------

  virtual void OnKeyUp(wxKeyEvent& event)
  { 
    if (event.m_keyCode == WXK_ESCAPE)
    {
      cancelDrawing();
    }
  };
/*
  virtual void OnKillFocus(wxFocusEvent&)
  {
    m_editSegmentDrawer.reset( NULL );
  }

  virtual void OnScrollWin(wxScrollWinEvent&)
  {
    m_editSegmentDrawer.reset( NULL );
  }
*/
private:

  //--------------------------------------------------------------------------
  /*!
    Draws the currently edited segment on the construction, and clears the
    segment upon destruction
  */
  struct EditSegmentDrawer : public boost::noncopyable
  {
    EditSegmentDrawer(CanvasDraw& owner, wxPoint const& a, wxPoint const& b)
    : m_owner(owner), m_a(a), m_b(b)
    {
      //draw(true);
      draw(false);
    }

    ~EditSegmentDrawer()
    {
      draw(true);
    }

  public:

    void draw(bool erase)
    {
      if (!erase)
      {
        Document const& doc = *theDocument;
        Point2d a = doc.convert(m_a);
        Point2d b = doc.convert(m_b);
        float segLength = (b - a).length();
        wxGetApp().m_frame->setInformationText( wxString::Format(RS_MODECREATE_DISTANCE, segLength) );
      }

      CanvasDraw::DCmanager& manager = m_owner.getDC();
      wxDC& dc = manager.getDC();

      float length = wxDistance(m_a, m_b);
      wxString text = wxString::Format("%0.2f", length);

      wxPoint position;
      position.x = (m_a.x + m_b.x) / 2;
      position.y = (m_a.y + m_b.y) / 2;

      dc.SetPen( wxNullPen );
    
      Document const& doc = *theDocument;
      unsigned sizecroix = dc.DeviceToLogicalXRel(8);

      unsigned function = dc.GetLogicalFunction();
      dc.SetLogicalFunction(wxINVERT);
      dc.DrawLine(m_a, m_b);
      dc.DrawLine(wxPoint(m_a.x-sizecroix,m_a.y+sizecroix),wxPoint(m_a.x+sizecroix,m_a.y-sizecroix));
      dc.DrawLine(wxPoint(m_a.x+sizecroix,m_a.y+sizecroix),wxPoint(m_a.x-sizecroix,m_a.y-sizecroix));
      dc.DrawLine(wxPoint(m_b.x-sizecroix,m_b.y+sizecroix),wxPoint(m_b.x+sizecroix,m_b.y-sizecroix));
      dc.DrawLine(wxPoint(m_b.x+sizecroix,m_b.y+sizecroix),wxPoint(m_b.x-sizecroix,m_b.y-sizecroix));
      dc.SetLogicalFunction(function);
      if (erase)
        manager.paint();
    }
  private:

    wxPoint const m_a;
    wxPoint const m_b;
    CanvasDraw& m_owner;
  };

  //--------------------------------------------------------------------------

  struct Vertex
  {
    Vertex() {};
    Vertex(MeshConnected::VertexHandle handle, Point2d const& position)
    { m_vertexHandle = handle; m_position = position; };

    Point2d const& getPosition() const { return m_position; };
    MeshConnected::VertexHandle getVertexHandle() const { return m_vertexHandle; };

  private:
    Point2d                     m_position;
    MeshConnected::VertexHandle m_vertexHandle;
  };

  //--------------------------------------------------------------------------

  void cancelDrawing()
  {
    wxGetApp().enableMesureTool(false);

    m_stay = false;
    m_drawing = false;

    m_editSegmentDrawer.reset( NULL );
    wxGetApp().m_frame->setInformationText( _T("") );

    m_owner.Refresh();
  }

 
  //--------------------------------------------------------------------------

  wxPoint m_currentPosition;
  wxPoint m_firstPosition;

  std::auto_ptr<MeshConnected> m_originalState;
  std::auto_ptr<EditSegmentDrawer> m_editSegmentDrawer;
  bool m_drawing;
  bool m_stay;
};

//----------------------------------------------------------------------------

#endif