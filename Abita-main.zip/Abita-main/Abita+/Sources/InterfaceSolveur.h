#ifndef ABITA_INTERFACE_SOLVEUR_H
#define ABITA_INTERFACE_SOLVEUR_H

#include "AbitaDocument.h"
#include "Solution.h"

class CGeom;
class CPopulation;
class CAlgo;

void convert(Document& document, CGeom &geom, CPopulation &popu, CAlgo &algo);

std::auto_ptr<Solution> convert( Document const& document, CSolution const& solution, unsigned floorID );

#endif
