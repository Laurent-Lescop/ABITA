#ifndef ABITA_MODE_CHANGE_ELEMENT_TYPE_H
#define ABITA_MODE_CHANGE_ELEMENT_TYPE_H

#include "EditContext.h"
#include "MeshConnected.h"
#include "MeshConnected_algorithms.h"
#include "Point2d.h"
#include "wxUtilities.h"

//----------------------------------------------------------------------------

class ModeChangeElementType : public InputMode
{
public:

  ModeChangeElementType(CanvasDraw& owner, ElementType type)
  : InputMode(owner), m_type(type)
  {
  };

  virtual ~ModeChangeElementType()
  {
    m_owner.SetCursor( NULL );
  }

  virtual void OnEvent(wxMouseEvent& event)
  {
    Document const& doc = *theDocument;

    bool const isNearUniquePolygon = theEditContext.isNearUniquePolygon();

    if (isNearUniquePolygon)
    {
      m_owner.SetCursor( wxCursor(wxCURSOR_PAINT_BRUSH) );
    }
    else
    {
      m_owner.SetCursor(NULL);
    }

    if (event.LeftDown())
    {
      if (isNearUniquePolygon)
      {
        MeshConnected::PolygonHandle ph = theEditContext.getNearPolygon();
        MeshConnected::PolygonData* pdata = doc.getShape().getPolygonData(ph);

        pdata->setType( m_type );

        m_owner.Refresh();
      }
    }
  };

private:
  ElementType m_type;
};

//----------------------------------------------------------------------------

#endif