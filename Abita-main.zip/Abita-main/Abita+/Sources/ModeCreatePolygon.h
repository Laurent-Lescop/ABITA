#ifndef ABITA_MODE_CREATE_POLYGON_H
#define ABITA_MODE_CREATE_POLYGON_H

#include "Application.h"

#include "EditContext.h"
#include "intersections.h"
#include "MeshConnected.h"
#include "Point2d.h"
#include "wxUtilities.h"
#include "textes.h"


#ifndef M_PI
namespace
{
  const float M_PI = 3.141592654f;
}
#endif

//----------------------------------------------------------------------------

class ModeCreatePolygon : public InputMode
{
public:

  ModeCreatePolygon(CanvasDraw& owner) : InputMode(owner), m_drawing(false)
  {
  };

  virtual ~ModeCreatePolygon()
  {
    cancelDrawing();
    m_owner.SetCursor( NULL );
  }

  virtual void OnEvent(wxMouseEvent& event)
  {
    Document const& doc = *theDocument;

    //---

    m_currentPosition = event.GetPosition();

    //--- change the mouse position
    {
      wxPoint newMousePosition = m_currentPosition;

      if (event.ShiftDown() && !m_vertices.empty())
      {
        //--- do the angle snap
        MeshConnected::VertexHandle lastVertex = m_vertices.back();
        MeshConnected::VertexData* vdata = doc.getShape().getVertexData(lastVertex);
        Point2d startPosition = vdata->position;
        wxPoint startPositionDC = doc.convert(startPosition);

        Point2d currentPosition = doc.convert(newMousePosition);

        float sdx = (currentPosition.x - startPosition.x);
        float sdy = (currentPosition.y - startPosition.y);
        float dx = fabsf(sdx);
        float dy = fabsf(sdy);
        if (dx > dy)
        {
          currentPosition.y = startPosition.y;
        }
        else
        {
          currentPosition.x = startPosition.x;
        }

        newMousePosition = doc.convert(currentPosition);
      }

      if (wxGetApp().isGridEnabled())
      {
        //--- apply the grid
        newMousePosition = doc.snapToGrid( newMousePosition );
      }

      if (newMousePosition != m_currentPosition)
      {
        //--- refresh the nearby elements
        m_currentPosition = newMousePosition;

        CanvasDraw::DCmanager manager = m_owner.getDC();
        wxDC& dc = manager.getDC();
        unsigned sensitivity = computeSensitivity(dc);
        theEditContext.populate( m_currentPosition, sensitivity );
      }
    }

    //---

    bool const isNearNothing = theEditContext.isNearNothing();
    bool const isNearUniqueVertex = theEditContext.isNearUniqueVertex();
    bool validNearVertex = false;

    // draw vertex handles
    {
      CanvasDraw::DCmanager manager = m_owner.getDC();
      wxDC& dc = manager.getDC();

      redrawVertexHandles(dc, VH_DONT_CARE);
      std::vector<MeshConnected::VertexHandle> nearVs;
      theEditContext.getNearVertices( nearVs );
      
      unsigned const numNearVs = nearVs.size();
      if (numNearVs == 1)
      {
        validNearVertex = isValidNextVertex( nearVs[0] );
      }

      VertexHandleStatus const status = validNearVertex ? VH_OK : VH_NOK;
      for (unsigned v=0; v<numNearVs; v++)
      {
        MeshConnected::VertexHandle handle = nearVs[v];
        MeshConnected::VertexData* vdata = doc.getShape().getVertexData(handle);
        drawVertexHandle(dc, doc.convert(vdata->position), status);
      }
    }

    bool validPosition = true;

    if (m_drawing)
    {
      validPosition = isValidNextPosition(m_currentPosition);
    }

    if (validPosition && (isNearNothing || (isNearUniqueVertex && validNearVertex)))
    {
      m_owner.SetCursor( *wxCROSS_CURSOR );
    }
    else
    {
      m_owner.SetCursor( wxCursor(wxCURSOR_NO_ENTRY) );
    }

    if (!m_drawing)
    {
      if (event.LeftDown())
      {
        // start drawing
        m_drawing = true;
        m_originalState.reset( new MeshConnected(doc.getShape()) );
      }
    }

    // define the cursor to use

    if (m_drawing)
    {
      // draw the current 'edit' segment
      if (!m_vertices.empty())
      {
        MeshConnected::VertexHandle lastVertex = m_vertices.back();
        MeshConnected::VertexData* vdata = doc.getShape().getVertexData(lastVertex);
        wxPoint startPosition = doc.convert(vdata->position);

        m_editSegmentDrawer.reset( new EditSegmentDrawer(m_owner, startPosition, m_currentPosition, validPosition) );
      }

      // draw the currently created polyline
      {
        CanvasDraw::DCmanager manager = m_owner.getDC();
        wxDC& dc = manager.getDC();

        unsigned numPlacedVerts = m_vertices.size();
        if (numPlacedVerts > 0)
        {
          MeshConnected::VertexHandle baseVH = m_vertices[0];
          MeshConnected::VertexData* baseVdata = doc.getShape().getVertexData(baseVH);
          wxPoint prevPosition = doc.convert( baseVdata->position );

          for (unsigned v=1; v<numPlacedVerts; v++)
          {
            MeshConnected::VertexHandle currentV = m_vertices[v];
            MeshConnected::VertexData* currentVdata = doc.getShape().getVertexData(currentV);

            wxPoint position = doc.convert( currentVdata->position );
            dc.DrawLine( prevPosition, position );
            prevPosition = position;
          }
        }

        manager.paint();
      }

      if (event.LeftDown())
      {
        // start a new segment
        if (validPosition)
        {
          if (isNearUniqueVertex)
          {
            if (validNearVertex)
            {
              MeshConnected::VertexHandle handle = theEditContext.getNearVertex();

              if (!m_vertices.empty() && handle == m_vertices[0])
              {
                // close the polygon & create it
                createPolygon();
              }
              else
              {
                // add an existing vertex to the polygon
                m_vertices.push_back( handle );
              }
            }
          }
          else
          {
            // add a new vertex to the polygon
            std::auto_ptr<MeshConnected::VertexData> vdata( new MeshConnected::VertexData );
            Point2d position = doc.convert(m_currentPosition);
            vdata->position = position;
            MeshConnected::VertexHandle newv = doc.getShape().createVertex( vdata );
            m_vertices.push_back( newv ); 
          }
        }
      }

      if (event.RightDown())
      {
        if (m_vertices.size() > 2)
        {
          createPolygon();
        }
      }
    }
  };

  //--------------------------------------------------------------------------

  virtual void OnKeyUp(wxKeyEvent& event)
  { 
    if (event.m_keyCode == WXK_ESCAPE)
    {
      cancelDrawing();
    }
  };

  virtual void OnKillFocus(wxFocusEvent&)
  {
    m_editSegmentDrawer.reset( NULL );
  }

  virtual void OnScrollWin(wxScrollWinEvent&)
  {
    m_editSegmentDrawer.reset( NULL );
  }

private:

  //--------------------------------------------------------------------------
  /*!
    Draws the currently edited segment on the construction, and clears the
    segment upon destruction
  */
  struct EditSegmentDrawer : public boost::noncopyable
  {
    EditSegmentDrawer(CanvasDraw& owner, wxPoint const& a, wxPoint const& b, bool validSegment)
    : m_owner(owner), m_a(a), m_b(b), m_valid(validSegment)
    {
      draw(false);
    }

    ~EditSegmentDrawer()
    {
      draw(true);
    }

  private:

    void draw(bool erase)
    {
      if (!erase)
      {
        Document const& doc = *theDocument;
        Point2d a = doc.convert(m_a);
        Point2d b = doc.convert(m_b);
        float segLength = (b - a).length();
        wxGetApp().m_frame->setInformationText( wxString::Format(RS_MODECREATE_DISTANCE, segLength) );
      }

      CanvasDraw::DCmanager& manager = m_owner.getDC();
      wxDC& dc = manager.getDC();

      float length = wxDistance(m_a, m_b);
      wxString text = wxString::Format("%0.2f", length);

      wxPoint position;
      position.x = (m_a.x + m_b.x) / 2;
      position.y = (m_a.y + m_b.y) / 2;

      if (m_valid)
        dc.SetPen( wxNullPen );
      else
        dc.SetPen( *wxBLACK_DASHED_PEN );

      unsigned function = dc.GetLogicalFunction();
      dc.SetLogicalFunction(wxINVERT);
      dc.DrawLine(m_a, m_b);

      //drawCenteredText(*m_dc, lengthText, position);    
      //wxGetApp().m_frame->setInformationText(RS_MODECREATE_DISTANCE + lengthText);

      dc.SetLogicalFunction(function);

      if (erase)
        manager.paint();
    }

    wxPoint const m_a;
    wxPoint const m_b;
    CanvasDraw& m_owner;
    bool m_valid;
  };

  //--------------------------------------------------------------------------

  struct Vertex
  {
    Vertex() {};
    Vertex(MeshConnected::VertexHandle handle, Point2d const& position)
    { m_vertexHandle = handle; m_position = position; };

    Point2d const& getPosition() const { return m_position; };
    MeshConnected::VertexHandle getVertexHandle() const { return m_vertexHandle; };

  private:
    Point2d                     m_position;
    MeshConnected::VertexHandle m_vertexHandle;
  };

  //--------------------------------------------------------------------------

  void cancelDrawing()
  {
    m_drawing = false;

    m_vertices.resize(0);

    Document& doc = *theDocument;
    if (m_originalState.get() != NULL)
      doc.setShape( m_originalState );

    m_editSegmentDrawer.reset( NULL );
    wxGetApp().m_frame->setInformationText( _T("") );

    m_owner.Refresh();
  }

  //--------------------------------------------------------------------------

  void createPolygon()
  {
    Document& doc = *theDocument;

    std::auto_ptr<MeshConnected::PolygonData> pdata( new MeshConnected::PolygonData(FREE_PART) );
    unsigned const numV = m_vertices.size();
    doc.getShape().createPolygon(m_vertices, pdata);
    m_vertices.clear();
    m_originalState.reset( new MeshConnected( doc.getShape() ) );
    m_drawing = false;
    m_editSegmentDrawer.reset(NULL);
    m_owner.Refresh();
  }

  //--------------------------------------------------------------------------

  bool isValidNextVertex(MeshConnected::VertexHandle handle)
  {
    unsigned const numVertices = m_vertices.size();
    if (numVertices == 0)
      return true;
    else
    {
      if (m_vertices[0] == handle)
      {
        // connect with the first point of the polyline - can close ?
        if (numVertices <= 2)
          return false;
        else
        {
          // TODO : add a self intersection test here ?
          return true;
        }
      }
      else
      {
        Vertices::const_iterator it = std::find(m_vertices.begin(), m_vertices.end(), handle);
        if (it == m_vertices.end())
          return true;
        else
          return false;
      }
    }
  }

  //--------------------------------------------------------------------------

  bool isValidNextPosition(wxPoint const& point) const
  {
    if (m_vertices.empty())
      return true;

    Document& doc = *theDocument;
    Point2d const position = doc.convert(point);

    MeshConnected::VertexHandle lastVertex = m_vertices.back();
    MeshConnected::VertexData* vdata = doc.getShape().getVertexData(lastVertex);
    Point2d const lastPosition = vdata->position;

    Point2d seg_a = doc.getShape().getVertexData( m_vertices[0] )->position;
    for (unsigned i=1; i<m_vertices.size(); i++)
    {
      Point2d seg_b = doc.getShape().getVertexData( m_vertices[i] )->position;

      int dummy;
      float dists[2];

      if (segments_intersect(position, lastPosition, seg_a, seg_b, dummy, dists))
      {
        const float EPSILON = 1e-5f;
        if (dists[0] > EPSILON && dists[0] < 1.f-EPSILON)
          return false;
        if (dists[1] > EPSILON && dists[1] < 1.f-EPSILON)
          return false;
      }

      seg_a = seg_b;
    }

    return true;
  }

  //--------------------------------------------------------------------------

  typedef std::vector<MeshConnected::VertexHandle> Vertices;
  Vertices m_vertices;

  wxPoint m_currentPosition;

  std::auto_ptr<MeshConnected> m_originalState;
  std::auto_ptr<EditSegmentDrawer> m_editSegmentDrawer;
  bool m_drawing;
};

//----------------------------------------------------------------------------

#endif