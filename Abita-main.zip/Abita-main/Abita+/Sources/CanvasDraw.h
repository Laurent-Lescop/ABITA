#ifndef ABIT_CANVAS_DRAW_H
#define ABIT_CANVAS_DRAW_H

#include "InputMode.h"

//----------------------------------------------------------------------------

class CanvasDraw : public wxScrolledWindow
{
public:

  struct DCmanager
  {
    DCmanager(DCmanager const& manager) : m_canvas(manager.m_canvas)
    {
      //m_dc.SelectObject( m_canvas.m_backBufferBitmap );
      m_canvas.PrepareBackBufferDC( m_dc );
    };

    void paint()
    {
      m_canvas.paintBackBuffer( m_dc );
    }

    ~DCmanager()
    {
    }

    wxDC& getDC() { return m_dc; };

  private:

    DCmanager(CanvasDraw& canvas) : m_canvas(canvas)
    {
      m_canvas.PrepareBackBufferDC( m_dc );
    };

    DCmanager& operator=(DCmanager const&);   //!< undefined

    friend CanvasDraw;

    CanvasDraw& m_canvas;
    wxMemoryDC m_dc;
  };

  CanvasDraw() {};
  CanvasDraw( wxWindow *parent, wxWindowID, const wxPoint &pos, const wxSize &size );
  ~CanvasDraw();

  void OnEraseBackground( wxEraseEvent& event );
  void OnKeyDown( wxKeyEvent& event );
  void OnKeyUp( wxKeyEvent& event );
  void OnMouseEvent( wxMouseEvent &event );
  void OnPaint( wxPaintEvent &event );
  void OnSetFocus(wxFocusEvent& event);
  void OnKillFocus(wxFocusEvent& event);
  void OnScrollWin(wxScrollWinEvent& event);
  void OnActivate(wxActivateEvent& event);

  void setInputMode( std::auto_ptr<InputMode> newMode ) { Refresh(); m_currentMode = newMode; };
  void setBkgrdChange(bool b) { m_bkgrd_change = b; };
  
  DCmanager getDC() { return DCmanager(*this); };

  //void putBitmap(wxImage imgSrc,wxImage imgDst,float ang,float z,wxSize outReel,wxSize outCrop);//----

  virtual void Refresh(bool eraseBackground = TRUE, const wxRect* rect = NULL);

  DECLARE_DYNAMIC_CLASS(CanvasDraw)
  DECLARE_EVENT_TABLE()

private:

  friend DCmanager;

  //--

  void PrepareBackBufferDC(wxMemoryDC& mdc);

  void OnSize(wxSizeEvent& event);

  void paintBackdropImage(wxDC& dc);

  void drawEchelle();
  void paintBackBuffer(wxMemoryDC& mdc);

  wxBitmap  m_backBufferBitmap;
  wxImage   m_backDropImage;

  std::auto_ptr<InputMode> m_currentMode;
  wxPoint m_currentMousePosition;
  bool    m_bkgrd_change;
};

//----------------------------------------------------------------------------

#endif