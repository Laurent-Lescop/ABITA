#ifndef ABITA_MODE_DELETE_SHAPE_ELEMENTS_H
#define ABITA_MODE_DELETE_SHAPE_ELEMENTS_H

#include "EditContext.h"
#include "MeshConnected.h"
#include "MeshConnected_algorithms.h"
#include "Point2d.h"
#include "wxUtilities.h"

//----------------------------------------------------------------------------

class ModeDeleteShapeElements : public InputMode
{
public:

  ModeDeleteShapeElements(CanvasDraw& owner) : InputMode(owner)
  {
  };

  virtual ~ModeDeleteShapeElements()
  {
    m_owner.SetCursor( NULL );
  }

  virtual void OnEvent(wxMouseEvent& event)
  {
    Document const& doc = *theDocument;

    bool const isNearUniqueVertex = theEditContext.isNearUniqueVertex();
    bool const isNearUniqueEdge = theEditContext.isNearUniqueEdge();
    bool const isNearUniquePolygon = theEditContext.isNearUniquePolygon();
    bool validVertexToDelete;
    bool validEdgeToDelete;

    {
      CanvasDraw::DCmanager& manager = m_owner.getDC();
      wxDC& dc = manager.getDC();

      // draw polygons
      {
        redrawPolygons(dc, doc.getShape(), P_DONT_CARE);

        MeshConnected::PolygonHandle poly = theEditContext.getNearPolygon();
        if (poly != MeshConnected::INVALID_HANDLE)
        {
          drawPolygon(dc, doc.getShape(), poly, P_OK);
        }
      }
      // draw edges
      {
        redrawEdges(dc, doc.getShape(), E_DONT_CARE);
        std::vector<MeshConnected::EdgeHandle> nearE;
        theEditContext.getNearEdges( nearE );
        
        if (!nearE.empty())
        {
          unsigned const numNearE = nearE.size();
          
          validEdgeToDelete = (isNearUniqueEdge && isValidEdgeToDelete(nearE[0]));

          EdgeStatus const status = (validEdgeToDelete) ? E_OK : E_NOK;
          for (unsigned e=0; e<numNearE; e++)
          {
            MeshConnected::EdgeHandle handle = nearE[e];
            drawEdge(dc, doc.getShape(), handle, status);
          }
        }
      }
      // draw vertex handles
      {
        redrawVertexHandles(dc, VH_DONT_CARE);
        std::vector<MeshConnected::VertexHandle> nearVs;
        theEditContext.getNearVertices( nearVs );
        
        if (!nearVs.empty())
        {
          validVertexToDelete = (isNearUniqueVertex && isValidVertexToDelete(nearVs[0]));

          unsigned const numNearVs = nearVs.size();
          VertexHandleStatus const status = (validVertexToDelete) ? VH_OK : VH_NOK;
          for (unsigned v=0; v<numNearVs; v++)
          {
            MeshConnected::VertexHandle handle = nearVs[v];
            MeshConnected::VertexData* vdata = doc.getShape().getVertexData(handle);
            drawVertexHandle(dc, doc.convert(vdata->position), status);
          }
        }
      }

      manager.paint();
    }

    // define the cursor to use
    m_owner.SetCursor( *wxCROSS_CURSOR );

    if (event.LeftDown())
    {
      if (isNearUniqueVertex && validVertexToDelete)
      {
        removeVertex( doc.getShape(), theEditContext.getNearVertex() );
        m_owner.Refresh();
      }
      if (isNearUniqueEdge && validEdgeToDelete)
      {
        removeEdge( doc.getShape(), theEditContext.getNearEdge() );
        m_owner.Refresh();
      }
      if (isNearUniquePolygon)
      {
        doc.getShape().erasePolygon( theEditContext.getNearPolygon() );
        m_owner.Refresh();
      }
    }
  };

private:

  bool isValidEdgeToDelete(MeshConnected::EdgeHandle eh) const
  {
    Document const& doc = *theDocument;
    MeshConnected const& mesh = doc.getShape();

    std::vector<MeshConnected::PolygonHandle> polygons;
    mesh.findAdjacentPolygons(eh, polygons);
    
    if (polygons.size() != 2)
      return false;

    MeshConnected::VertexHandle vh[2];
    mesh.findVertices( eh, vh );

    for (unsigned i=0; i<2; i++)
    {
      std::vector<MeshConnected::EdgeHandle> edges;
      mesh.findAdjacentEdges(vh[i], edges);
      if (edges.size() < 3)
        return false;
    }
    return true;
  }

  bool isValidVertexToDelete(MeshConnected::VertexHandle vh) const
  {
    Document const& doc = *theDocument;
    MeshConnected const& mesh = doc.getShape();

    std::vector<MeshConnected::EdgeHandle> edges;
    mesh.findAdjacentEdges(vh, edges);
    
    if (edges.size() != 2)
      return false;

    return true;
  }
};

//----------------------------------------------------------------------------

#endif