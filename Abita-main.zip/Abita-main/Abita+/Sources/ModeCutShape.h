#ifndef ABITA_MODE_CUT_SHAPE_H
#define ABITA_MODE_CUT_SHAPE_H

#include "EditContext.h"
#include "MeshConnected.h"
#include "MeshConnected_algorithms.h"
#include "Point2d.h"
#include "wxUtilities.h"

//----------------------------------------------------------------------------

class ModeCutShape : public InputMode
{
public:

  ModeCutShape(CanvasDraw& owner) : InputMode(owner), m_drawing(false)
  {
  };

  virtual ~ModeCutShape()
  {
    cancelDrawing();
    m_owner.SetCursor( NULL );
  }

  virtual void OnEvent(wxMouseEvent& event)
  {
    Document const& doc = *theDocument;

    m_currentPosition = event.GetPosition();

    //--- change the mouse position
    {
      wxPoint newMousePosition = m_currentPosition;

      if (event.ShiftDown() && m_drawing)
      {
        //--- do the angle snap
        wxPoint startPositionDC = m_startPosition;
        Point2d startPosition = m_startCut;

        Point2d currentPosition = doc.convert(newMousePosition);

        float sdx = (currentPosition.x - startPosition.x);
        float sdy = (currentPosition.y - startPosition.y);
        float dx = fabsf(sdx);
        float dy = fabsf(sdy);
        if (dx > dy)
        {
          currentPosition.y = startPosition.y;
        }
        else
        {
          currentPosition.x = startPosition.x;
        }

        newMousePosition = doc.convert(currentPosition);
      }

      if (wxGetApp().isGridEnabled())
      {
        //--- apply the grid
        newMousePosition = doc.snapToGrid( newMousePosition );
      }

      if (newMousePosition != m_currentPosition)
      {
        //--- refresh the nearby elements
        m_currentPosition = newMousePosition;

        CanvasDraw::DCmanager manager = m_owner.getDC();
        wxDC& dc = manager.getDC();
        unsigned sensitivity = computeSensitivity(dc);
        theEditContext.populate( m_currentPosition, sensitivity );
      }
    }

    bool const isNearNothing = theEditContext.isNearNothing();
    bool const isNearUniqueVertex = theEditContext.isNearUniqueVertex();

    // draw vertex handles
    {
      CanvasDraw::DCmanager& manager = m_owner.getDC();
      wxDC& dc = manager.getDC();

      redrawVertexHandles(dc, VH_DONT_CARE);
      std::vector<MeshConnected::VertexHandle> nearVs;
      theEditContext.getNearVertices( nearVs );
      
      unsigned const numNearVs = nearVs.size();
      VertexHandleStatus const status = VH_NOK;
      for (unsigned v=0; v<numNearVs; v++)
      {
        MeshConnected::VertexHandle handle = nearVs[v];
        MeshConnected::VertexData* vdata = doc.getShape().getVertexData(handle);
        drawVertexHandle(dc, doc.convert(vdata->position), status);
      }

      manager.paint();
    }

    bool const isCutForbidden = !isNearNothing;

    // define the cursor to use

    if (isCutForbidden)
    {
      m_owner.SetCursor( wxCursor(wxCURSOR_NO_ENTRY) );
    }
    else
    {
      m_owner.SetCursor( *wxCROSS_CURSOR );
    }

    if (m_drawing)
    {
      if (event.LeftDown() && !isCutForbidden)
      {
        // do the cut
        Point2d endCut   = doc.convert( m_currentPosition );

        if (isNearUniqueVertex)
        {
          MeshConnected::VertexData* vdata = doc.getShape().getVertexData( theEditContext.getNearVertex() );
          endCut = vdata->position;
        }

        cutMesh( doc.getShape(), m_startCut, endCut );

        m_owner.Refresh();
        cancelDrawing();
      }
    }
    else
    {
      if (event.LeftDown() && !isCutForbidden)
      {
        // start drawing
        m_drawing = true;
        if (isNearUniqueVertex)
        {
          MeshConnected::VertexData* vdata = doc.getShape().getVertexData( theEditContext.getNearVertex() );
          m_startPosition = doc.convert( vdata->position );
          m_startCut = vdata->position;
        }
        else
        {
          m_startPosition = m_currentPosition;
          m_startCut = doc.convert( m_startPosition );
        }
      }
    }

    if (m_drawing)
    {
      // draw the current 'edit' segment
      {
        m_editSegmentDrawer.reset( new EditSegmentDrawer(m_owner, m_startPosition, m_currentPosition) );
      }

      if (event.RightDown())
      {
        cancelDrawing();
      }
    }
  };

  //--------------------------------------------------------------------------

  virtual void OnKeyUp(wxKeyEvent& event)
  { 
    if (event.m_keyCode == WXK_ESCAPE)
    {
      cancelDrawing();
    }
  };

  virtual void OnKillFocus(wxFocusEvent&)
  {
    m_editSegmentDrawer.reset( NULL );
  }

  virtual void OnScrollWin(wxScrollWinEvent&)
  {
    m_editSegmentDrawer.reset( NULL );
  }

private:

  //--------------------------------------------------------------------------
  /*!
    Draws the currently edited segment on the construction, and clears the
    segment upon destruction
  */
  struct EditSegmentDrawer : public boost::noncopyable
  {
    EditSegmentDrawer(CanvasDraw& owner, wxPoint const& a, wxPoint const& b)
    : m_owner(owner), m_a(a), m_b(b)
    {
      draw(false);
    }

    ~EditSegmentDrawer()
    {
      draw(true);
    }

  private:

    void draw(bool erase)
    {
      CanvasDraw::DCmanager& manager = m_owner.getDC();
      wxDC& dc = manager.getDC();

      unsigned function = dc.GetLogicalFunction();
      dc.SetLogicalFunction(wxINVERT);
      dc.DrawLine(m_a, m_b);

      dc.SetLogicalFunction(function);

      manager.paint();
    }

    wxPoint const m_a;
    wxPoint const m_b;
    CanvasDraw& m_owner;
  };

  //--------------------------------------------------------------------------

  void cancelDrawing()
  {
    m_drawing = false;
    m_editSegmentDrawer.reset( NULL );
    m_owner.Refresh();
  }

  //--------------------------------------------------------------------------

  wxPoint m_startPosition, m_currentPosition;
  Point2d m_startCut;

  std::auto_ptr<EditSegmentDrawer> m_editSegmentDrawer;
  bool m_drawing;
};

//----------------------------------------------------------------------------

#endif