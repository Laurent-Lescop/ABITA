#ifndef ABITA_EDIT_CONTEXT_H
#define ABITA_EDIT_CONTEXT_H

#include "MeshConnected.h"

//----------------------------------------------------------------------------

class EditContext
{
public:

  static const unsigned SENSIVITY = 4;

  EditContext() {};

  void resetContext();
  void setContext( std::vector<MeshConnected::VertexHandle> const& nearVertices );
  void setContext( std::vector<MeshConnected::EdgeHandle> const& nearEdges );
  void setContext( MeshConnected::PolygonHandle insidePolygon );

  bool isNearNothing() const;
  bool isNearUniqueVertex() const;
  bool isNearUniqueEdge() const;
  bool isNearUniquePolygon() const;

  bool isNearVertex( MeshConnected::VertexHandle handle );

  MeshConnected::VertexHandle getNearVertex() const;
  void getNearVertices(std::vector<MeshConnected::VertexHandle>& result) const;

  MeshConnected::EdgeHandle getNearEdge() const;
  void getNearEdges(std::vector<MeshConnected::EdgeHandle>& result) const;

  MeshConnected::PolygonHandle getNearPolygon() const;

  void populate( wxPoint const& mousePosition, unsigned sensitivity );

private:
  EditContext(EditContext const&);
  EditContext& operator=(EditContext const&);

  std::vector<MeshConnected::VertexHandle> m_nearVertices;
  std::vector<MeshConnected::EdgeHandle> m_nearEdges;
  MeshConnected::PolygonHandle m_nearPolygon;
};

//----------------------------------------------------------------------------

inline unsigned computeSensitivity(wxDC& dc)
{
  return dc.DeviceToLogicalXRel( EditContext::SENSIVITY );
}

//----------------------------------------------------------------------------

extern EditContext theEditContext;

//----------------------------------------------------------------------------

#endif