#ifndef ABITA_FRAMEMAIN_H
#define ABITA_FRAMEMAIN_H

#include "Solveur/Geom.h"
#include "Solveur/Algo.h"

class CanvasDraw;

using namespace std;

class FrameMain : public wxFrame
{
public:
  FrameMain(const wxString& title, const wxPoint& pos, const wxSize& size,long style = wxDEFAULT_FRAME_STYLE);

  void OnSize(wxSizeEvent& event);
  // menu
  void OnMenuQuitter(wxCommandEvent& event);
  void OnMenuNouveau(wxCommandEvent& WXUNUSED(event));
  void OnMenuCharger(wxCommandEvent& WXUNUSED(event));
  void OnMenuSauver(wxCommandEvent& WXUNUSED(event));
  void OnMenuExporter(wxCommandEvent& WXUNUSED(event));
  void OnMenuImprimer(wxCommandEvent& WXUNUSED(event));

  void OnMenuPropriete(wxCommandEvent& WXUNUSED(event));
  void OnMenuConfiguration(wxCommandEvent& WXUNUSED(event));
  void OnMenuSolution(wxCommandEvent& WXUNUSED(event));
  void OnMenuVisualiser(wxCommandEvent& WXUNUSED(event));

  void OnMenuUndo(wxCommandEvent& event);
  void OnMenuRedo(wxCommandEvent& event);  
  void OnMenuEtageAdd(wxCommandEvent& WXUNUSED(event));
  void OnMenuEtageSup(wxCommandEvent& WXUNUSED(event));
  void OnMenuNormal(wxCommandEvent& WXUNUSED(event));
  void OnMenuContour(wxCommandEvent& WXUNUSED(event));
  void OnMenuStructure(wxCommandEvent& WXUNUSED(event));
  void OnMenuMesure(wxCommandEvent& WXUNUSED(event));
  void OnMenuDeplacer(wxCommandEvent& WXUNUSED(event));
  void OnMenuSupprimer(wxCommandEvent& WXUNUSED(event));

  void OnMenuZoomIn(wxCommandEvent& WXUNUSED(event));
  void OnMenuZoomOut(wxCommandEvent& WXUNUSED(event));
  void OnMenuZoomReset(wxCommandEvent& WXUNUSED(event));

  void OnMenuFond(wxCommandEvent& event);
  void OnMenuGrid(wxCommandEvent& event);

  void OnMenuElementLibre(wxCommandEvent& WXUNUSED(event));
  void OnMenuElementCommunPossible(wxCommandEvent& WXUNUSED(event));
  void OnMenuElementCommunImpose(wxCommandEvent& WXUNUSED(event));
  void OnMenuElementSortie(wxCommandEvent& WXUNUSED(event));

  void OnMenuShowtips(wxCommandEvent& WXUNUSED(event));
  void OnMenuAide(wxCommandEvent& WXUNUSED(event));
  void OnMenuAbout(wxCommandEvent& event);

  //toolbar
  void OnToolEnterH(wxCommandEvent& event);
  void OnToolEnterV(wxCommandEvent& event);

  void OnPageChange(wxNotebookEvent &event);

  void setInformationText(wxString const& str){ m_information_text->SetLabel(str); };
  void setInformationCels(wxString const& str){ m_textCels->SetLabel(str); };

  void refreshCanvas();
  // background bitmap
  wxImage m_img_fond_ecran;

private:
  // any class wishing to process wxWindows events must use this macro
  DECLARE_EVENT_TABLE()

  wxMenuItem *createMenuItem(wxMenu *parent,unsigned id,wxString str,wxBitmap bitmap);
  wxMenuItem *createMenuItem(wxMenu *parent,unsigned id,wxString str);
  wxMenuItem *createSeparator(wxMenu *parent);
  wxBitmap SetTrans(wxBitmap in);

  //float m_size_fond_ecran;
  void layoutChildren();

  // --
  wxConfig *m_config;
  wxStaticText *m_information_text;
  std::vector<CanvasDraw*> m_canvas;

  //  for gui
  wxTextCtrl *m_log_textctrl;
  wxToolBarBase *m_toolbarVerticale;
  wxToolBar *m_toolBarhorizontale;
  wxPanel *m_panelTop,*m_panelBottom;
  wxTextCtrl *m_textCels;
  wxSplitterWindow *m_split;
  wxNotebook *m_notebook;

  wxMenu *menuFile;
  wxMenu *menuProjet;
  wxMenu *menuDraw; 
  wxMenu *menuView; 

  std::auto_ptr<CGeom>       m_geom;
  std::auto_ptr<CPopulation> m_popu;
  std::auto_ptr<CAlgo>       m_algo;

  unsigned m_last_id;

};

#endif