#ifndef MG_GUIABOUT
#define MG_GUIABOUT

#include "precompiled.h"
#include "textes.h"

enum ID_CONTROLS_ABOUT
{
  ID_ABOUT_BUTT = 10000,
  ID_ABOUT_QUIT
};

class DlgAbout: public wxDialog
{
protected:
  //wxFrame*   mpClientWnd;   
  wxStaticBitmap *wsb;
  wxButton *wxb;
public:
  DlgAbout( wxWindow* parent, wxString title );
  ~DlgAbout();

  void OnQuit( wxCommandEvent& event );    
  void OnButt( wxCommandEvent& event );
  bool OnClose(void) { return TRUE; }

  DECLARE_EVENT_TABLE()
};


/***** Immlementation for class DlgAbout *****/

BEGIN_EVENT_TABLE(DlgAbout, wxDialog)
  EVT_MENU( ID_ABOUT_QUIT,  DlgAbout::OnQuit  )
  EVT_BUTTON( ID_ABOUT_BUTT, DlgAbout::OnButt )
END_EVENT_TABLE()


DlgAbout::DlgAbout( wxWindow* parent, wxString title )  : wxDialog( parent, -1, title, wxDefaultPosition, wxSize( 600, 540  ), wxTHICK_FRAME)
{ 	
  this->SetBackgroundColour(*wxWHITE);
  wxBitmap bmp("about_dialog");
  if (bmp.Ok())
  {
    wsb = new  wxStaticBitmap(this, -1, bmp, wxPoint(125, 0));        
  }
  wxStaticText* wst = new wxStaticText(this, -1, RS_ABOUT_COPYRIGHT, wxPoint(8,280), wxSize(600,300),wxST_NO_AUTORESIZE );
  wst->SetFont( wxFont( 7, wxSWISS, wxNORMAL, wxNORMAL ) );
  wxb = new wxButton(wst, ID_ABOUT_BUTT, RS_DIALOG_OK, wxPoint(290, 225));
  wxb->SetDefault();

}

DlgAbout::~DlgAbout()
{
    delete wxb;
    delete wsb;
}

void DlgAbout::OnQuit( wxCommandEvent& event )
{
  Show( FALSE ); // TRICK:: hide it, to avoid flickered destruction

  Close(TRUE);
}

void DlgAbout::OnButt( wxCommandEvent& event )
{
  Show( FALSE ); // TRICK:: hide it, to avoid flickered destruction

  Close(TRUE);

}

#endif