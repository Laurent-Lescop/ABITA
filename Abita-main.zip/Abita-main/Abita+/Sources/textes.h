#ifndef MG_RESOURCES_FR
#define MG_RESOURCES_FR

//-------------------------------------------------

// defition des resources de textes
// FR

//-------------------------------------------------

// Main Application
static const wxString RS_APP_TITLE =           _T("Abita+ version de d�monstration");
static const wxString RS_APP_VENDORNAME  =     _T("MGDESIGN");
static const wxString RS_APP_NAME  =           _T("Abita+");
static const wxString RS_APP_CLASSNAME =       _T("Architecture");

// dialog standard..
static const wxString RS_DIALOG_OK  =          _T("Ok");
static const wxString RS_DIALOG_ANNULER  =     _T("Annuler");
static const wxString RS_DIALOG_NON  =         _T("non");
static const wxString RS_DIALOG_FERMER  =      _T("Fermer");
static const wxString RS_DIALOG_ERREUR       = _T("Erreur");
static const wxString RS_DIALOG_WARNING      = _T("Attention");
static const wxString RS_DIALOG_PROPRIETE_DEFAULT = _T("Valeurs par d�fault");
static const wxString RS_DIALOG_QUESTION      = _T("Question ?");

static const wxString RS_INFORMATIONS =         _T("Informations");
static const wxString RS_INFORMATIONS_DEFAULT = _T("                                                \n                                                ");

// menu
static const wxString RS_MENU_GLOBAL_FILE  =   _T("&Fichier");
static const wxString RS_MENU_GLOBAL_PROJET=   _T("&Projet");
static const wxString RS_MENU_GLOBAL_DRAW =    _T("&Conception");
static const wxString RS_MENU_GLOBAL_VIEW =    _T("&Affichage");
static const wxString RS_MENU_GLOBAL_HELP =    _T("&Aide");
// menu fichier
static const wxString RS_MENU_NOUVEAU  =       _T("&Nouveau");
static const wxString RS_MENU_NOUVEAU_INFO =   _T("Cr�er un nouveau projet");
static const wxString RS_MENU_CHARGER   =      _T("&Ouvrir");
static const wxString RS_MENU_CHARGER_INFO=    _T("Charger un projet existant");
static const wxString RS_MENU_SAUVER    =      _T("Enregistrer &sous");
static const wxString RS_MENU_SAUVER_INFO =    _T("Sauver le projet en court");
static const wxString RS_MENU_EXPORTER   =     _T("&Exporter");
static const wxString RS_MENU_EXPORTER_INFO=   _T("Exporter le projet vers d'autres logiciels");
static const wxString RS_MENU_IMPRIMER     =   _T("&Imprimer");
static const wxString RS_MENU_IMPRIMER_INFO =  _T("Imprimer");
static const wxString RS_MENU_QUITTER       =  _T("&Quitter\tAlt-X");
static const wxString RS_MENU_QUITTER_INFO  =  _T("Quitter l'application");
// menu projet
static const wxString RS_MENU_PROPRIETE =      _T("&Propri�t�s");
static const wxString RS_MENU_PROPRIETE_INFO = _T("Propri�t�s du projet");
static const wxString RS_MENU_CONFIGURATION =    _T("&Options");
static const wxString RS_MENU_CONFIGURATION_INFO= _T("Pr�f�rences Abita+");
static const wxString RS_MENU_SOLUTION  =      _T("&Solution");
static const wxString RS_MENU_SOLUTION_INFO =  _T("Lancer la solution");
static const wxString RS_MENU_VISUALISER  =    _T("&Visualiser");
static const wxString RS_MENU_VISUALISER_INFO =_T("Visualiser la solution");
static const wxString RS_MENU_VISUALISER3D  =    _T("Visualiser &3D");
static const wxString RS_MENU_VISUALISER3D_INFO= _T("Visualiser la solution en 3D");
// menu aide
static const wxString RS_MENU_SHOWTIPS  =      _T("&Voir les tips");
static const wxString RS_MENU_SHOWTIPS_INFO =  _T("Tips");
static const wxString RS_MENU_AIDE    =        _T("&Aide\tF1");
static const wxString RS_MENU_AIDE_INFO=       _T("Aide d'Abita+");
static const wxString RS_MENU_ABOUT  =         _T("A &propos");
static const wxString RS_MENU_ABOUT_INFO  =    _T("Informations sur Abita+");
// menu view et toolbar  V
static const wxString RS_MENU_ZOOM_IN    =         _T("Zoom &+");
static const wxString RS_MENU_ZOOM_IN_INFO =       _T("Zoom +");
static const wxString RS_MENU_ZOOM_OUT    =        _T("Zoom &-");
static const wxString RS_MENU_ZOOM_OUT_INFO  =     _T("Zoom -");
static const wxString RS_MENU_ZOOM_RESET     =     _T("Zoom &0");
static const wxString RS_MENU_ZOOM_RESET_INFO =    _T("Zoom 0");
static const wxString RS_MENU_FOND       =         _T("&Image en fond d'�cran");
static const wxString RS_MENU_FOND_INFO   =        _T("Ins�rer une image en fond d'�cran");
static const wxString RS_MENU_GRID       =         _T("&Grille");
static const wxString RS_MENU_GRID_INFO   =        _T("Suivre la grille");
//menu draw et toolbar  V
static const wxString RS_MENU_UNDO              =  _T("&Annuler");
static const wxString RS_MENU_REDO              =  _T("&R�p�ter ");
static const wxString RS_MENU_DRAW_NORMAL       =  _T("Mode: &normal");
static const wxString RS_MENU_DRAW_NORMAL_INFO   = _T("Revenir au mode normal");
static const wxString RS_MENU_DRAW_CONTOUR  =      _T("Mode: &contour");
static const wxString RS_MENU_DRAW_CONTOUR_INFO =  _T("Mode contour");
static const wxString RS_MENU_DRAW_STRUCTURE  =    _T("Mode: &structure");
static const wxString RS_MENU_DRAW_STRUCTURE_INFO= _T("Mode structure");
static const wxString RS_MENU_MESURE =              _T("Mode: &Mesure");
static const wxString RS_MENU_MESURE_INFO   =        _T("Mesurer");
static const wxString RS_MENU_DEPLACER =           _T("Edition: &D�placer");
static const wxString RS_MENU_DEPLACER_INFO   =        _T("D�placer un point");
static const wxString RS_MENU_SUPPRIMER =          _T("Edition: Su&pprimer");
static const wxString RS_MENU_SUPPRIMER_INFO   =      _T("Effacer un �lement");
static const wxString RS_MENU_ETAGE_ADD       =        _T("A&jouter �tage");
static const wxString RS_MENU_ETAGE_ADD_INFO   =       _T("Ajouter �tage");
static const wxString RS_MENU_ETAGE_SUP       =        _T("S&upprimer �tage");
static const wxString RS_MENU_ETAGE_SUP_INFO   =       _T("Supprimer �tage");
static const wxString RS_MENU_ELEMENT_LIBRE =       _T("El�ments: &libres");
static const wxString RS_MENU_ELEMENT_LIBRE_INFO=   _T("D�finition des �l�ments libres");
static const wxString RS_MENU_ELEMENT_COMMUN_POSSIBLE = _T("El�ments: communs &possibles");
static const wxString RS_MENU_ELEMENT_COMMUN_POSSIBLE_INFO=   _T("D�finition des �l�ments communs possibles");
static const wxString RS_MENU_ELEMENT_COMMUN_IMPOSE = _T("El�ments: communs &impos�s");
static const wxString RS_MENU_ELEMENT_COMMUN_IMPOSE_INFO= _T("D�finition des �l�ments communs impos�s");
static const wxString RS_MENU_ELEMENT_SORTIE = _T("El�ments: entr�e/&sortie");
static const wxString RS_MENU_ELEMENT_SORTIE_INFO = _T("D�finition des �l�ments d'entr�e/sortie");

// Toolbar
static const wxString RS_TOOLBAR_NOUVEAU  =        _T("Nouveau");
static const wxString RS_TOOLBAR_CHARGER  =        _T("Ouvrir");
static const wxString RS_TOOLBAR_SAUVER   =        _T("Sauver");
static const wxString RS_TOOLBAR_IMPRIMER  =       _T("Imprimer");
static const wxString RS_TOOLBAR_PROPRIETE   =     _T("Propri�t�s");
static const wxString RS_TOOLBAR_CONFIGURATION=    _T("Config.");
static const wxString RS_TOOLBAR_SOLUTION   =      _T("Solution");
static const wxString RS_TOOLBAR_VISUALISER  =     _T("Visualiser");
static const wxString RS_TOOLBAR_AIDE       =      _T("Aide");

static const wxString RS_TOOLBAR_DRAW_NORMAL =     _T("Normal");
static const wxString RS_TOOLBAR_DRAW_CONTOUR =    _T("Contours");
static const wxString RS_TOOLBAR_MESURE        =    _T("Mesure");
static const wxString RS_TOOLBAR_DRAW_STRUCTURE=   _T("Structures");
static const wxString RS_TOOLBAR_DEPLACER =        _T("D�placer");
static const wxString RS_TOOLBAR_DEPLACER_INFO =   _T("D�placer");
static const wxString RS_TOOLBAR_SUPPRIMER =       _T("Supprimer");
static const wxString RS_TOOLBAR_SUPPRIMER_INFO =  _T("Supprimer");
static const wxString RS_TOOLBAR_ETAGE_ADD       =     _T("+Etage");
static const wxString RS_TOOLBAR_ETAGE_SUP       =     _T("-Etage");
static const wxString RS_TOOLBAR_FOND       =      _T("+ Image");
static const wxString RS_TOOLBAR_GRID       =      _T("Grille");
static const wxString RS_TOOLBAR_ZOOM_RESET =      _T("Zoom 0");
static const wxString RS_TOOLBAR_ZOOM_IN =         _T("Zoom +");
static const wxString RS_TOOLBAR_ZOOM_OUT =        _T("Zoom -");
static const wxString RS_TOOLBAR_ELEMENT_LIBRE =   _T("Libres");
static const wxString RS_TOOLBAR_ELEMENT_COMMUN_POSSIBLE =     _T("Communs possibles");
static const wxString RS_TOOLBAR_ELEMENT_COMMUN_IMPOSE =    _T("Communs impos�s");
static const wxString RS_TOOLBAR_ELEMENT_SORTIE =   _T("Entr�es/sorties");

// About Dialog
static const wxString RS_ABOUT_TITLE   =           _T("A propos d'Abita+");
static const wxString RS_ABOUT_COPYRIGHT   =       _T("Protection des fichiers :\n"
        "Conform�ment aux dispositions de la loi n� 98-536 du 1er juillet 1998, portant transposition dans le code de la propri�t� intellectuelle de la \n"
        "directive 96/9/CE du 11 mars 1996, concernant la protection juridique des bases de donn�es, Keris sarl est producteur et propri�taire de \n"
        "tout ou partie des bases de donn�es composant le pr�sent logiciel. En acc�dant au pr�sent logiciel, vous reconnaissez que les donn�es \n"
        "le composant sont l�galement prot�g�es, et, conform�ment aux dispositions de la loi du 1er juillet 1998 pr�cit�e, vous vous interdisez \n"
        "notamment d'extraire, r�utiliser, stocker, reproduire, repr�senter ou conserver, directement ou indirectement, sur tout type de support, \n"
        "par tout moyen et sous toute forme que ce soit, tout ou partie qualitativement ou quantitativement substantielle, du contenu des \n"
        "bases de donn�es figurant au site auquel vous acc�dez.\n"
        "\n"
        "Abita+ n'autorise ses utilisateurs � copier �lectroniquement et � imprimer sur support papier ces �l�ments que dans le seul but de pr�parer \n"
        "leurs etudes ��architecturales��. Toute autre utilisation d'�l�ments du logiciel Abita+, y compris la reproduction dans des buts autres que \n"
        "ceux susmentionn�s, la modification, la diffusion ou la re-publication, sans l'autorisation �crite pr�alable d�Abita+, est strictement \n"
        "interdite et constitutive d'une contrefa�on sanctionn�e p�nalement.\n"
        "\n"
        "Marques\n"
        "Les marques Abita+ et tout autre produit ou service d�Abita+ r�f�renc�s sur le logiciel Abita+ sont des marques commerciales, ou des \n"
        "marques d�pos�es de Keris sarl ., en France et dans d'autres pays. Les autres noms de produits ou d'entreprises mentionn�s sur le site \n"
        "Abita+ peuvent �tre des marques commerciales ou marques d�pos�es appartenant � des tiers et prot�g�es � ce titre par le droit de la \n"
        "propri�t� intellectuelle.");

// Preferences Dialog
static const wxString RS_PREFERENCES_TITLE =       _T("Pr�ferences d'Abita+");
static const wxString RS_PREFERENCES_TEXTE_TIPS=   _T("Voir les tips au d�marage");
static const wxString RS_PREFERENCES_TAILLE_GRILLE = _T("Taille de la grille (en m�tres)");
static const wxString RS_PREFERENCES_SOLVER         = _T("Solveur:");
static const wxString RS_PREFERENCES_A1   =           _T("A1:");
static const wxString RS_PREFERENCES_A2 =             _T("A2:");
static const wxString RS_PREFERENCES_A3 =             _T("A3:");
static const wxString RS_PREFERENCES_A4 =            _T("A4:");

// proprietes dialog
static const wxString RS_PROPRIETE_TITLE   =       _T("Propri�t�s du projet");
static const wxString RS_PROPRIETE_SURFACE_TITRE =   _T("Surface de dessin");
static const wxString RS_PROPRIETE_LONGUEUR =        _T("Longueur");
static const wxString RS_PROPRIETE_LARGEUR =         _T("Largeur");
static const wxString RS_PROPRIETE_TYPOLOGIE  =      _T("Typologie des logements:");
static const wxString RS_PROPRIETE_UNITE  =          _T("m");
static const wxString RS_PROPRIETE_TYPE =             _T("Type");
static const wxString RS_PROPRIETE_T1 =               _T("T1");
static const wxString RS_PROPRIETE_T2 =               _T("T2");
static const wxString RS_PROPRIETE_T3 =               _T("T3");
static const wxString RS_PROPRIETE_T4 =               _T("T4");
static const wxString RS_PROPRIETE_T5 =               _T("T5");
static const wxString RS_PROPRIETE_VALEURM2 =         _T("Valeur m�");
static const wxString RS_PROPRIETE_AIREMINI =         _T("Aire mini");
static const wxString RS_PROPRIETE_AIREMAXI =         _T("Aire maxi");
static const wxString RS_PROPRIETE_QTEMINI =          _T("Qt� mini");
static const wxString RS_PROPRIETE_QTEMAXI =          _T("Qt� maxi");
static const wxString RS_PROPRIETES_ANNOTATIONS =     _T("Annotations:");

// dialog visu
static const wxString RS_DIALOG_VISU_IMPRIMER = _T("Imprimer les r�sultats");
static const wxString RS_DIALOG_VISU_EXPORTER = _T("Exporter les r�sultats");
static const wxString RS_DIALOG_VISU_INFOS_LOT = _T("%s / %.2f m� / valeur : %.2f");
static const wxString RS_DIALOG_VISU_TYPE_COMMUN = _T("Communs");
static const wxString RS_DIALOG_VISU_COLONNE_SOLUTION = _T("Solution");
static const wxString RS_DIALOG_VISU_COLONNE_VALEUR = _T("Valeur");
static const wxString RS_INFORMATIONS_TYPE  =       _T("Types d'appartements");
static const wxString RS_DIALOG_VISU_COLONNE_TOTAL = _T("Total");

// dialog de gestion des fichiers

static const wxString RS_FILE_DIALOG_WARNING  =       _T("Attention !\n Etes vous sur de vouloir quitter le travail en cours ?");
static const wxString RS_FILE_DIALOG_OPEN_TITLE  =    _T("Choisissez le fichier � charger");
static const wxString RS_FILE_DIALOG_SAVE_TITLE  =    _T("Choisissez le fichier � sauver");
static const wxString RS_FILE_DIALOG_BITMAP_ERREUR =  _T("Impossible de charger le fichier d'image. \nAbita+ ne peut lire que les types suivants de fichiers :\nBMP,PNG,JPEG,GIF,TIFF,PCX,PNM,XPM");
static const wxString RS_FILE_DIALOG_BITMAP_CHOIX =   _T("Changement de l'image de fond d'�cran:\nQue voulez vous faire ?"); 
static const wxStringList RS_FILE_DIALOG_BITMAP_CHOIX_BUTTON = wxStringList(wxT("Effacer"),
                                                              wxT("Remplacer"),
                                                              wxT("Annuler"),
                                                              NULL);
static const wxString RS_FILE_DIALOG_OPEN_WILDCARD  = _T("Tous (*.*)|*.*");
static const wxString RS_FILE_DIALOG_TAILLE_M       = _T("D�finissez la taille en metres de votre image (sur l'Axe X)");
static const wxString RS_FILE_DIALOG_TAILLE_M_TITRE  = _T("Taille ?");
// Notebook
static const wxString RS_ETAGE         =           _T("Etage");
static const wxString RS_ETAGE_DIALOG_ADD =           _T("Voulez vous ajouter un �tage :\nAvant la s�lection courante\nApr�s la s�lection courante\nApr�s le dernier �tage ?");
static const wxStringList RS_ETAGE_DIALOG_ADD_CHOIX_BUTTON = wxStringList(wxT("Avant"),
                                                            wxT("Apr�s"),
                                                            wxT("A la fin"),
                                                            wxT("Annuler"),
                                                            NULL);
static const wxString RS_ETAGE_DIALOG_SUP =           _T("Etes vous sur de vouloir supprimer cet �tage ?");
static const wxString RS_ETAGE_DIALOG_IMPOSSIBLE_SUP =_T("Impossible de supprimer\nIl doit toujours rester un �tage");

// dialog compute
static const wxString RS_DIALOG_COMPUTE_TITLE =       _T("Calcul des solutions en cours...");
static const wxString RS_DIALOG_SOLUTION_TITLE =  _T("Visualisation");
static const wxString RS_DIALOG_WAIT_SOLUTION_TEXT1  = _T("Visualisation du calul");
static const wxString RS_DIALOG_WAIT_SOLUTION_TEXT2  = _T("Calcul des solutions en cours, it�ration : ");
// Statusbar
static const wxString RS_TEXTE_STATUSBAR_WELCOME=  _T("Bienvenue dans Abita+...");

static const wxString RS_CANVAS_ECHELLE = _T("Distance = %d m");

static const wxString RS_MODECREATE_DISTANCE        = _T("Longueur : %.2f m");

static const wxString RS_EDITCELS_TITRE =             _T("Edition de \nla cellule:");
static const wxString RS_VIEW_INFORMATIONS =          _T("Aire : %.2f m� / Perim�tre : %.2f m");

//-------------------------------------------------

#endif
