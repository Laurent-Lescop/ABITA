///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Source code for "Radix Sort Revisited"
// (C) 2000, Pierre Terdiman (p.terdiman@wanadoo.fr)
//
// Works with IEEE floats only.
// Version is 1.1.
//
// This is my new radix routine:
//				- it uses indices and doesn't recopy the values anymore, hence wasting less ram
//				- it creates all the histograms in one run instead of four
//				- it sorts words faster than dwords and bytes faster than words
//				- it correctly sorts negative floats by patching the offsets
//				- it automatically takes advantage of temporal coherence
//				- multiple keys support is a side effect of temporal coherence
//				- it may be worth recoding in asm...
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef __RADIXSORT_H__
#define __RADIXSORT_H__

	#define null				0														//!<	our own NULL pointer

	// New types
	typedef signed char			sbyte;		//!<	sizeof(sbyte)	must be 1
	typedef unsigned char		ubyte;		//!<	sizeof(ubyte)	must be 1
	typedef signed short		sword;		//!<	sizeof(sword)	must be 2
	typedef unsigned short		uword;		//!<	sizeof(uword)	must be 2
	typedef signed int			sdword;		//!<	sizeof(sdword)	must be 4
	typedef unsigned int		udword;		//!<	sizeof(udword)	must be 4
	typedef signed __int64		sqword;		//!<	sizeof(sqword)	must be 8
	typedef unsigned __int64	uqword;		//!<	sizeof(uqword)	must be 8
	typedef float				float32;	//!<	sizeof(float32)	must be 4
	typedef double				float64;	//!<	sizeof(float64)	must be 4

#define ICE_COMPILE_TIME_ASSERT(name, x)	typedef int ICE_Dummy_ ## name[(x) * 2 - 1]

	ICE_COMPILE_TIME_ASSERT(ubyte,	sizeof(ubyte)==1);
	ICE_COMPILE_TIME_ASSERT(sbyte,	sizeof(sbyte)==1);
	ICE_COMPILE_TIME_ASSERT(sword,	sizeof(sword)==2);
	ICE_COMPILE_TIME_ASSERT(uword,	sizeof(uword)==2);
	ICE_COMPILE_TIME_ASSERT(udword,	sizeof(udword)==4);
	ICE_COMPILE_TIME_ASSERT(sdword,	sizeof(sdword)==4);
	ICE_COMPILE_TIME_ASSERT(uqword,	sizeof(uqword)==8);
	ICE_COMPILE_TIME_ASSERT(sqword,	sizeof(sqword)==8);

#undef ICE_COMPILE_TIME_ASSERT

  // Prevent nasty user-manipulations (strategy borrowed from Charles Bloom)
	#define PREVENT_COPY(curclass)	private: curclass(const curclass& object);	curclass& operator=(const curclass& object);

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//
	//																			Class RadixSorter
	//
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	#define RADIX_LOCAL_RAM
  #define inline_ __forceinline

	class RadixSorter
	{
		public:
		// Constructor/Destructor
								RadixSorter();
								~RadixSorter();
		// Sorting methods
    inline_ RadixSorter& Sort(const unsigned* input, udword nb) { return Sort(input, nb, false); };
    inline_ RadixSorter& Sort(const int* input, udword nb) { return Sort(reinterpret_cast<const udword*>(input), nb, true); };

				RadixSorter&		Sort(const udword* input, udword nb, bool signedvalues);
				RadixSorter&		Sort(const float* input, udword nb);

		//! Access to results. mRanks is a list of indices in sorted order, i.e. in the order you may further process your data
		inline_	udword*			GetIndices()			const	{ return mRanks;		}

		//! mIndices2 gets trashed on calling the sort routine, but otherwise you can recycle it the way you want.
		inline_	udword*			GetRecyclable()		const	{ return mRanks2;		}

		// Stats
				udword			GetUsedRam()		const;
		//! Returns the total number of calls to the radix sorter.
		inline_	udword			GetNbTotalCalls()	const	{ return mTotalCalls;	}
		//! Returns the number of premature exits due to temporal coherence.
		inline_	udword			GetNbHits()			const	{ return mNbHits;		}

								PREVENT_COPY(RadixSorter)
		private:
#ifndef RADIX_LOCAL_RAM
				udword*			mHistogram;			//!< Counters for each byte
				udword*			mOffset;			//!< Offsets (nearly a cumulative distribution function)
#endif
				udword			mCurrentSize;		//!< Current size of the indices list
				udword*			mRanks;				//!< Two lists, swapped each pass
				udword*			mRanks2;
		// Stats
				udword			mTotalCalls;
				udword			mNbHits;
		// Internal methods
				void			CheckResize(udword nb);
				bool			Resize(udword nb);
	};

#endif // __RADIXSORT_H__
