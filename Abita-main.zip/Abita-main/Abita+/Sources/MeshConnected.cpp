#include "precompiled.h"
#include "MeshConnected.h"

#include <algorithm>
#include <crtdbg.h>
#include <boost/cast.hpp>

#include "MeshConnected_algorithms.h"

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

ConnectedElement::ConnectedElement(ConnectedElement const& src)
: _up_cnx(src._up_cnx),
  _down_cnx(src._down_cnx),
  _data(src._data)
{
  //?! _data = (src._data.get() == NULL) ? data_ptr_t((data_t*)NULL) : data_ptr_t(src._data->clone());
}

//----------------------------------------------------------------------------

ConnectedElement& ConnectedElement::operator=(ConnectedElement const& src)
{
  if (&src == this)
    return (*this);
  _up_cnx = src._up_cnx;
  _down_cnx = src._down_cnx;
  _data = src._data; //?! (src._data.get() == NULL) ? data_ptr_t((data_t*)NULL) : data_ptr_t(src._data->clone());
  return (*this);
}

//----------------------------------------------------------------------------

void ConnectedElement::add_up_reference(handle element)
{
  _up_cnx.push_back(element);
}

//----------------------------------------------------------------------------

void ConnectedElement::add_down_reference(handle element)
{
  _down_cnx.push_back(element);
}

//----------------------------------------------------------------------------

void ConnectedElement::remove_up_reference(handle element)
{
  iterator it = std::find(_up_cnx.begin(), _up_cnx.end(), element);
  if (it != _up_cnx.end())
    _up_cnx.erase(it);
}

//----------------------------------------------------------------------------

void ConnectedElement::remove_down_reference(handle element)
{
  iterator it = std::find(_down_cnx.begin(), _down_cnx.end(), element);
  if (it != _down_cnx.end())
    _down_cnx.erase(it);
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

unsigned ElementLayer::generate_magic_value()
{
  unsigned result = m_current_magic_value;
  ++m_current_magic_value;
  if (m_current_magic_value > ConnectedElement::handle::MAX_MAGIC_VALUE)
    m_current_magic_value = 1;
  return result;
}

ElementLayer::const_iterator ElementLayer::begin() const
{
  const_iterator::policies_type policies(m_elements_magic, m_elements);
  return const_iterator(0, policies);
}

ElementLayer::const_iterator ElementLayer::end() const
{
  const_iterator::policies_type policies(m_elements_magic, m_elements);
  return const_iterator(m_elements.size(), policies);
}

//----------------------------------------------------------------------------

ConnectedElement::handle ElementLayer::alloc()
{
  if (m_free_elements.empty())
  {
    unsigned index = m_elements.size();
    m_elements.push_back( ConnectedElement() );
    m_elements_magic.push_back( generate_magic_value() );
    return ConnectedElement::handle( index, m_elements_magic[index] );
  }
  else
  {
    unsigned free_index = m_free_elements.back();
    _ASSERT( m_elements_magic[free_index] == 0 );
    
    unsigned magic = generate_magic_value();
    ConnectedElement::handle h = ConnectedElement::handle(free_index, magic);
    // should be :: new (&m_elements[h]) ConnectedElement;
    // instead, it is already constructed...

    m_free_elements.pop_back();
    m_elements_magic[free_index] = magic;
    return h;
  }
}

//----------------------------------------------------------------------------

void ElementLayer::free( ConnectedElement::handle h )
{
#ifdef _DEBUG
  {
    char buffer[MAX_PATH+1];
    sprintf(buffer, "ElementLayer::free - this=%p - handle=%8.8x\r\n", this, h.bits);
    OutputDebugString(buffer);
  }
#endif

  // should be :: m_elements[h].~ConnectedElement(); but causes problems with ~vector

  unsigned index = h.index;
  if (h.magic == m_elements_magic[index] && h.magic != 0)
  {
    m_elements[index].~ConnectedElement();
    new (&m_elements[index]) ConnectedElement;

    m_free_elements.push_back(index);
    m_elements_magic[index] = 0;
  }
}

//----------------------------------------------------------------------------

void ElementLayer::destroy(ConnectedElement::handle h, DestroyPolicy policy)
{
  std::vector<ConnectedElement::handle> up_refs;
  {
    ConnectedElement& element = get_element(h);

    if (policy == DESTROY_DANGLING)
    {
      if (element.has_up_references() && m_upper_layer!=NULL)
      {
        ConnectedElement::const_iterator it   = element.begin_up_references();
        ConnectedElement::const_iterator end  = element.end_up_references();
        while (it != end)
        {
          up_refs.push_back(*it);
          ++it;
        }
      }
    }

    if (element.has_down_references() && m_lower_layer!=NULL)
    {
      std::vector<ConnectedElement::handle> handle_copy;
      ConnectedElement::const_iterator it   = element.begin_down_references();
      ConnectedElement::const_iterator end  = element.end_down_references();
      while (it != end)
      {
        handle_copy.push_back(*it);
        ++it;
      }
      deconnect(h);

      unsigned const num_dependents = handle_copy.size();
      for (unsigned i=0; i<num_dependents; i++)
      {
        m_lower_layer->destroy( handle_copy[i], policy );
      }
    }
    else
    {
      deconnect(h);
    }
  }

  unsigned const num_dependents = up_refs.size();
  for (unsigned i=0; i<num_dependents; i++)
  {
    ConnectedElement& up_element = m_upper_layer->get_element(up_refs[i]);
    if (!up_element.has_down_references())
      m_upper_layer->destroy( up_refs[i], policy );
  }
  
  free(h);
}

//----------------------------------------------------------------------------

void ElementLayer::connect_up(ConnectedElement::handle h_element, ConnectedElement::handle h_up_element)
{
  if (m_upper_layer == NULL)
    return;

  ConnectedElement& element = get_element(h_element);
  ConnectedElement& up_element = m_upper_layer->get_element(h_up_element);

  element.add_up_reference(h_up_element);
  up_element.add_down_reference(h_element);
}

//----------------------------------------------------------------------------

void ElementLayer::connect_down(ConnectedElement::handle h_element, ConnectedElement::handle h_down_element)
{
  if (m_lower_layer == NULL)
    return;

  ConnectedElement& element = get_element(h_element);
  ConnectedElement& down_element = m_upper_layer->get_element(h_down_element);

  element.add_down_reference(h_down_element);
  down_element.add_up_reference(h_element);
}

//----------------------------------------------------------------------------

void ElementLayer::deconnect(ConnectedElement::handle h_element)
{
  ConnectedElement& element = get_element(h_element);

  if (element.has_up_references() && m_upper_layer != NULL)
  {
    ConnectedElement::const_iterator it   = element.begin_up_references();
    ConnectedElement::const_iterator end  = element.end_up_references();
    while (it != end)
    {
      ConnectedElement& up_element = m_upper_layer->get_element(*it);
      up_element.remove_down_reference(h_element);
      ++it;
    }
    element.reset_up_references();
  }

  if (element.has_down_references() && m_lower_layer != NULL)
  {
    ConnectedElement::const_iterator it   = element.begin_down_references();
    ConnectedElement::const_iterator end  = element.end_down_references();
    while (it != end)
    {
      ConnectedElement& down_element = m_lower_layer->get_element(*it);
      down_element.remove_up_reference(h_element);
      ++it;
    }
    element.reset_down_references();
  }
}

//----------------------------------------------------------------------------

void ElementLayer::depends_on(ElementLayer* upper_layer)
{
  m_upper_layer = upper_layer;
  upper_layer->m_lower_layer = this;
}

//----------------------------------------------------------------------------

void ElementLayer::display()
{
  //for (unsigned i=0; i<m_elements.size(); i++)
  //{
  //  if (m_elements_in_use[i])
  //  {
  //    ConnectedElement& element = get_element(i);

  //    std::cout << "[" << i << ";";

  //    if (element.has_up_references() && m_upper_layer != NULL)
  //    {
  //      ConnectedElement::const_iterator it   = element.begin_up_references();
  //      ConnectedElement::const_iterator end  = element.end_up_references();
  //      while (it != end)
  //      {
  //        std::cout << *it;
  //        ++it;
  //        if (it != end)
  //          std::cout << "-";
  //      }
  //    }

  //    std::cout << ";";

  //    if (element.has_down_references() && m_lower_layer != NULL)
  //    {
  //      ConnectedElement::const_iterator it   = element.begin_down_references();
  //      ConnectedElement::const_iterator end  = element.end_down_references();
  //      while (it != end)
  //      {
  //        std::cout << *it;
  //        ++it;
  //        if (it != end)
  //          std::cout << "-";
  //      }
  //    }

  //    std::cout << "]" << std::endl;
  //  }
  //}
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

/*static*/ const ConnectedElement::handle MeshConnected::INVALID_HANDLE;

std::auto_ptr<MeshConnected::VertexData> MeshConnected::VertexData::clone() const
{
  std::auto_ptr<VertexData> res( new VertexData );
  res->position = position;
  return res;
}

//----------------------------------------------------------------------------

std::auto_ptr<MeshConnected::PolygonData> MeshConnected::PolygonData::clone() const
{
  std::auto_ptr<PolygonData> res( new PolygonData );
  res->m_type = m_type;
  return res;
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

MeshConnected::MeshConnected()
{
  m_edges.depends_on( &m_vertices );
  m_polygons.depends_on( &m_edges );
}

//----------------------------------------------------------------------------

MeshConnected::MeshConnected(MeshConnected const& src)
: m_vertices( src.m_vertices ),
  m_edges( src.m_edges ),
  m_polygons( src.m_polygons )
{
  m_edges.depends_on( &m_vertices );
  m_polygons.depends_on( &m_edges );
}

//----------------------------------------------------------------------------

MeshConnected::VertexHandle MeshConnected::createVertex( std::auto_ptr<VertexData> data/*= std::auto_ptr<VertexData>()*/ )
{
  VertexHandle handle;
  _VertexDataPtr vdata;
  alloc_vertex(handle, vdata);
  vdata->user_data = data;

#ifdef _DEBUG
  {
    char buffer[MAX_PATH+1];
    sprintf(buffer, "createVertex:: handle=%8.8x\r\n", ConnectedElement::handle(handle).bits);
    OutputDebugString(buffer);
  }
#endif

  return handle;
}

//----------------------------------------------------------------------------

MeshConnected::EdgeHandle MeshConnected::createEdge( VertexHandle va, VertexHandle vb )
{
  EdgeHandle handle = findEdge(va, vb);
  
  if (handle == INVALID_HANDLE)
  {
    handle = m_edges.alloc();
    m_edges.connect_up(handle, va);
    m_edges.connect_up(handle, vb);
  }

  return handle;
}



//----------------------------------------------------------------------------

MeshConnected::PolygonHandle MeshConnected::createPolygon(std::vector<VertexHandle> const& _vertices,
                                                          std::auto_ptr<PolygonData> data/*=std::auto_ptr<PolygonData>()*/ )
{
  std::vector<VertexHandle> vertices = _vertices;
  unsigned const numVertices = vertices.size();

  //- fix the orientation
  {
    float area = 0;
    MeshConnected::VertexData *vh = getVertexData( vertices.back() );
    Point2d pt1 = vh->position;
    for(unsigned i=0; i<numVertices; i++)
    {
      MeshConnected::VertexData *vh = getVertexData( vertices[i] );
      Point2d pt2 = vh->position;

      Point2d delta = pt2 - pt1;

      area      += pt1.x * pt2.y - pt2.x * pt1.y;
      pt1 = pt2;
    }

    if (area < 0)
    {
      std::reverse( vertices.begin(), vertices.end() );
    }
  }
  //

  _ASSERT( numVertices > 2 );

  PolygonHandle handle;
  _PolygonDataPtr polygonData;
  alloc_polygon(handle, polygonData);

  polygonData->h_vert = vertices;
  polygonData->user_data = data;

  m_polygons.connect_up( handle, createEdge( vertices[numVertices-1], vertices[0] ) );
  for (unsigned v=0; v<numVertices-1; v++)
  {
    m_polygons.connect_up(handle, createEdge(vertices[v], vertices[v+1]));
  }

#ifdef _DEBUG
  {
    float area, perimeter;
    computePolygonArea(*this, handle, area, perimeter);
    _ASSERT( area >= 0 );
  }
#endif

  return handle;
}

//----------------------------------------------------------------------------

MeshConnected::EdgeHandle MeshConnected::findEdge( VertexHandle hva, VertexHandle hvb ) const
{
  ConnectedElement const& va = m_vertices.get_element(hva);
  ConnectedElement::const_iterator edge_it = va.begin_down_references();
  ConnectedElement::const_iterator edge_end = va.end_down_references();
  while (edge_it != edge_end)
  {
    ConnectedElement const& edge = m_edges.get_element(*edge_it);

    _ASSERT( edge.up_references_size() == 2 );

    ConnectedElement::const_iterator edge_vert_it = edge.begin_up_references();
    if (*edge_vert_it == hvb)
      return *edge_it;

    ConnectedElement::const_iterator edge_other_vert_it = edge_vert_it+1;
    if (*edge_other_vert_it == hvb)
      return *edge_it;

    ++edge_it;
  }
  return INVALID_HANDLE;
}

//----------------------------------------------------------------------------
  
void MeshConnected::findVertices( EdgeHandle eh, VertexHandle vertices[2] ) const
{
  EdgeLayer::element_t const& edge = m_edges.get_element(eh);
  _ASSERT( edge.up_references_size() == 2 );
  ConnectedElement::const_iterator it = edge.begin_up_references();
  vertices[0] = *(it++);
  vertices[1] = *(it++);
}

//----------------------------------------------------------------------------

  void MeshConnected::findVertices( PolygonHandle th, std::vector<VertexHandle>& result ) const
{
  PolygonLayer::element_t const& polygon = m_polygons.get_element(th);
  
  _ASSERT( polygon.up_references_size() >= 3 );

  _PolygonData* tdata = get_polygon_data(polygon);

  result = tdata->h_vert;
}

//----------------------------------------------------------------------------

void MeshConnected::findEdges( PolygonHandle th, std::vector<EdgeHandle>& result ) const
{
  PolygonLayer::element_t const& polygon = m_polygons.get_element(th);
  
  _ASSERT( polygon.up_references_size() >= 3 );

  result.resize(0);

  ConnectedElement::const_iterator edge_it = polygon.begin_up_references();
  ConnectedElement::const_iterator edge_end = polygon.end_up_references();
  while (edge_it != edge_end)
  {
    result.push_back( *edge_it );
    ++edge_it;
  }
}

//----------------------------------------------------------------------------

void MeshConnected::findAdjacentEdges( VertexHandle hv, std::vector<EdgeHandle>& edges ) const
{
  ConnectedElement const& vertex = m_vertices.get_element(hv);

  ConnectedElement::const_iterator it   = vertex.begin_down_references();
  ConnectedElement::const_iterator end  = vertex.end_down_references();
  while (it != end)
  {
    edges.push_back( *it );
    ++it;
  }
}

//----------------------------------------------------------------------------

void MeshConnected::findAdjacentPolygons( VertexHandle hv, std::vector<PolygonHandle>& polygons ) const
{
  ConnectedElement const& vertex = m_vertices.get_element(hv);

  unsigned startResultIndex = polygons.size();

  ConnectedElement::const_iterator it   = vertex.begin_down_references();
  ConnectedElement::const_iterator end  = vertex.end_down_references();
  while (it != end)
  {
    findAdjacentPolygons( EdgeHandle(*it), polygons );
    ++it;
  }

  std::sort( polygons.begin() + startResultIndex, polygons.end() );
  std::vector<PolygonHandle>::iterator new_end = std::unique( polygons.begin() + startResultIndex, polygons.end() );
  polygons.erase( new_end, polygons.end() );
}

//----------------------------------------------------------------------------

void MeshConnected::findAdjacentPolygons( EdgeHandle he, std::vector<PolygonHandle>& polygons ) const
{
  ConnectedElement const& edge = m_edges.get_element(he);
  polygons.insert(polygons.end(), edge.begin_down_references(), edge.end_down_references());
}

//----------------------------------------------------------------------------

void MeshConnected::detachEdge(EdgeHandle eh)
{
  m_edges.destroy(eh, ElementLayer::DESTROY_DOWN_ONLY);
}

//----------------------------------------------------------------------------

void MeshConnected::detachPolygon(PolygonHandle th)
{
  m_polygons.destroy(th, ElementLayer::DESTROY_DOWN_ONLY);
}

//----------------------------------------------------------------------------

void MeshConnected::eraseEdge(EdgeHandle eh)
{
#ifdef _DEBUG
  OutputDebugString("eraseEdge\r\n");
#endif
  m_edges.destroy(eh, ElementLayer::DESTROY_DANGLING);
}

void MeshConnected::erasePolygon(PolygonHandle th)
{
#ifdef _DEBUG
  OutputDebugString("erasePolygon\r\n");
#endif
  m_polygons.destroy(th, ElementLayer::DESTROY_DANGLING);
}

void MeshConnected::eraseVertex(VertexHandle vh)
{
#ifdef _DEBUG
  OutputDebugString("eraseVertex\r\n");
#endif
  m_vertices.destroy(vh, ElementLayer::DESTROY_DANGLING);
}

//----------------------------------------------------------------------------

MeshConnected::VertexData* MeshConnected::getVertexData( VertexHandle h ) const
{
  VertexLayer::element_t const& vertex = m_vertices.get_element(h);
  _VertexData* tdata = get_vertex_data(vertex);
  return tdata->user_data.get();
}

//----------------------------------------------------------------------------

MeshConnected::PolygonData* MeshConnected::getPolygonData( PolygonHandle h ) const
{
  PolygonLayer::element_t const& polygon = m_polygons.get_element(h);
  _PolygonData* tdata = get_polygon_data(polygon);
  return tdata->user_data.get();
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

void MeshConnected::alloc_vertex( VertexHandle& handle, _VertexDataPtr& vertex_data )
{
  handle = m_vertices.alloc();

  VertexLayer::element_t& vertex = m_vertices.get_element(handle);
  vertex_data = _VertexDataPtr( new _VertexData );
  vertex.set_data( vertex_data );
}

//----------------------------------------------------------------------------

MeshConnected::_VertexData* MeshConnected::get_vertex_data( VertexLayer::element_t const& vertex ) const
{
  return boost::polymorphic_downcast<_VertexData*>( vertex.data().get() );
}

//----------------------------------------------------------------------------

void MeshConnected::alloc_polygon( PolygonHandle& handle,
                                    _PolygonDataPtr& tri_data )
{
  handle = m_polygons.alloc();

  PolygonLayer::element_t& polygon = m_polygons.get_element(handle);
  tri_data = _PolygonDataPtr( new _PolygonData );
  polygon.set_data( tri_data );
}

//----------------------------------------------------------------------------

MeshConnected::_PolygonData* MeshConnected::get_polygon_data( PolygonLayer::element_t const& polygon ) const
{
  return boost::polymorphic_downcast<_PolygonData*>( polygon.data().get() );
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

void MeshConnected::display()
{
  //std::cout << "** vertices" << std::endl;
  //m_vertices.display();

  //std::cout << "** edges" << std::endl;
  //m_edges.display();

  //std::cout << "** polygons" << std::endl;
  //m_polygons.display();
}
