#ifndef ABITA_INPUT_MODE_H
#define ABITA_INPUT_MODE_H

class CanvasDraw;

//----------------------------------------------------------------------------
/*!
  Base class for all input modes
*/
class InputMode
{
public:
  virtual ~InputMode() {};

  virtual void OnEvent(wxMouseEvent&) {};
  virtual void OnKeyDown(wxKeyEvent&) {};
  virtual void OnKeyUp(wxKeyEvent&) {};
  virtual void OnPaint(wxDC&) {};
  virtual void OnSetFocus(wxFocusEvent&) {};
  virtual void OnKillFocus(wxFocusEvent&) {};
  virtual void OnScrollWin(wxScrollWinEvent&) {};

protected:
  InputMode(CanvasDraw& owner) : m_owner(owner) {};

  CanvasDraw& m_owner;
};

//----------------------------------------------------------------------------

#endif