#ifndef ABITA_APPLICATION_H
#define ABITA_APPLICATION_H

#include "FrameMain.h"

//----------------------------------------------------------------------------

class Application : public wxApp
{
public:

  virtual bool OnInit();


  bool  isGridEnabled() const     { return m_gridState; };
  void  enableGrid(bool value)    { m_gridState = value; };
  float getGridSize() const       { return m_gridSize; };
  void  setGridSize(float value)  { m_gridSize = value; };

  void set_a1(int v)       { m_a1 = v; };  
  int get_a1() const       { return m_a1;};  
  
  void set_a2(int v)       { m_a2 = v; };  
  int get_a2() const       { return m_a2;};  
  
  void set_a3(unsigned v)  { m_a3 = v; };  
  unsigned get_a3() const  { return m_a3;};  
  
  void set_a4(float v)     { m_a4 = v; };  
  float get_a4() const     { return m_a4;};  

  FrameMain *m_frame;

  bool  isMesureToolEnable() const     { return m_mesureToolEnable; };
  void  enableMesureTool(bool value)    { m_mesureToolEnable = value; };

  void setMesureToolValues(wxPoint a,wxPoint b) {  m_mesureToolvalues[0] = a; m_mesureToolvalues[1] = b; };
  std::vector<wxPoint> getMesureToolValues(void) const { return m_mesureToolvalues; };

private:

  bool m_mesureToolEnable;
  std::vector<wxPoint> m_mesureToolvalues;

  float m_gridSize;
  bool m_gridState;
  
  // ------

  int m_a1;
  int m_a2;
  unsigned m_a3;
  float m_a4;
};

//----------------------------------------------------------------------------

DECLARE_APP(Application)

#endif