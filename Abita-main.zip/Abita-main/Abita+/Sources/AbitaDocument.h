#ifndef ABITA_DOCUMENT_H
#define ABITA_DOCUMENT_H

#include "Application.h"
#include "MeshConnected.h"

//----------------------------------------------------------------------------

class Document
{
public:

  static const unsigned POINT_PRECISION = 512;

  typedef enum
  {
    T1 = 0,
    T2,
    T3,
    T4,
    T5
  }
  TypeLogement;

  struct InfosTypeLogement
  {
    InfosTypeLogement( float _benefit, unsigned _areaMin, float _areaMax, unsigned _numMin, unsigned _numMax)
    {
      benefit = _benefit;
      numMin  = _numMin;
      numMax  = _numMax;
      areaMin = _areaMin;
      areaMax = _areaMax;
    }

    float    benefit;
    unsigned numMin;
    unsigned numMax;
    float    areaMin;
    float    areaMax;

  private:
    InfosTypeLogement() {};
    friend Document;
  };

  Document();

  void setShape( std::auto_ptr<MeshConnected> shape ) { m_shapes[m_currentFloor] = shape; };
  MeshConnected& getShape() const { _ASSERT(m_shapes[m_currentFloor].get() != NULL); return *m_shapes[m_currentFloor]; };

  void setCurrentFloor(unsigned floor) { m_currentFloor = floor; };
  unsigned getCurrentFloor() const { return m_currentFloor; };

  unsigned getNumFloors() const { return m_shapes.size(); };

  void eraseFloor(unsigned floor)
  {
    m_shapes.erase( m_shapes.begin() + floor );
    if (floor <= m_currentFloor)
    {
      if (m_currentFloor != 0)
        --m_currentFloor;
    }
  };
  void addFloor( std::auto_ptr<MeshConnected> initialShape ) { m_shapes.push_back( boost::shared_ptr<MeshConnected>(initialShape) ); };
  void insertFloor(unsigned floorPosition, std::auto_ptr<MeshConnected> initialShape )
  {
    m_shapes.insert( m_shapes.begin() + floorPosition, boost::shared_ptr<MeshConnected>(initialShape) );
    if (floorPosition <= m_currentFloor)
      m_currentFloor++;
  };

  bool isEmpty();

  Point2d convert( wxPoint const& canvasPosition) const
  { return Point2d( float(canvasPosition.x)/float(POINT_PRECISION), float(canvasPosition.y)/float(POINT_PRECISION) );
  }
  //{ return Point2d( float(canvasPosition.x-m_editCanvasTopLeftCorner.x) / float(m_pixelsPerMeter),
  //                  float(canvasPosition.y-m_editCanvasTopLeftCorner.y) / float(m_pixelsPerMeter) );
  //} 

  wxPoint convert( Point2d const& shapePosition ) const
  { return wxPoint( int(shapePosition.x*POINT_PRECISION), int(shapePosition.y*POINT_PRECISION) );
  }
  //{ return wxPoint( int(shapePosition.x * float(m_pixelsPerMeter)) + m_editCanvasTopLeftCorner.x,
  //                  int(shapePosition.y * float(m_pixelsPerMeter)) + m_editCanvasTopLeftCorner.y);
  //}

  wxPoint snapToGrid( wxPoint const& point ) const
  {
    float const gridSize = wxGetApp().getGridSize();
    Point2d docPosition = convert( point );
    docPosition.x = float( int( (docPosition.x / gridSize)+0.5f )) * gridSize;
    docPosition.y = float( int( (docPosition.y / gridSize)+0.5f )) * gridSize;
    return convert( docPosition );
  }

  float getSizeX() const { return m_sizeX; };
  float getSizeY() const { return m_sizeY; };
  void  setSizeX(float f) { m_sizeX = f; };
  void  setSizeY(float f) { m_sizeY = f; };  

         float getPixelsPerMeter() const { return m_pixelsPerMeter; };
  inline void  setPixelsPerMeter(float value);

  InfosTypeLogement const& getInfoTypeAppartement(TypeLogement type) const;
  void setInfoTypeAppartement(TypeLogement type, InfosTypeLogement const& infos);

  wxPoint m_editCanvasTopLeftCorner;

  wxString getGlobalAnnotations(){ return m_annotations_globales; };
  void setGlobalAnnotations(wxString str){ m_annotations_globales = str; };

private:
  float    m_sizeX, m_sizeY;
  float    m_pixelsPerMeter;

  unsigned m_currentFloor;
  std::vector< boost::shared_ptr<MeshConnected> > m_shapes;

  InfosTypeLogement m_infosTypesLogements[5];
  
  // annotations
  wxString m_annotations_globales;
};

//----------------------------------------------------------------------------

void Document::setPixelsPerMeter(float value)
{ 
  if (value < 2.0f) value = 2.0f;
  if (value > 256.f) value = 256.f;
  m_pixelsPerMeter = value;
};

//----------------------------------------------------------------------------

extern Document* theDocument;

//----------------------------------------------------------------------------

#endif