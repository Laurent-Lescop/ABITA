#ifndef ABITA_POINT2D_H
#define ABITA_POINT2D_H

class Point2d
{
public:

  Point2d() {};
  Point2d(float _x, float _y) : x(_x), y(_y) {};

  Point2d operator-() const { return Point2d(-x, -y); };
  Point2d operator-(Point2d const& rhs) const { return Point2d(x-rhs.x, y-rhs.y); };
  Point2d operator+(Point2d const& rhs) const { return Point2d(x+rhs.x, y+rhs.y); };

  Point2d& operator+=(Point2d const& rhs) { x += rhs.x; y += rhs.y; return (*this); };

  //! dot product
  float operator*(Point2d const& rhs) const { return (x*rhs.x) + (y*rhs.y); };

  Point2d operator*(float rhs) const { return Point2d(x*rhs, y*rhs); };
  Point2d& operator*=(float rhs) { x *= rhs; y *= rhs; return (*this); };

  float length() const { return sqrt(squareLength()); };
  float squareLength() const { return (x*x + y*y); };

  float x, y;
};

#endif
