#ifndef ABITA_MODE_MOVE_VERTEX_H
#define ABITA_MODE_MOVE_VERTEX_H

#include "EditContext.h"
#include "MeshConnected.h"
#include "MeshConnected_algorithms.h"
#include "Point2d.h"
#include "wxUtilities.h"

//----------------------------------------------------------------------------

class ModeMoveVertex : public InputMode
{
public:

  ModeMoveVertex(CanvasDraw& owner) : InputMode(owner), m_moving(false)
  {
  };

  virtual ~ModeMoveVertex()
  {
    cancelOperation();
  }

  //--------------------------------------------------------------------------

  virtual void OnEvent(wxMouseEvent& event)
  {
    Document const& doc = *theDocument;

    wxPoint currentPosition = event.GetPosition();

    //--- define the cursor to use

    m_owner.SetCursor( *wxCROSS_CURSOR );

    //--- change the mouse position

    if (m_moving)
    {
      MeshConnected::VertexHandle mergeVertex;

      wxPoint newMousePosition = currentPosition;

      do
      {
        // first pass : find a vertex that we can merge at the ungridded mouse location
        // second pass [if any] : find a vertex that we can merge at the gridded mouse location

        if (newMousePosition != currentPosition)
        {
          //--- refresh the nearby elements
          currentPosition = newMousePosition;

          CanvasDraw::DCmanager manager = m_owner.getDC();
          wxDC& dc = manager.getDC();
          unsigned sensitivity = computeSensitivity(dc);
          theEditContext.populate( currentPosition, sensitivity );
        }

        std::vector<MeshConnected::VertexHandle> nearVs;
        theEditContext.getNearVertices( nearVs );
        if (!nearVs.empty())
        {
          unsigned nearVindex = 0;
          MeshConnected::VertexHandle vh = nearVs[nearVindex];
          while (vh == m_movedVertex && nearVindex < (nearVs.size()-1))
          {
            ++nearVindex;
            vh = nearVs[nearVindex];
          }
          if (vh != m_movedVertex)
            mergeVertex = vh;
        }

        if (wxGetApp().isGridEnabled())
        {
          //--- apply the grid
          newMousePosition = doc.snapToGrid( newMousePosition );
        }
      }
      while (newMousePosition != currentPosition && mergeVertex == MeshConnected::INVALID_HANDLE);
      currentPosition = newMousePosition;

      if (event.LeftUp())
      {
        m_moving = false;

        if (mergeVertex != MeshConnected::INVALID_HANDLE)
        {
          MeshConnected::VertexHandle mergev[2] = { m_movedVertex, mergeVertex };
          mergeVertices(doc.getShape(), mergev);
        }
        else
        {
          doc.getShape().getVertexData(m_movedVertex)->position = doc.convert( currentPosition );
        }

        m_owner.Refresh();
        m_originalState.reset( NULL );

        return;
      }
      else
      {
        // dumb update
        if (mergeVertex != MeshConnected::INVALID_HANDLE)
        {
          MeshConnected::VertexData* vdata = doc.getShape().getVertexData(mergeVertex);
          doc.getShape().getVertexData(m_movedVertex)->position = vdata->position;
        }
        else
        {
          doc.getShape().getVertexData(m_movedVertex)->position = doc.convert( currentPosition );
        }
        m_owner.Refresh();
      }
    }

    // draw vertex handles
    {
      CanvasDraw::DCmanager& manager = m_owner.getDC();
      wxDC& dc = manager.getDC();

      redrawVertexHandles(dc, VH_DONT_CARE);
      std::vector<MeshConnected::VertexHandle> nearVs;
      theEditContext.getNearVertices( nearVs );
      
      unsigned const numNearVs = nearVs.size();
      VertexHandleStatus const status = (numNearVs > 1) ? VH_NOK : VH_OK;
      for (unsigned v=0; v<numNearVs; v++)
      {
        MeshConnected::VertexHandle handle = nearVs[v];

        VertexHandleStatus nstatus = (m_moving && m_movedVertex==handle) ? VH_DONT_CARE : status;

        MeshConnected::VertexData* vdata = doc.getShape().getVertexData(handle);
        drawVertexHandle(dc, doc.convert(vdata->position), nstatus);
      }

      manager.paint();
    }

    if (!m_moving)
    {
      bool const isNearUniqueVertex = theEditContext.isNearUniqueVertex();

      if (event.LeftDown() && isNearUniqueVertex)
      {
        // start draaging the vertex
        m_moving = true;
        m_movedVertex = theEditContext.getNearVertex();

        m_originalState.reset( new MeshConnected(doc.getShape()) );
      }
    }
  };

  //--------------------------------------------------------------------------

  virtual void OnKeyUp(wxKeyEvent& event)
  { 
    if (event.m_keyCode == WXK_ESCAPE)
    {
      cancelOperation();
    }
  };

  virtual void OnPaint(wxDC& dc)
  {
    // draw vertex handles
    if (m_moving)
    {
      redrawVertexHandles(dc, VH_DONT_CARE);
      std::vector<MeshConnected::VertexHandle> nearVs;
      theEditContext.getNearVertices( nearVs );
      
      unsigned const numNearVs = nearVs.size();
      VertexHandleStatus const status = (numNearVs > 2) ? VH_NOK : VH_OK;
      for (unsigned v=0; v<numNearVs; v++)
      {
        MeshConnected::VertexHandle handle = nearVs[v];
        MeshConnected::VertexData* vdata = theDocument->getShape().getVertexData(handle);
        drawVertexHandle(dc, theDocument->convert(vdata->position), status);
      }
    }
  }

private:

  //--------------------------------------------------------------------------

  void cancelOperation()
  {
    m_owner.SetCursor( NULL );

    if (m_originalState.get() != NULL)
      theDocument->setShape( m_originalState );

    m_owner.Refresh();

    m_moving = false;
  }

  //--------------------------------------------------------------------------

  std::auto_ptr<MeshConnected> m_originalState;
  MeshConnected::VertexHandle m_movedVertex;
  bool m_moving;
};

//----------------------------------------------------------------------------

#endif