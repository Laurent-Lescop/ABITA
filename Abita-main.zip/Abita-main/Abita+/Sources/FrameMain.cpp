#include "precompiled.h"

#include "Application.h"
#include "FrameMain.h"
#include "CanvasDraw.h"
#include "AbitaDocument.h"

// Dialog
#include "DlgAbout.h"
#include "DlgPreferences.h"
#include "DlgProprietes.h"
#include "DlgQuestion.h"
#include "DlgWaitCompute.h"

#include "ModeCutShape.h"
#include "ModeCreatePolygon.h"
#include "ModeMoveVertex.h"
#include "ModeDeleteShapeElements.h"
#include "ModeChangeElementType.h"
#include "ModeEdition.h"
#include "ModeMeasure.h"

// textes (resources)
#include "textes.h"

using namespace std;

//bool is_start = false;

//----------------------------------------------------------------------------
// constants
//----------------------------------------------------------------------------

const unsigned BOTTOM_PANEL_SIZE = 64;


// IDs for the controls and the menu commands
enum
{
  // menu fichier
  ID_QUIT = 1,
  ID_NOUVEAU,
  ID_CHARGER,
  ID_SAUVER,
  ID_EXPORTER,
  ID_IMPRIMER,

  // menu projet
  ID_PROPRIETE,
  ID_CONFIGURATION,
  ID_SOLUTION,
  ID_VISUALISER,

  // menu draw
  ID_UNDO,
  ID_REDO,
  ID_ETAGEADD,
  ID_ETAGESUP,
  ID_NORMAL,
  ID_CONTOUR,
  ID_STRUCTURE,
  ID_MESURE,
  ID_DEPLACER,
  ID_SUPPRIMER,
  ID_ELEMENT_LIBRE,
  ID_ELEMENT_COMMUN_POSSIBLE,
  ID_ELEMENT_COMMUN_IMPOSE,
  ID_ELEMENT_SORTIE,

  // menu view
  ID_FOND,
  ID_GRID,
  ID_ZOOM_IN,
  ID_ZOOM_OUT,
  ID_ZOOM_RESET,

  // menu aide
  ID_SHOWTIPS,
  ID_AIDE,
  ID_ABOUT = wxID_ABOUT,

  // Toolbar defs
  ID_TOOLBARH,
  ID_TOOLBARV,

  // Notebook
  ID_NOTEBOOK
};

//----------------------------------------------------------------------------
// event tables and other macros for wxWindows
//----------------------------------------------------------------------------

BEGIN_EVENT_TABLE(FrameMain, wxFrame)
//menu fichier
EVT_MENU(ID_NOUVEAU,  FrameMain::OnMenuNouveau)
EVT_MENU(ID_CHARGER,  FrameMain::OnMenuCharger)
EVT_MENU(ID_SAUVER,  FrameMain::OnMenuSauver)
EVT_MENU(ID_QUIT,  FrameMain::OnMenuQuitter)
EVT_MENU(ID_EXPORTER,  FrameMain::OnMenuExporter)
EVT_MENU(ID_IMPRIMER,  FrameMain::OnMenuImprimer)
// menu projet
EVT_MENU(ID_PROPRIETE, FrameMain::OnMenuPropriete)
EVT_MENU(ID_CONFIGURATION, FrameMain::OnMenuConfiguration)
EVT_MENU(ID_SOLUTION, FrameMain::OnMenuSolution)
EVT_MENU(ID_VISUALISER, FrameMain::OnMenuVisualiser)
// menu draw
EVT_MENU(ID_UNDO, FrameMain::OnMenuUndo)
EVT_MENU(ID_REDO, FrameMain::OnMenuRedo)
EVT_MENU(ID_NORMAL, FrameMain::OnMenuNormal)
EVT_MENU(ID_CONTOUR, FrameMain::OnMenuContour)
EVT_MENU(ID_STRUCTURE, FrameMain::OnMenuStructure)
EVT_MENU(ID_MESURE, FrameMain::OnMenuMesure)
EVT_MENU(ID_DEPLACER, FrameMain::OnMenuDeplacer)
EVT_MENU(ID_SUPPRIMER, FrameMain::OnMenuSupprimer)
EVT_MENU(ID_ETAGEADD, FrameMain::OnMenuEtageAdd)
EVT_MENU(ID_ETAGESUP, FrameMain::OnMenuEtageSup)
EVT_MENU(ID_ELEMENT_LIBRE, FrameMain::OnMenuElementLibre)
EVT_MENU(ID_ELEMENT_COMMUN_POSSIBLE, FrameMain::OnMenuElementCommunPossible)
EVT_MENU(ID_ELEMENT_COMMUN_IMPOSE, FrameMain::OnMenuElementCommunImpose)
EVT_MENU(ID_ELEMENT_SORTIE, FrameMain::OnMenuElementSortie)

// menu view
EVT_MENU(ID_FOND, FrameMain::OnMenuFond)
EVT_MENU(ID_GRID, FrameMain::OnMenuGrid)
EVT_MENU(ID_ZOOM_IN, FrameMain::OnMenuZoomIn)
EVT_MENU(ID_ZOOM_OUT, FrameMain::OnMenuZoomOut)
EVT_MENU(ID_ZOOM_RESET, FrameMain::OnMenuZoomReset)

// menu aide
EVT_MENU(ID_SHOWTIPS, FrameMain::OnMenuShowtips)
EVT_MENU(ID_AIDE, FrameMain::OnMenuAide)
EVT_MENU(ID_ABOUT, FrameMain::OnMenuAbout)

EVT_SIZE(FrameMain::OnSize)
// toolbar main
EVT_TOOL_ENTER(ID_TOOLBARH, FrameMain::OnToolEnterH)
EVT_TOOL_ENTER(ID_TOOLBARV, FrameMain::OnToolEnterV)
// toolbar tools H
EVT_TOOL(ID_NOUVEAU,  FrameMain::OnMenuNouveau)
EVT_TOOL(ID_CHARGER,  FrameMain::OnMenuCharger)
EVT_TOOL(ID_SAUVER,  FrameMain::OnMenuSauver)
EVT_TOOL(ID_IMPRIMER,  FrameMain::OnMenuImprimer)
EVT_TOOL(ID_PROPRIETE, FrameMain::OnMenuPropriete)
EVT_TOOL(ID_SOLUTION, FrameMain::OnMenuSolution)
EVT_TOOL(ID_VISUALISER, FrameMain::OnMenuVisualiser)
EVT_TOOL(ID_AIDE, FrameMain::OnMenuAide)
// toolbar tools V
EVT_TOOL(ID_NORMAL, FrameMain::OnMenuNormal)
EVT_TOOL(ID_CONTOUR,FrameMain::OnMenuContour)
EVT_TOOL(ID_CONTOUR,FrameMain::OnMenuStructure)
EVT_TOOL(ID_ZOOM_IN, FrameMain::OnMenuZoomIn)
EVT_TOOL(ID_ZOOM_OUT, FrameMain::OnMenuZoomOut)
EVT_TOOL(ID_ZOOM_RESET, FrameMain::OnMenuZoomReset)

EVT_TOOL(ID_SUPPRIMER, FrameMain::OnMenuSupprimer)
EVT_TOOL(ID_DEPLACER, FrameMain::OnMenuDeplacer)

EVT_TOOL(ID_ELEMENT_LIBRE,           FrameMain::OnMenuElementLibre)
EVT_TOOL(ID_ELEMENT_COMMUN_POSSIBLE, FrameMain::OnMenuElementCommunPossible)
EVT_TOOL(ID_ELEMENT_COMMUN_IMPOSE,   FrameMain::OnMenuElementCommunImpose)
EVT_TOOL(ID_ELEMENT_SORTIE,          FrameMain::OnMenuElementSortie)


EVT_TOOL(ID_GRID, FrameMain::OnMenuGrid)
EVT_TOOL(ID_FOND, FrameMain::OnMenuFond)

EVT_NOTEBOOK_PAGE_CHANGED(ID_NOTEBOOK, OnPageChange)

END_EVENT_TABLE()

//----------------------------------------------------------------------------

wxMenuItem *FrameMain::createMenuItem(wxMenu *parent,unsigned id,wxString str,wxBitmap bitmap)
{
  wxMenuItem *wmi = new wxMenuItem(parent, id, str);
  wmi->SetBitmap(SetTrans(bitmap));
  //wmi->SetBackgroundColour(*wxWHITE);
  return wmi;
}

wxMenuItem *FrameMain::createMenuItem(wxMenu *parent,unsigned id,wxString str)
{
  wxMenuItem *wmi = new wxMenuItem(parent, id, str);
  //wmi->SetBackgroundColour(*wxWHITE);
  return wmi;
}
/*
wxMenuItem *FrameMain::createSeparator(wxMenu *parent)
{
wxMenuItem *wmi = new wxMenuItem(parent, wxID_SEPARATOR , "","",wxITEM_SEPARATOR);
wmi->SetBackgroundColour(*wxWHITE);
return wmi;
}
*/
/*
wxBitmapButton* FrameMain::CreateBitmapButton(wxWindow *parent,wxBitmap in,wxWindowID id,wxString str)
{

in.SetMask(new wxMask(in,wxColour(255,255,255)));
//out.SetMask(new wxMask(out,wxColour(255,255,255)));
//SetBitmapSelected(out);
return new wxBitmapButton(parent,id, in, wxDefaultPosition, wxSize(16,16), 0 ,wxDefaultValidator, str);
}
*/

wxBitmap FrameMain::SetTrans(wxBitmap in)
{
  in.SetMask(new wxMask(in,wxColour(255,255,255)));
  return in;
}


FrameMain::FrameMain(const wxString& title, const wxPoint& pos, const wxSize& size, long style)
: wxFrame(NULL, -1, title, pos, size, style)
{
  // set the frame icon
  SetIcon(wxICON(mainico));

  // ----------------------------------------------------
  // init variables
  // ----------------------------------------------------

  m_toolbarVerticale = NULL;
  m_last_id = 0;

  // ----------------------------------------------------
  //read config
  // ----------------------------------------------------
  m_config = new wxConfig("Abita+");


  //----------------------------------------------------
  // Spash screen
  //----------------------------------------------------
  wxSplashScreen* splash = new wxSplashScreen(wxBITMAP(logo_abita_splash),
    wxSPLASH_CENTRE_ON_SCREEN|wxSPLASH_TIMEOUT,
    2000, this, -1, wxDefaultPosition, wxDefaultSize,
    wxSIMPLE_BORDER|wxSTAY_ON_TOP);
  //wxYield();

  // ----------------------------------------------------
  // the menus
  // ----------------------------------------------------

#if wxUSE_MENUS
  // create a menu bar

  // ---------- Menu File
  menuFile = new wxMenu;
  /*
  menuFile->Append(createMenuItem(menuFile,ID_NOUVEAU, RS_MENU_NOUVEAU,wxBITMAP(toolbar_new)));
  menuFile->Append(createMenuItem(menuFile,ID_CHARGER,  RS_MENU_CHARGER,wxBITMAP(toolbar_open)));
  menuFile->Append(createMenuItem(menuFile,ID_SAUVER,  RS_MENU_SAUVER,wxBITMAP(toolbar_save)));  
  menuFile->Append(createMenuItem(menuFile,ID_EXPORTER,RS_MENU_EXPORTER));
  menuFile->AppendSeparator();
  menuFile->Append(createMenuItem(menuFile,ID_IMPRIMER,RS_MENU_IMPRIMER,wxBITMAP(toolbar_print)));
  menuFile->AppendSeparator();
  menuFile->Append(createMenuItem(menuFile,ID_QUIT,  RS_MENU_QUITTER));
  */
  menuFile->Append(ID_NOUVEAU, RS_MENU_NOUVEAU);
  menuFile->Append(ID_CHARGER,  RS_MENU_CHARGER);
  menuFile->Append(ID_SAUVER,  RS_MENU_SAUVER);  
  menuFile->Append(ID_EXPORTER,RS_MENU_EXPORTER);
  menuFile->AppendSeparator();
  menuFile->Append(ID_IMPRIMER,RS_MENU_IMPRIMER);
  menuFile->AppendSeparator();
  menuFile->Append(ID_QUIT,  RS_MENU_QUITTER);

  // ---------- Menu Projet
  menuProjet = new wxMenu;
  /*
  menuProjet->Append(createMenuItem(menuProjet,ID_PROPRIETE,  RS_MENU_PROPRIETE,wxBITMAP(toolbar_propriete)));
  menuProjet->Append(createMenuItem(menuProjet,ID_CONFIGURATION,  RS_MENU_CONFIGURATION,wxBITMAP(toolbar_configuration)));
  menuProjet->AppendSeparator();
  menuProjet->Append(createMenuItem(menuProjet,ID_SOLUTION,  RS_MENU_SOLUTION,wxBITMAP(toolbar_compute)));
  menuProjet->Append(createMenuItem(menuProjet,ID_VISUALISER,RS_MENU_VISUALISER,wxBITMAP(toolbar_visu)));
  */
  menuProjet->Append(ID_PROPRIETE,  RS_MENU_PROPRIETE);
  menuProjet->Append(ID_CONFIGURATION,  RS_MENU_CONFIGURATION);
  menuProjet->AppendSeparator();
  menuProjet->Append(ID_SOLUTION,  RS_MENU_SOLUTION);
  menuProjet->Append(ID_VISUALISER,RS_MENU_VISUALISER);

  // ---------- Menu Draw
  menuDraw = new wxMenu;
  /*
  menuDraw->Append(createMenuItem(menuDraw,ID_UNDO, RS_MENU_UNDO));
  menuDraw->Append(createMenuItem(menuDraw,ID_REDO, RS_MENU_REDO));
  menuDraw->AppendSeparator();
  menuDraw->Append(createMenuItem(menuDraw,ID_ETAGEADD, RS_MENU_ETAGE_ADD,wxBITMAP(toolbar_etage_add)));
  menuDraw->Append(createMenuItem(menuDraw,ID_ETAGESUP, RS_MENU_ETAGE_SUP,wxBITMAP(toolbar_etage_sup)));
  menuDraw->AppendSeparator();
  //#if wxHAS_RADIO_MENU_ITEMS  TO DO : check if feature is present ...
  menuDraw->Append(createMenuItem(menuDraw,ID_NORMAL, RS_MENU_DRAW_NORMAL,wxBITMAP(toolbar_normal)));
  menuDraw->Append(createMenuItem(menuDraw,ID_CONTOUR, RS_MENU_DRAW_CONTOUR,wxBITMAP(toolbar_contour)));
  menuDraw->Append(createMenuItem(menuDraw,ID_STRUCTURE, RS_MENU_DRAW_STRUCTURE,wxBITMAP(toolbar_structure)));
  menuDraw->AppendSeparator();
  menuDraw->Append(createMenuItem(menuDraw,ID_DEPLACER, RS_MENU_DEPLACER, wxBITMAP(toolbar_move)));
  menuDraw->Append(createMenuItem(menuDraw,ID_SUPPRIMER, RS_MENU_SUPPRIMER, wxBITMAP(toolbar_delete)));
  menuDraw->AppendSeparator();
  menuDraw->Append(createMenuItem(menuDraw, ID_ELEMENT_LIBRE,           RS_MENU_ELEMENT_LIBRE,           wxBITMAP(toolbar_selectA)));
  menuDraw->Append(createMenuItem(menuDraw, ID_ELEMENT_COMMUN_POSSIBLE, RS_MENU_ELEMENT_COMMUN_POSSIBLE, wxBITMAP(toolbar_selectB)));
  menuDraw->Append(createMenuItem(menuDraw, ID_ELEMENT_COMMUN_IMPOSE,   RS_MENU_ELEMENT_COMMUN_IMPOSE,   wxBITMAP(toolbar_selectC)));
  menuDraw->Append(createMenuItem(menuDraw, ID_ELEMENT_SORTIE,          RS_MENU_ELEMENT_SORTIE,          wxBITMAP(toolbar_selectD)));
  */
  menuDraw->Append(ID_UNDO, RS_MENU_UNDO);
  menuDraw->Append(ID_REDO, RS_MENU_REDO);
  menuDraw->AppendSeparator();
  menuDraw->Append(ID_ETAGEADD, RS_MENU_ETAGE_ADD);
  menuDraw->Append(ID_ETAGESUP, RS_MENU_ETAGE_SUP);
  menuDraw->AppendSeparator();
  //#if wxHAS_RADIO_MENU_ITEMS  TO DO : check if feature is present ...
  menuDraw->AppendRadioItem(ID_NORMAL, RS_MENU_DRAW_NORMAL);
  menuDraw->AppendRadioItem(ID_CONTOUR, RS_MENU_DRAW_CONTOUR);
  menuDraw->AppendRadioItem(ID_STRUCTURE, RS_MENU_DRAW_STRUCTURE);
  menuDraw->AppendRadioItem(ID_MESURE, RS_MENU_MESURE);
  //menuDraw->AppendSeparator();
  menuDraw->AppendRadioItem(ID_DEPLACER, RS_MENU_DEPLACER);
  menuDraw->AppendRadioItem(ID_SUPPRIMER, RS_MENU_SUPPRIMER);
  //menuDraw->AppendSeparator();
  menuDraw->AppendRadioItem(ID_ELEMENT_LIBRE,RS_MENU_ELEMENT_LIBRE);
  menuDraw->AppendRadioItem(ID_ELEMENT_COMMUN_POSSIBLE,RS_MENU_ELEMENT_COMMUN_POSSIBLE);
  menuDraw->AppendRadioItem(ID_ELEMENT_COMMUN_IMPOSE,RS_MENU_ELEMENT_COMMUN_IMPOSE);
  menuDraw->AppendRadioItem(ID_ELEMENT_SORTIE,RS_MENU_ELEMENT_SORTIE);

  // ---------- Menu View
  menuView = new wxMenu;
  /*
  menuView->Append(createMenuItem(menuView,ID_GRID, RS_MENU_GRID,wxBITMAP(toolbar_grid)));
  menuView->Append(createMenuItem(menuView,ID_FOND, RS_MENU_FOND,wxBITMAP(toolbar_fond)));
  menuView->AppendSeparator();
  menuView->Append(createMenuItem(menuView,ID_ZOOM_IN, RS_MENU_ZOOM_IN,wxBITMAP(toolbar_zoom_in)));
  menuView->Append(createMenuItem(menuView,ID_ZOOM_OUT, RS_MENU_ZOOM_OUT,wxBITMAP(toolbar_zoom_out)));
  menuView->Append(createMenuItem(menuView,ID_ZOOM_RESET, RS_MENU_ZOOM_RESET,wxBITMAP(toolbar_zoom_reset)));
  */
  menuView->AppendCheckItem(ID_GRID, RS_MENU_GRID);
  menuView->Append(ID_FOND, RS_MENU_FOND);
  menuView->AppendSeparator();
  menuView->Append(ID_ZOOM_IN, RS_MENU_ZOOM_IN);
  menuView->Append(ID_ZOOM_OUT, RS_MENU_ZOOM_OUT);
  menuView->Append(ID_ZOOM_RESET, RS_MENU_ZOOM_RESET);

  // ---------- Menu Aide
  wxMenu *menuAide = new wxMenu;
  /*
  menuAide->Append(createMenuItem(menuAide,ID_SHOWTIPS, RS_MENU_SHOWTIPS));
  menuAide->Append(createMenuItem(menuAide,ID_AIDE, RS_MENU_AIDE,wxBITMAP(toolbar_help)));
  menuAide->AppendSeparator();
  menuAide->Append(createMenuItem(menuAide,ID_ABOUT, RS_MENU_ABOUT));
  */
  menuAide->Append(ID_SHOWTIPS, RS_MENU_SHOWTIPS);
  menuAide->Append(ID_AIDE, RS_MENU_AIDE);
  menuAide->AppendSeparator();
  menuAide->Append(ID_ABOUT, RS_MENU_ABOUT);

  // now append the freshly created menu to the menu bar...
  wxMenuBar *menuBar = new wxMenuBar();
  menuBar->Append(menuFile, RS_MENU_GLOBAL_FILE);
  menuBar->Append(menuProjet, RS_MENU_GLOBAL_PROJET);
  menuBar->Append(menuDraw, RS_MENU_GLOBAL_DRAW);
  menuBar->Append(menuView, RS_MENU_GLOBAL_VIEW);
  menuBar->Append(menuAide, RS_MENU_GLOBAL_HELP);

  // ... and attach this menu bar to the frame
  SetMenuBar(menuBar);
#endif // wxUSE_MENUS

#if wxUSE_STATUSBAR
  // create a status bar just for fun (by default with 1 pane only)
  CreateStatusBar(2);
  SetStatusText(RS_TEXTE_STATUSBAR_WELCOME);
#endif // wxUSE_STATUSBAR

  // desactive les menus 

  menuFile->Enable(ID_CHARGER,false);
  menuFile->Enable(ID_SAUVER,false);
  menuFile->Enable(ID_EXPORTER,false);
  menuFile->Enable(ID_IMPRIMER,false);

  menuDraw->Enable(ID_UNDO,false);
  menuDraw->Enable(ID_REDO,false);
  menuAide->Enable(ID_AIDE,false);

  // ----------------------------------------------------
  // Create the Horizontal toolbar
  // ----------------------------------------------------

  wxBitmap toolBarBitmapsH[9];
  //wxBitmap toolBarBitmapsH_over[8];

  m_toolBarhorizontale = CreateToolBar(wxTB_FLAT|wxTB_HORIZONTAL|wxTB_TEXT, ID_TOOLBARH);
  m_toolBarhorizontale->SetToolBitmapSize(wxSize(16,16));

  toolBarBitmapsH[0] = wxBITMAP(toolbar_new);
  toolBarBitmapsH[1] = wxBITMAP(toolbar_open);
  toolBarBitmapsH[2] = wxBITMAP(toolbar_save);
  toolBarBitmapsH[3] = wxBITMAP(toolbar_percent);
  toolBarBitmapsH[4] = wxBITMAP(toolbar_print);
  toolBarBitmapsH[5] = wxBITMAP(toolbar_compute);
  toolBarBitmapsH[6] = wxBITMAP(toolbar_visu);
  toolBarBitmapsH[7] = wxBITMAP(toolbar_help);
  toolBarBitmapsH[8] = wxBITMAP(toolbar_configuration);

  /*
  toolBarBitmapsH_over[0] = wxBITMAP(toolbar_new_over);
  toolBarBitmapsH_over[1] = wxBITMAP(toolbar_open_over);
  toolBarBitmapsH_over[2] = wxBITMAP(toolbar_save_over);
  toolBarBitmapsH_over[3] = wxBITMAP(toolbar_compute_over);
  toolBarBitmapsH_over[4] = wxBITMAP(toolbar_visu_over);
  toolBarBitmapsH_over[5] = wxBITMAP(toolbar_percent_over);
  toolBarBitmapsH_over[6] = wxBITMAP(toolbar_print_over);
  toolBarBitmapsH_over[7] = wxBITMAP(toolbar_help_over);
  */

  //#endif // USE_XPM_BITMAPS/!USE_XPM_BITMAPS

  //m_toolBarhorizontale->AddControl(CreateBitmapButton(m_toolBarhorizontale,toolBarBitmapsH[0],ID_NOUVEAU, RS_TOOLBAR_NOUVEAU));

  m_toolBarhorizontale->AddTool(ID_NOUVEAU, RS_TOOLBAR_NOUVEAU, toolBarBitmapsH[0],RS_MENU_NOUVEAU_INFO);
  m_toolBarhorizontale->AddTool(ID_CHARGER, RS_TOOLBAR_CHARGER, toolBarBitmapsH[1],RS_MENU_CHARGER_INFO);
  m_toolBarhorizontale->AddTool(ID_SAUVER, RS_TOOLBAR_SAUVER, toolBarBitmapsH[2],RS_MENU_SAUVER_INFO);

  m_toolBarhorizontale->AddControl(new wxStaticBitmap(m_toolBarhorizontale, -1, wxBITMAP(separatorH)));

  m_toolBarhorizontale->AddTool(ID_CONFIGURATION, RS_TOOLBAR_CONFIGURATION, toolBarBitmapsH[8]);
  m_toolBarhorizontale->AddTool(ID_PROPRIETE, RS_TOOLBAR_PROPRIETE, toolBarBitmapsH[3]);
  m_toolBarhorizontale->AddTool(ID_IMPRIMER, RS_TOOLBAR_IMPRIMER, toolBarBitmapsH[4],RS_MENU_IMPRIMER_INFO);

  m_toolBarhorizontale->AddControl(new wxStaticBitmap(m_toolBarhorizontale, -1, wxBITMAP(separatorH)));

  m_toolBarhorizontale->AddTool(ID_SOLUTION, RS_TOOLBAR_SOLUTION, toolBarBitmapsH[5]);
  m_toolBarhorizontale->AddTool(ID_VISUALISER, RS_TOOLBAR_VISUALISER, toolBarBitmapsH[6]);

  m_toolBarhorizontale->AddControl(new wxStaticBitmap(m_toolBarhorizontale, -1, wxBITMAP(separatorH)));

  m_toolBarhorizontale->AddTool(ID_AIDE, RS_TOOLBAR_AIDE, toolBarBitmapsH[7], RS_MENU_AIDE_INFO);
  m_toolBarhorizontale->AddControl(new wxStaticBitmap(m_toolBarhorizontale, -1, wxBITMAP(logo_abita)));


  m_toolBarhorizontale->Realize();

  m_toolBarhorizontale->SetBackgroundColour(*wxWHITE);


  // ----------------------------------------------------
  // Create the vertical toolbar
  // ----------------------------------------------------

  m_toolbarVerticale = new wxToolBar(this, ID_TOOLBARV,wxDefaultPosition,wxDefaultSize,wxTB_DOCKABLE |wxTB_FLAT|wxTB_VERTICAL|wxTB_TEXT);
  m_toolbarVerticale->SetToolBitmapSize(wxSize(16,16));
  //m_toolbarVerticale->SetMargins(50,0);

  wxBitmap toolBarBitmapsV[16];

  toolBarBitmapsV[0] = SetTrans(wxBITMAP(toolbar_contour));
  toolBarBitmapsV[1] = SetTrans(wxBITMAP(toolbar_structure));
  toolBarBitmapsV[2] = SetTrans(wxBITMAP(toolbar_zoom_reset));
  toolBarBitmapsV[3] = SetTrans(wxBITMAP(toolbar_zoom_in));
  toolBarBitmapsV[4] = SetTrans(wxBITMAP(toolbar_zoom_out));
  toolBarBitmapsV[5] = SetTrans(wxBITMAP(toolbar_etage_add));
  toolBarBitmapsV[6] = SetTrans(wxBITMAP(toolbar_selectA));
  toolBarBitmapsV[7] = SetTrans(wxBITMAP(toolbar_selectB));
  toolBarBitmapsV[8] = SetTrans(wxBITMAP(toolbar_selectC));
  toolBarBitmapsV[13] = SetTrans(wxBITMAP(toolbar_selectD));
  toolBarBitmapsV[9] = SetTrans(wxBITMAP(toolbar_normal));
  toolBarBitmapsV[10] = SetTrans(wxBITMAP(toolbar_move));
  toolBarBitmapsV[11] = SetTrans(wxBITMAP(toolbar_delete));
  //toolBarBitmapsV[12] = SetTrans(wxBITMAP(toolbar_fond));
  toolBarBitmapsV[12] = SetTrans(wxBITMAP(toolbar_grid));
  toolBarBitmapsV[14] = SetTrans(wxBITMAP(toolbar_etage_sup));
  toolBarBitmapsV[15] = SetTrans(wxBITMAP(toolbar_mesure));

  //m_toolbarVerticale->SetToolSeparation(16);

  m_toolbarVerticale->AddTool(ID_ETAGEADD, RS_TOOLBAR_ETAGE_ADD, toolBarBitmapsV[5],RS_MENU_ETAGE_ADD_INFO);
  m_toolbarVerticale->AddTool(ID_ETAGESUP, RS_TOOLBAR_ETAGE_SUP, toolBarBitmapsV[14],RS_MENU_ETAGE_SUP_INFO);
  //m_toolbarVerticale->AddTool(ID_FOND, RS_TOOLBAR_FOND, toolBarBitmapsV[12],RS_MENU_FOND_INFO);
  m_toolbarVerticale->AddTool(ID_GRID, RS_TOOLBAR_GRID, toolBarBitmapsV[12],RS_MENU_GRID_INFO, wxITEM_CHECK );

  m_toolbarVerticale->AddControl(new wxStaticBitmap(m_toolbarVerticale, -1, SetTrans(wxBITMAP(vide))));
  m_toolbarVerticale->AddSeparator();

  m_toolbarVerticale->AddTool(ID_NORMAL,   RS_TOOLBAR_DRAW_NORMAL,   toolBarBitmapsV[9], RS_MENU_DRAW_NORMAL_INFO,       wxITEM_RADIO  );
  m_toolbarVerticale->AddTool(ID_CONTOUR,   RS_TOOLBAR_DRAW_CONTOUR,   toolBarBitmapsV[0], RS_MENU_DRAW_CONTOUR_INFO,    wxITEM_RADIO  );
  m_toolbarVerticale->AddTool(ID_STRUCTURE, RS_TOOLBAR_DRAW_STRUCTURE, toolBarBitmapsV[1], RS_MENU_DRAW_STRUCTURE_INFO,  wxITEM_RADIO  );
  m_toolbarVerticale->AddTool(ID_MESURE, RS_TOOLBAR_MESURE, toolBarBitmapsV[15], RS_MENU_MESURE_INFO,  wxITEM_RADIO  );

  m_toolbarVerticale->AddTool(ID_DEPLACER,  RS_TOOLBAR_DEPLACER,       toolBarBitmapsV[10], RS_TOOLBAR_DEPLACER_INFO ,    wxITEM_RADIO  );
  m_toolbarVerticale->AddTool(ID_SUPPRIMER, RS_TOOLBAR_SUPPRIMER,      toolBarBitmapsV[11], RS_TOOLBAR_SUPPRIMER_INFO ,    wxITEM_RADIO );

  m_toolbarVerticale->AddTool(ID_ELEMENT_LIBRE,           RS_TOOLBAR_ELEMENT_LIBRE,           toolBarBitmapsV[6], RS_MENU_ELEMENT_LIBRE_INFO,            wxITEM_RADIO );
  m_toolbarVerticale->AddTool(ID_ELEMENT_COMMUN_POSSIBLE, RS_TOOLBAR_ELEMENT_COMMUN_POSSIBLE, toolBarBitmapsV[7], RS_MENU_ELEMENT_COMMUN_POSSIBLE_INFO,  wxITEM_RADIO );
  m_toolbarVerticale->AddTool(ID_ELEMENT_COMMUN_IMPOSE,   RS_TOOLBAR_ELEMENT_COMMUN_IMPOSE,   toolBarBitmapsV[8], RS_MENU_ELEMENT_COMMUN_IMPOSE_INFO,    wxITEM_RADIO );
  m_toolbarVerticale->AddTool(ID_ELEMENT_SORTIE,          RS_TOOLBAR_ELEMENT_SORTIE,          toolBarBitmapsV[13], RS_MENU_ELEMENT_SORTIE_INFO,           wxITEM_RADIO );

  m_toolbarVerticale->AddControl(new wxStaticBitmap(m_toolbarVerticale, -1, SetTrans(wxBITMAP(vide))));
  m_toolbarVerticale->AddSeparator();

  m_toolbarVerticale->AddTool(ID_ZOOM_RESET, RS_TOOLBAR_ZOOM_RESET, toolBarBitmapsV[2],RS_MENU_ZOOM_RESET_INFO );
  m_toolbarVerticale->AddTool(ID_ZOOM_IN, RS_TOOLBAR_ZOOM_IN, toolBarBitmapsV[3],RS_MENU_ZOOM_IN_INFO );
  m_toolbarVerticale->AddTool(ID_ZOOM_OUT, RS_TOOLBAR_ZOOM_OUT, toolBarBitmapsV[4],RS_MENU_ZOOM_OUT_INFO );

  m_toolbarVerticale->Realize();

  // desactive les icones non fonctionnelles

  m_toolBarhorizontale->EnableTool(ID_CHARGER,false);
  m_toolBarhorizontale->EnableTool(ID_SAUVER,false);
  m_toolBarhorizontale->EnableTool(ID_IMPRIMER,false);
  m_toolBarhorizontale->EnableTool(ID_VISUALISER,false);

  // ----------------------------------------------------
  // Init the main splitter window
  // ----------------------------------------------------

  m_split = new wxSplitterWindow(this, -1,wxDefaultPosition, wxDefaultSize,0);

  // ----------------------------------------------------
  // Set notebook
  // ----------------------------------------------------

  m_panelTop = new wxPanel(m_split,-1);

  m_notebook = new wxNotebook(m_panelTop, ID_NOTEBOOK);

  // Initialisation du notebook des �tages
  CanvasDraw* cd = new CanvasDraw( m_notebook, -1, wxPoint(0,0), wxSize(400,400) );
  m_canvas.push_back(cd);
  m_notebook->AddPage( cd, RS_ETAGE + " 0", FALSE );

  m_notebook->SetSelection(0);

  m_split->Initialize(m_panelTop);


  // ----------------------------------------------------
  // Bas de page : infos, log, ...
  // ----------------------------------------------------

  m_panelBottom = new wxPanel(m_split,-1);

  wxBoxSizer *item1 = new wxBoxSizer( wxHORIZONTAL );

  // Infos

  wxStaticBox *item30 = new wxStaticBox( m_panelBottom, -1, RS_INFORMATIONS,wxDefaultPosition, wxSize(200,48));
  wxStaticBoxSizer *item20 = new wxStaticBoxSizer( item30, wxVERTICAL );
  m_information_text = new wxStaticText( m_panelBottom, -1, RS_INFORMATIONS_DEFAULT, wxDefaultPosition, wxDefaultSize, 0 );
  item20->Add( m_information_text, 0, wxALIGN_CENTRE|wxALL, 5 );

  item1->Add( item20, 0, wxALIGN_LEFT|wxALL, 5 );

  // Informations

  item1->Add( new wxStaticText( m_panelBottom, -1, RS_EDITCELS_TITRE, wxDefaultPosition, wxDefaultSize, 0 ), 0, wxALIGN_LEFT|wxALL, 5 );

  m_textCels = new wxTextCtrl( m_panelBottom, -1, wxEmptyString, wxDefaultPosition, wxSize(200,48), wxTE_RICH | wxTE_MULTILINE | wxTE_READONLY );
  m_textCels->SetBackgroundColour(*wxLIGHT_GREY);
  item1->Add( m_textCels, 0, wxALIGN_LEFT|wxALL, 5 );

  // Log

  item1->Add( new wxStaticText( m_panelBottom, -1, _T("Log:"), wxDefaultPosition, wxDefaultSize, 0 ), 0, wxALIGN_LEFT|wxALL, 5 );

  m_log_textctrl = new wxTextCtrl( m_panelBottom, -1, wxEmptyString, wxDefaultPosition, wxSize(200,48), wxTE_RICH |wxTE_MULTILINE | wxTE_READONLY );
  m_log_textctrl->SetBackgroundColour(*wxLIGHT_GREY);
  //wxLog::SetActiveTarget( new wxLogTextCtrl(m_log_textctrl) );
  item1->Add( m_log_textctrl, 0, wxALIGN_RIGHT|wxALL, 5 );

  // set sizers...

  m_panelBottom->SetAutoLayout( TRUE );
  m_panelBottom->SetSizer( item1 );

  item1->Fit( m_panelBottom );
  item1->SetSizeHints( m_panelBottom );

  m_split->SplitHorizontally( m_panelTop, m_panelBottom );
  //m_panelBottom->SetSize(wxSize(-1,BOTTOM_PANEL_SIZE));

  layoutChildren();

  OnMenuNormal( wxCommandEvent() );

#ifdef __WXMSW__
  SendSizeEvent();
#endif

  wxString str_temp;
  if(m_config)
    str_temp = m_config->Read("/GUI/showTips", "");
  if ( str_temp.IsEmpty() || (str_temp == "true") )
  {
    wxTipProvider *tipProvider = wxCreateFileTipProvider("tips.txt", 0);
    bool result = wxShowTip(this, tipProvider,true);
    delete tipProvider;
    if(result)
      m_config->Write("/GUI/showTips", "true");
    else
      m_config->Write("/GUI/showTips", "false");
  }
}

void FrameMain::OnSize(wxSizeEvent& event)
{

  if(m_toolbarVerticale)
    layoutChildren(); 
  //else
  event.Skip();
} 

void FrameMain::layoutChildren()
{

  wxSize size = GetClientSize();

  m_toolbarVerticale->SetSize(-1, size.y);
  m_toolbarVerticale->Move(0, 0);

  unsigned offset = m_toolbarVerticale->GetSize().x;


  //  m_notebooksizer->SetDimension(0, 0, size.x - offset, size.y);
  m_split->SetSize(offset, 0, size.x - offset, size.y);
  m_split->SetSashPosition(size.y - BOTTOM_PANEL_SIZE);

  wxSize sizeBottom = m_panelBottom->GetClientSize();

  m_notebook->SetSize(0, 0, size.x - offset, size.y - sizeBottom.y - 8);
}

void FrameMain::OnToolEnterH(wxCommandEvent& event)
{
  if (event.GetSelection() > -1)
  {
    //unsigned selected  = event.GetSelection();
    //toolBarBitmapsH[0] = toolBarBitmapsH_over[0];
  }
}

void FrameMain::OnToolEnterV(wxCommandEvent& event)
{
  if (event.GetSelection() > -1)
  {
    //
  }
}


//------------------------------------------------------------------------------------------------

void FrameMain::refreshCanvas()
{
  m_canvas[m_notebook->GetSelection()]->Refresh();
}

//------------------------------------------------------------------------------------------------
// Menu file
//------------------------------------------------------------------------------------------------


// event handlers
void FrameMain::OnMenuNouveau(wxCommandEvent& WXUNUSED(event))
{
  //wxMessageDialog dialog(this, RS_DIALOG_WARNING, RS_FILE_DIALOG_BITMAP_CHOIX);
  //if(dialog.ShowModal() == wxID_CANCEL) return;

  DlgProprietes frame(this,true, RS_PROPRIETE_TITLE);
  frame.CenterOnParent(wxBOTH);
  if(frame.ShowModal() == wxOK)
  {
    // Initialisation du notebook des �tages
    CanvasDraw* cd = new CanvasDraw( m_notebook, -1, wxPoint(0,0), wxSize(400,400) );
    m_canvas.clear();
    m_canvas.push_back(cd); 

    m_notebook->DeleteAllPages();
    m_notebook->AddPage( cd, RS_ETAGE + " 0", FALSE );
    m_notebook->SetSelection(0);

    if(m_img_fond_ecran.Ok()) m_img_fond_ecran.Destroy();
    // TO DO : redraw the background
    refreshCanvas();  
  }
}

void FrameMain::OnMenuCharger(wxCommandEvent& WXUNUSED(event))
{
  //wxMessageDialog dialog(this, RS_DIALOG_WARNING, RS_FILE_DIALOG_BITMAP_CHOIX);
  //if(dialog.ShowModal() == wxID_CANCEL) return;

  wxString default_path= _T("");
  static wxString s_extDef;
  wxString path = wxFileSelector(RS_FILE_DIALOG_OPEN_TITLE, default_path, _T(""),s_extDef, _T("*.abi"),  wxCHANGE_DIR, this);

  if ( !path )
    return;

  path = path.AfterLast(_T('\\'));
  path = path.AfterLast(_T('/'));

  if(m_img_fond_ecran.Ok()) m_img_fond_ecran.Destroy();
}
void FrameMain::OnMenuSauver(wxCommandEvent& WXUNUSED(event))
{
}
void FrameMain::OnMenuExporter(wxCommandEvent& WXUNUSED(event))
{
}
void FrameMain::OnMenuImprimer(wxCommandEvent& WXUNUSED(event))
{
}
void FrameMain::OnMenuQuitter(wxCommandEvent& WXUNUSED(event))
{
  // TRUE is to force the frame to close
  Close(TRUE);
}

//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------
// Menu Projet
//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------

void FrameMain::OnMenuPropriete(wxCommandEvent& WXUNUSED(event))
{
  DlgProprietes frame(this, false,RS_PROPRIETE_TITLE);
  frame.CenterOnParent(wxBOTH);
  frame.ShowModal();
}
void FrameMain::OnMenuConfiguration(wxCommandEvent& WXUNUSED(event))
{
  DlgPreferences frame(this, RS_PREFERENCES_TITLE);
  frame.CenterOnParent(wxBOTH);
  frame.ShowModal();
}

//------------------------------------------------------------------------------------------------

#include "DlgVisualisation.h"
#include "InterfaceSolveur.h"
#include "Solveur/AbiFile.h"
#include "Solveur/Algo.h"
#include "Solveur/Geom.h"

void FrameMain::OnMenuSolution(wxCommandEvent& WXUNUSED(event))
{
  //wxStreamToTextRedirector redirect(m_log_textctrl);

  m_geom.reset( new CGeom );
  m_popu.reset( new CPopulation );
  m_algo.reset( new CAlgo(m_geom.get(), m_popu.get()) );

  convert(*theDocument, *m_geom, *m_popu, *m_algo);

  DlgWaitCompute dlgWait(this,RS_DIALOG_COMPUTE_TITLE);
  dlgWait.CentreOnParent(wxBOTH);
  dlgWait.Show(true);

  while (m_algo->Run())
  {
    /* do something */
    dlgWait.DrawSomething(*m_popu);
    wxYield();
  }
  dlgWait.Show(false);
  dlgWait.Destroy();

  //- save the results in a dummy ABI file (for debugging & maintenance purpose)
  {
    CAbiFile file("resultats.abi");
    file.Write( *m_geom, *m_popu, *m_algo );
  }

  DlgVisualisation *dlg = new DlgVisualisation( *m_popu, this, RS_DIALOG_SOLUTION_TITLE,GetSize());
  dlg->CentreOnParent(wxBOTH);
  dlg->Show();
}

//------------------------------------------------------------------------------------------------

void FrameMain::OnMenuVisualiser(wxCommandEvent& WXUNUSED(event))
{
}

//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------
// Menu Aide
//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------

void FrameMain::OnMenuShowtips(wxCommandEvent& WXUNUSED(event))
{
  wxTipProvider *tipProvider = wxCreateFileTipProvider("tips.txt", 0);
  bool result = wxShowTip(this, tipProvider,true);
  delete tipProvider;
  if(result)
    m_config->Write("/GUI/showTips", "true");
  else
    m_config->Write("/GUI/showTips", "false");
}

void FrameMain::OnMenuAide(wxCommandEvent& WXUNUSED(event))
{
}

void FrameMain::OnMenuAbout(wxCommandEvent& WXUNUSED(event))
{
  DlgAbout frame(this, "RS_ABOUT_TITLE");
  //frame.CenterOnParent(wxBOTH);
  frame.ShowModal();
}



//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------
// Menu Draw
//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------

void FrameMain::OnMenuUndo(wxCommandEvent& event)
{
}
void FrameMain::OnMenuRedo(wxCommandEvent& event)
{
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

void FrameMain::OnMenuEtageAdd(wxCommandEvent& WXUNUSED(event))
{
  int floor = m_notebook->GetSelection();

  //wxMessageDialog dialog(this, RS_ETAGE_DIALOG_ADD, RS_DIALOG_QUESTION, wxYES_NO | wxCANCEL | wxCENTRE);
  DlgQuestion dlg(this,RS_DIALOG_QUESTION,RS_ETAGE_DIALOG_ADD,RS_ETAGE_DIALOG_ADD_CHOIX_BUTTON);
  int result = dlg.ShowModal();

  if(result == 0) // Avant la selection
  {
    std::auto_ptr<MeshConnected> initialShape( new MeshConnected(theDocument->getShape()) );
    theDocument->insertFloor(floor, initialShape);

    CanvasDraw* cd = new CanvasDraw( m_notebook, -1, wxPoint(0,0), wxSize(400,400) );
    m_canvas.insert( m_canvas.begin() + floor, cd );

    m_notebook->InsertPage(floor, cd, RS_ETAGE + wxString::Format(" %d",floor));

    // rename all the floors
    for(unsigned i=0;i<m_canvas.size();i++)
      m_notebook->SetPageText(i,RS_ETAGE + wxString::Format("%d",i));

    m_notebook->SetSelection(floor);
  }
  if(result == 1) // Apr�s la selection
  {
    int newfloor = floor + 1;
    std::auto_ptr<MeshConnected> initialShape( new MeshConnected(theDocument->getShape()) );
    theDocument->insertFloor(newfloor, initialShape);

    CanvasDraw* cd = new CanvasDraw( m_notebook, -1, wxPoint(0,0), wxSize(400,400) );
    m_canvas.insert( m_canvas.begin()+newfloor, cd );

    m_notebook->InsertPage(newfloor, cd, RS_ETAGE + wxString::Format(" %d",newfloor));

    // rename all the floors
    for(unsigned i=0;i<m_canvas.size();i++)
      m_notebook->SetPageText(i,RS_ETAGE + wxString::Format("%d",i));

    m_notebook->SetSelection(newfloor);
  }

  if(result == 2)  // A la fin
  {
    std::auto_ptr<MeshConnected> initialShape( new MeshConnected(theDocument->getShape()) );
    theDocument->addFloor( initialShape );

    unsigned newFloorID = m_canvas.size();

    CanvasDraw* cd = new CanvasDraw( m_notebook, -1, wxPoint(0,0), wxSize(400,400) );
    m_canvas.push_back(cd);

    m_notebook->AddPage(cd, RS_ETAGE + wxString::Format(" %d", newFloorID));
    m_notebook->SetSelection( newFloorID );
  }
}

//----------------------------------------------------------------------------

void FrameMain::OnMenuEtageSup(wxCommandEvent& WXUNUSED(event))
{
  if (m_canvas.size() == 1)
  {
    wxMessageDialog dialog(this,RS_ETAGE_DIALOG_IMPOSSIBLE_SUP , RS_DIALOG_WARNING, wxOK | wxCENTRE);
    dialog.ShowModal();
    return;
  }
  int floor = m_notebook->GetSelection();

  wxMessageDialog dialog(this,RS_ETAGE_DIALOG_SUP , RS_DIALOG_QUESTION, wxOK| wxCANCEL | wxCENTRE);

  if (dialog.ShowModal() == wxID_OK)
  {
    theDocument->eraseFloor( floor );

    m_canvas.erase( m_canvas.begin() + floor );
    m_notebook->DeletePage(floor);

    // rename all the floors
    for(unsigned i=0;i<m_canvas.size();i++)
      m_notebook->SetPageText(i,RS_ETAGE + wxString::Format("%d",i));
  }
}

//----------------------------------------------------------------------------

void FrameMain::OnPageChange(wxNotebookEvent &event)
{
  unsigned floor = m_notebook->GetSelection();
  theDocument->setCurrentFloor( floor );

  m_notebook->Refresh();

  OnMenuNormal( wxCommandEvent() );
}

//----------------------------------------------------------------------------


void FrameMain::OnMenuNormal(wxCommandEvent& WXUNUSED(event))
{
  menuDraw->Check(ID_NORMAL,true);

  // to prevent wxToolBar bug with radio button 
  m_toolbarVerticale->ToggleTool( m_last_id, false );

  m_toolbarVerticale->ToggleTool( ID_NORMAL, true );
  int floor = m_notebook->GetSelection();
  m_canvas[floor]->setInputMode( std::auto_ptr<InputMode>(new ModeEdition(*m_canvas[floor])) );
  m_last_id = ID_NORMAL;
}

void FrameMain::OnMenuContour(wxCommandEvent& WXUNUSED(event))
{
  menuDraw->Check(ID_CONTOUR,true);

  m_toolbarVerticale->ToggleTool( m_last_id, false );

  m_toolbarVerticale->ToggleTool( ID_CONTOUR, true );
  int floor = m_notebook->GetSelection();
  m_canvas[floor]->setInputMode( std::auto_ptr<InputMode>(new ModeCreatePolygon(*m_canvas[floor])) );
  m_last_id = ID_CONTOUR;

}

void FrameMain::OnMenuStructure(wxCommandEvent& WXUNUSED(event))
{
  menuDraw->Check(ID_STRUCTURE,true);

  m_toolbarVerticale->ToggleTool( m_last_id, false );

  m_toolbarVerticale->ToggleTool( ID_STRUCTURE, true );
  int floor = m_notebook->GetSelection();
  m_canvas[floor]->setInputMode( std::auto_ptr<InputMode>( new ModeCutShape(*m_canvas[floor])) );
  m_last_id = ID_STRUCTURE;

}

void FrameMain::OnMenuMesure(wxCommandEvent& WXUNUSED(event))
{
  menuDraw->Check(ID_MESURE,true);

  m_toolbarVerticale->ToggleTool( m_last_id, false );

  m_toolbarVerticale->ToggleTool( ID_MESURE, true );
  int floor = m_notebook->GetSelection();
  m_canvas[floor]->setInputMode( std::auto_ptr<InputMode>(new ModeMeasure(*m_canvas[floor])) );  

  m_last_id = ID_MESURE;
}

void FrameMain::OnMenuDeplacer(wxCommandEvent& WXUNUSED(event))
{
  menuDraw->Check(ID_DEPLACER,true);

  m_toolbarVerticale->ToggleTool( m_last_id, false );

  m_toolbarVerticale->ToggleTool( ID_DEPLACER, true );
  int floor = m_notebook->GetSelection();
  m_canvas[floor]->setInputMode( std::auto_ptr<InputMode>(new ModeMoveVertex(*m_canvas[floor])) );

  m_last_id = ID_DEPLACER;

}

void FrameMain::OnMenuSupprimer(wxCommandEvent& WXUNUSED(event))
{
  menuDraw->Check(ID_SUPPRIMER,true);

  m_toolbarVerticale->ToggleTool( m_last_id, false );

  m_toolbarVerticale->ToggleTool( ID_SUPPRIMER, true );
  int floor = m_notebook->GetSelection();
  m_canvas[floor]->setInputMode( std::auto_ptr<InputMode>(new ModeDeleteShapeElements(*m_canvas[floor])) );    

  m_last_id = ID_SUPPRIMER;

}


void FrameMain::OnMenuElementLibre(wxCommandEvent& WXUNUSED(event))
{
  menuDraw->Check(ID_ELEMENT_LIBRE,true);

  m_toolbarVerticale->ToggleTool( m_last_id, false );

  m_toolbarVerticale->ToggleTool( ID_ELEMENT_LIBRE, true );
  int floor = m_notebook->GetSelection();
  m_canvas[floor]->setInputMode( std::auto_ptr<InputMode>(new ModeChangeElementType(*m_canvas[floor], FREE_PART)) );    

  m_last_id = ID_ELEMENT_LIBRE;

}

void FrameMain::OnMenuElementCommunPossible(wxCommandEvent& WXUNUSED(event))
{
  menuDraw->Check(ID_ELEMENT_COMMUN_POSSIBLE,true);

  m_toolbarVerticale->ToggleTool( m_last_id, false );

  m_toolbarVerticale->ToggleTool( ID_ELEMENT_COMMUN_POSSIBLE, true );
  int floor = m_notebook->GetSelection();
  m_canvas[floor]->setInputMode( std::auto_ptr<InputMode>(new ModeChangeElementType(*m_canvas[floor], POSSIBLE_COMMON_PART)) );    

  m_last_id = ID_ELEMENT_COMMUN_POSSIBLE;

}

void FrameMain::OnMenuElementCommunImpose(wxCommandEvent& WXUNUSED(event))
{
  menuDraw->Check(ID_ELEMENT_COMMUN_IMPOSE,true);

  m_toolbarVerticale->ToggleTool( m_last_id, false );

  m_toolbarVerticale->ToggleTool( ID_ELEMENT_COMMUN_IMPOSE, true );
  int floor = m_notebook->GetSelection();
  m_canvas[floor]->setInputMode( std::auto_ptr<InputMode>(new ModeChangeElementType(*m_canvas[floor], IMPOSED_COMMON_PART)) );    

  m_last_id = ID_ELEMENT_COMMUN_IMPOSE;

}

void FrameMain::OnMenuElementSortie(wxCommandEvent& WXUNUSED(event))
{
  menuDraw->Check(ID_ELEMENT_SORTIE,true);

  m_toolbarVerticale->ToggleTool( m_last_id, false );

  m_toolbarVerticale->ToggleTool( ID_ELEMENT_SORTIE, true );
  int floor = m_notebook->GetSelection();
  m_canvas[floor]->setInputMode( std::auto_ptr<InputMode>(new ModeChangeElementType(*m_canvas[floor], IMPOSED_EXIT_PART)) );    

  m_last_id = ID_ELEMENT_SORTIE;

}

//------------------------------------------------------------------------------------------------
// Menu View
//------------------------------------------------------------------------------------------------

void FrameMain::OnMenuGrid(wxCommandEvent& event)
{

  if(event.IsChecked())
  {
    menuView->Check(ID_GRID,true);
    m_toolbarVerticale->ToggleTool( ID_GRID, true );
  }
  else
  {
    menuView->Check(ID_GRID,false);
    m_toolbarVerticale->ToggleTool( ID_GRID, false );
  }

  wxGetApp().enableGrid( event.IsChecked() );
}

void FrameMain::OnMenuZoomIn(wxCommandEvent& WXUNUSED(event))
{
  theDocument->setPixelsPerMeter( theDocument->getPixelsPerMeter() * 1.333 );
  refreshCanvas();

}
void FrameMain::OnMenuZoomOut(wxCommandEvent& WXUNUSED(event))
{
  theDocument->setPixelsPerMeter( theDocument->getPixelsPerMeter() * (1.0/1.333) );
  refreshCanvas();
}

void FrameMain::OnMenuZoomReset(wxCommandEvent& WXUNUSED(event))
{
  theDocument->setPixelsPerMeter( 10.0 );
  refreshCanvas();
}



void FrameMain::OnMenuFond(wxCommandEvent& event)
{
  if(m_img_fond_ecran.Ok())
  {

    DlgQuestion dlg(this,RS_DIALOG_WARNING,RS_FILE_DIALOG_BITMAP_CHOIX,RS_FILE_DIALOG_BITMAP_CHOIX_BUTTON);
    int result = dlg.ShowModal();

    //wxSingleChoiceDialog dialog(this, RS_FILE_DIALOG_BITMAP_CHOIX, RS_DIALOG_WARNING , 2, RS_FILE_DIALOG_BITMAP_CHOIX_BUTTON, NULL);//, wxCENTRE);
    //wxMessageDialog dialog(this, RS_DIALOG_WARNING, RS_FILE_DIALOG_BITMAP_CHOIX);
    //dialog.SetSelection(1);
    if(result == 2)
      return;

    if(result == 0)
    {
      // efface le fond d'�cran
      // TO DO : appeler la fonction qui va bien.
      m_img_fond_ecran.Destroy();     
      m_canvas[m_notebook->GetSelection()]->setBkgrdChange(true);
      refreshCanvas();
      return;
    }
  }
  wxString default_path= _T("");
  static wxString s_extDef;
  wxString path = wxFileSelector(RS_FILE_DIALOG_OPEN_TITLE, default_path, _T(""),s_extDef, RS_FILE_DIALOG_OPEN_WILDCARD,wxCHANGE_DIR, this);
  if ( !path )
    return;
  /*
  // choix de la taille en M2
  wxTextEntryDialog ted(this, RS_FILE_DIALOG_TAILLE_M, RS_FILE_DIALOG_TAILLE_M_TITRE, _T("1.0"),wxOK| wxCENTRE);
  ted.ShowModal();
  double d;
  ted.GetValue().ToDouble(&d);
  m_size_fond_ecran = (float) d; 
  */
  wxImage img;
  if(img.LoadFile(path))
  {
    if(m_img_fond_ecran.Ok()) m_img_fond_ecran.Destroy();
    m_img_fond_ecran = img;
    m_canvas[m_notebook->GetSelection()]->setBkgrdChange(true);
  }else
  {
    wxMessageDialog dialog(this, RS_DIALOG_ERREUR, RS_FILE_DIALOG_BITMAP_ERREUR, wxCANCEL | wxCENTRE);
    dialog.ShowModal();
  }
  refreshCanvas();
}
