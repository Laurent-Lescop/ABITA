#include "precompiled.h"
#include "EditContext.h"

//----------------------------------------------------------------------------

EditContext theEditContext;

//----------------------------------------------------------------------------

void EditContext::resetContext()
{
  m_nearVertices.resize(0);
  m_nearEdges.resize(0);
  m_nearPolygon = MeshConnected::INVALID_HANDLE;
}

//----------------------------------------------------------------------------

void EditContext::setContext( std::vector<MeshConnected::VertexHandle> const& nearVertices )
{
  m_nearVertices = nearVertices;
  m_nearEdges.resize(0);
  m_nearPolygon = MeshConnected::INVALID_HANDLE;
}

//----------------------------------------------------------------------------

void EditContext::setContext( std::vector<MeshConnected::EdgeHandle> const& nearEdges )
{
  m_nearVertices.resize(0);
  m_nearEdges = nearEdges;
  m_nearPolygon = MeshConnected::INVALID_HANDLE;
}

//----------------------------------------------------------------------------

void EditContext::setContext( MeshConnected::PolygonHandle insidePolygon )
{
  m_nearVertices.resize(0);
  m_nearEdges.resize(0);
  m_nearPolygon = insidePolygon;
}

//----------------------------------------------------------------------------

bool EditContext::isNearNothing() const
{
  return (m_nearVertices.empty() && m_nearEdges.empty() && m_nearPolygon == MeshConnected::INVALID_HANDLE);
}

//----------------------------------------------------------------------------

bool EditContext::isNearUniqueVertex() const
{
  return (m_nearVertices.size() == 1);
}

bool EditContext::isNearUniqueEdge() const
{
  return (m_nearEdges.size() == 1);
}

bool EditContext::isNearUniquePolygon() const
{
  return (m_nearPolygon != MeshConnected::INVALID_HANDLE);
}

//----------------------------------------------------------------------------

bool EditContext::isNearVertex( MeshConnected::VertexHandle handle )
{
  unsigned const numVertices = m_nearVertices.size();
  for (unsigned v=0; v<numVertices; v++)
  {
    if (m_nearVertices[v] == handle)
      return true;
  }
  return false;
}

//----------------------------------------------------------------------------

MeshConnected::VertexHandle EditContext::getNearVertex() const
{
  _ASSERT( isNearUniqueVertex() );
  if (m_nearVertices.empty())
  {
    return MeshConnected::INVALID_HANDLE;
  }
  else
  {
    return m_nearVertices[0];
  }
}

void EditContext::getNearVertices(std::vector<MeshConnected::VertexHandle>& result) const
{
  result = m_nearVertices;
}

//----------------------------------------------------------------------------

MeshConnected::EdgeHandle EditContext::getNearEdge() const
{
  _ASSERT( isNearUniqueEdge() );
  if (m_nearEdges.empty())
  {
    return MeshConnected::INVALID_HANDLE;
  }
  else
  {
    return m_nearEdges[0];
  }
}

void EditContext::getNearEdges(std::vector<MeshConnected::EdgeHandle>& result) const
{
  result = m_nearEdges;
}

//----------------------------------------------------------------------------

MeshConnected::PolygonHandle EditContext::getNearPolygon() const
{
  return m_nearPolygon;
}

//----------------------------------------------------------------------------

namespace {

//----------------------------------------------------------------------------

bool nearBy(wxPoint const& a, wxPoint const& b, unsigned sensitivity)
{
  return ( fabsf(a.x-b.x) <= sensitivity && fabsf(a.y-b.y) <= sensitivity );
}

//----------------------------------------------------------------------------

bool nearEdge(wxPoint const& mousePosition, wxPoint const& edge_a, wxPoint const& edge_b, unsigned sensitivity)
{
  Point2d a( edge_a.x, edge_a.y );
  Point2d b( edge_b.x, edge_b.y );
  Point2d m( mousePosition.x, mousePosition.y );

  Point2d dir = b - a;

  float t0 = (dir * (m - a)) / (dir * dir);
  Point2d nearestPoint;
  if (t0 < 0) nearestPoint = a;
  else
  {
    if (t0 > 1) nearestPoint = b;
    else
    {
      nearestPoint = a + (dir * t0);
    }
  }

  Point2d mToNearest = nearestPoint - m;
  if (mToNearest.squareLength() > sensitivity*sensitivity)
    return false;
  else
    return true;
}

//----------------------------------------------------------------------------

bool insidePolygon( Point2d const& mouse, std::vector<Point2d> const& points )
{
  Point2d prevPnt = points.back();
  bool flag1 = (mouse.y >= prevPnt.y);
  bool inside = false;
  unsigned const numV = points.size();

  for (unsigned v=0; v<numV; v++)
  {
    Point2d pnt = points[v];
    bool flag2 = (mouse.y >= pnt.y);

    if (flag1 != flag2)
    {
      bool flag3 = ((pnt.y - mouse.y) * (prevPnt.x - pnt.x) >=
                    (pnt.x - mouse.x) * (prevPnt.y - pnt.y));

      if (flag3 == flag2)
        inside = !inside;
    }

    prevPnt = pnt;
    flag1 = flag2;
  }

  return inside;
}

//----------------------------------------------------------------------------

};

void EditContext::populate( wxPoint const& mousePosition, unsigned sensitivity )
{
  Document const& doc = *theDocument;
  MeshConnected const& shape = doc.getShape();

  resetContext();

  //--- polygons
  {
    std::vector<MeshConnected::PolygonHandle> nearElems;
    std::vector<MeshConnected::VertexHandle> verts;
    std::vector<Point2d> vertPos;

    Point2d mPosition = doc.convert( mousePosition );

    MeshConnected::polygon_const_iterator it  = shape.polygons_begin();
    MeshConnected::polygon_const_iterator end = shape.polygons_end();
    while (it != end)
    {
      MeshConnected::PolygonHandle handle = (*it);

      verts.resize(0);
      shape.findVertices( handle, verts );

      unsigned const numV = verts.size();
      vertPos.resize(0);
      vertPos.reserve(numV);
      for (unsigned v=0; v<numV; v++)
      {
        MeshConnected::VertexData* vdata = shape.getVertexData( verts[v] );
        vertPos.push_back( vdata->position );
      }

      if (insidePolygon(mPosition, vertPos))
      {
        setContext( handle );
      }

      ++it;
    }
  }
  //--- edges
  {
    std::vector<MeshConnected::EdgeHandle> nearElems;
    MeshConnected::vertex_const_iterator it  = shape.edges_begin();
    MeshConnected::vertex_const_iterator end = shape.edges_end();
    while (it != end)
    {
      MeshConnected::EdgeHandle handle = (*it);

      MeshConnected::VertexHandle verts[2];
      shape.findVertices( handle, verts );

      MeshConnected::VertexData* vdata[2];
      vdata[0] = shape.getVertexData( verts[0] );
      vdata[1] = shape.getVertexData( verts[1] );

      if (nearEdge(mousePosition, doc.convert(vdata[0]->position), doc.convert(vdata[1]->position), sensitivity ))
        nearElems.push_back( handle );

      ++it;
    }
    if (!nearElems.empty())
      setContext( nearElems );
  }
  //--- vertices
  {
    std::vector<MeshConnected::VertexHandle> nearVertices;
    MeshConnected::vertex_const_iterator v_it  = shape.vertices_begin();
    MeshConnected::vertex_const_iterator v_end = shape.vertices_end();
    while (v_it != v_end)
    {
      MeshConnected::VertexHandle vertex = (*v_it);
      MeshConnected::VertexData* vdata = shape.getVertexData(vertex);
      
      wxPoint position = doc.convert( vdata->position );

      if (nearBy(position, mousePosition, sensitivity))
        nearVertices.push_back( vertex );

      ++v_it;
    }

    if (!nearVertices.empty())
      setContext( nearVertices );
  }
}

//----------------------------------------------------------------------------

