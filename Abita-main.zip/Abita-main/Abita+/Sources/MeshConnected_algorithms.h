#ifndef MG_MESH_CONNECTED_ALGORITHMS_H
#define MG_MESH_CONNECTED_ALGORITHMS_H

#include "MeshConnected.h"

//----------------------------------------------------------------------------

void computePolygonArea( MeshConnected const& mesh, MeshConnected::PolygonHandle th,
                         float &area, float &perimeter);

bool segmentPolygonOverlap( MeshConnected const& mesh, MeshConnected::PolygonHandle poly,
                            Point2d const& segment_a, Point2d const& segment_b );

void cutMesh(MeshConnected& mesh, Point2d const& segment_a, Point2d const& segment_b);

void removeEdge( MeshConnected& mesh, MeshConnected::EdgeHandle eh );
void removeVertex( MeshConnected& mesh, MeshConnected::VertexHandle vh );

//! merge vertices vh[0] & vh[1] ( by replacing vh[0] by vh[1] )
void mergeVertices( MeshConnected& mesh, MeshConnected::VertexHandle vh[2] );

bool isInsidePolygon( Point2d const& point, MeshConnected const& mesh, MeshConnected::PolygonHandle ph );

//----------------------------------------------------------------------------

#endif