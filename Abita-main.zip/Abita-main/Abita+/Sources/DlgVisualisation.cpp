#include "precompiled.h"
#include "DlgVisualisation.h"

#include <limits>

#include "InterfaceSolveur.h"
#include "MeshConnected_algorithms.h"
#include "Solveur/Lot.h"
#include "wxUtilities.h"

const unsigned size_iconX = 24;
const unsigned size_iconY = 24;

const unsigned splitterSizeX = 256;

const wxColour colourT1 = wxColour(124,235,122);
const wxColour colourT2 = wxColour(122,234,235);
const wxColour colourT3 = wxColour(122,159,235);
const wxColour colourT4 = wxColour(204,122,235);
const wxColour colourT5 = wxColour(235,122,178);

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

namespace {

  void computeTypeDistribution(CSolution const& solution, unsigned distrib[6])
  {
    distrib[0] = distrib[1] = distrib[2] = 0;
    distrib[3] = distrib[4] = distrib[5] = 0;

    for (int lotID=0; lotID<solution.NbLots; lotID++)
    {
      CLot const* lot = solution.LotList[lotID];
      if (!lot->Common)
      {
        ++distrib[ lot->TypeNo ];
        ++distrib[ 5 ];
      }
    }
  }

};

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

IMPLEMENT_DYNAMIC_CLASS(CanvasVisualisation, wxScrolledWindow)

//----------------------------------------------------------------------------

BEGIN_EVENT_TABLE(CanvasVisualisation, wxScrolledWindow)

EVT_PAINT(        CanvasVisualisation::OnPaint)
EVT_SIZE(         CanvasVisualisation::OnSize)
EVT_MOUSE_EVENTS( CanvasVisualisation::OnMouseEvent)
EVT_SCROLLWIN(  CanvasVisualisation::OnScroll)
END_EVENT_TABLE()

//----------------------------------------------------------------------------

CanvasVisualisation::CanvasVisualisation( wxWindow *parent, wxWindowID id, const wxPoint &pos, const wxSize &size )
: wxScrolledWindow( parent, id, pos, size, wxSUNKEN_BORDER | wxTAB_TRAVERSAL, _T("") )
{
  SetScrollRate( 5, 5 );
  SetBackgroundColour( *wxWHITE );
  wxToolTip::SetDelay(0);
}

//----------------------------------------------------------------------------

CanvasVisualisation::~CanvasVisualisation()
{
}

//----------------------------------------------------------------------------

void CanvasVisualisation::setSolution(std::auto_ptr<Solution> solution)
{
  m_solution = solution;
  setSize();
  Refresh();
}


//----------------------------------------------------------------------------

void CanvasVisualisation::setSize()
{
  float xmin = std::numeric_limits<float>::max(), xmax = -std::numeric_limits<float>::max();
  float ymin = std::numeric_limits<float>::max(), ymax = -std::numeric_limits<float>::max();

  if (m_solution.get() != NULL)
  {
    unsigned const numLots = m_solution->numLots();
    for (unsigned lotID=0; lotID<numLots; lotID++)
    {
      Solution::Lot const& lot = m_solution->getLot(lotID);
      MeshConnected const& shape = lot.getShape();
      MeshConnected::vertex_const_iterator vit = shape.vertices_begin();
      MeshConnected::vertex_const_iterator vend = shape.vertices_end();
      while (vit != vend)
      {
        MeshConnected::VertexData const* vdata = shape.getVertexData(*vit);

        xmin = std::min(xmin, vdata->position.x);
        xmax = std::max(xmax, vdata->position.x);
        ymin = std::min(ymin, vdata->position.y);
        ymax = std::max(ymax, vdata->position.y);

        ++vit;
      }
    }
  }

  float dx = (xmax - xmin);
  float dy = (ymax - ymin);

  float const VIEW_MARGIN = 0.05f;
  float viewSize = std::max(dx, dy) * (1.f + VIEW_MARGIN);

  float xcenter = (xmax + xmin) * 0.5f;
  float ycenter = (ymax + ymin) * 0.5f;

  m_minX = xcenter - viewSize*0.5f;
  m_maxX = xcenter + viewSize*0.5f;
  m_minY = ycenter - viewSize*0.5f;
  m_maxY = ycenter + viewSize*0.5f;
}

//----------------------------------------------------------------------------

void CanvasVisualisation::OnSize(wxSizeEvent& event)
{
  wxScrolledWindow::OnSize(event);

  wxSize const& size = event.GetSize();

  if (size.y >= size.x)
  {
    unsigned baseSize = size.y-16;
    unsigned otherSize = int( float(baseSize) * theDocument->getSizeX() / theDocument->getSizeY() )+1;
    SetVirtualSize( otherSize, baseSize );
  }
  else
  {
    unsigned baseSize = size.x-16;
    unsigned otherSize = int( float(baseSize) * theDocument->getSizeY() / theDocument->getSizeX() )+1;
    SetVirtualSize( baseSize, otherSize );
  }

  event.Skip();
}

//----------------------------------------------------------------------------

void CanvasVisualisation::OnScroll(wxScrollWinEvent &e)
{
  Refresh();
  e.Skip();
}


//----------------------------------------------------------------------------

wxPoint CanvasVisualisation::convert(wxSize const& clientSize, Point2d const& position) const
{
  int x = ((position.x - m_minX) / (m_maxX - m_minX)) * float(clientSize.x);
  int y = ((position.y - m_minY) / (m_maxY - m_minY)) * float(clientSize.y);
  return wxPoint(x, y);
}

//----------------------------------------------------------------------------

void CanvasVisualisation::PrepareDC(wxDC& dc)
{
  wxScrolledWindow::PrepareDC( dc );

  wxSize const size = GetVirtualSize();

  double scaleX = 1.0 / (double(theDocument->getSizeX() * Document::POINT_PRECISION) / double(size.GetWidth()));
  double scaleY = 1.0 / (double(theDocument->getSizeY() * Document::POINT_PRECISION) / double(size.GetHeight()));
  dc.SetUserScale( scaleX, scaleY );  
}

//----------------------------------------------------------------------------


void CanvasVisualisation::OnPaint( wxPaintEvent &event )
{
  wxPaintDC dc( this );
  PrepareDC(dc);

  wxSize const clientSize = GetClientSize();

  if (m_solution.get() != NULL)
  {
    unsigned const numLots = m_solution->numLots();
    for (unsigned lotID=0; lotID<numLots; lotID++)
    {
      Solution::Lot const& lot = m_solution->getLot(lotID);
      MeshConnected const& shape = lot.getShape();

      //- draw lot background

      dc.SetPen( *wxTRANSPARENT_PEN );
      {
        MeshConnected::polygon_const_iterator pit = shape.polygons_begin();
        MeshConnected::polygon_const_iterator pend = shape.polygons_end();
        while (pit != pend)
        {
          if (lotID == 0)
          {
            // element commun
            drawPolygon(dc, shape, *pit, P_DONT_CARE);
          }
          else
          {
            _ASSERT( lot.getType() != Solution::Lot::COMMON );
            static wxColour const colors[] = {  colourT1, colourT2, colourT3,colourT4,colourT5 };

            unsigned colorIndex = lot.getType() - Solution::Lot::T1;
            dc.SetBrush( wxBrush( colors[colorIndex], wxSOLID ) );
            drawPolygon(dc, shape, *pit, P_USER_COLOR);
          }
          ++pit;
        }
      }

      //- draw lot contour

      dc.SetPen( *wxBLACK_PEN );
      {
        MeshConnected::edge_const_iterator eit = shape.edges_begin();
        MeshConnected::edge_const_iterator eend = shape.edges_end();
        while (eit != eend)
        {
          MeshConnected::EdgeHandle eh = *eit;
          std::vector<MeshConnected::PolygonHandle> polygons;
          shape.findAdjacentPolygons(eh, polygons);
          if (polygons.size() < 2)
          {
            drawEdge(dc, shape, eh, E_DONT_CARE);
          }
          ++eit;
        }
      }
    }
  }
  {
    wxClientDC dc(this);

    // draw echelle

    Document const& doc = *theDocument;

    const unsigned n_metres = 5;
    const unsigned epaisseur_bord = 10;
    const unsigned epaisseur = 5; 

    int sx,sy;
    sx = 16;
    sy = 16;
    unsigned m = doc.getPixelsPerMeter();

    dc.SetPen( *wxBLACK_PEN );
    dc.SetBrush( *wxBLACK_BRUSH );
    dc.DrawLine(sx, sy, sx + m*n_metres, sy);
    dc.DrawLine(sx, sy, sx, sy+epaisseur_bord);dc.DrawLine(sx+1, sy, sx+1, sy+epaisseur_bord);
    dc.DrawLine(sx+ m *n_metres, sy, sx+ m*n_metres, sy+epaisseur_bord);dc.DrawLine(sx+1+ m*n_metres, sy, sx+1+ m*n_metres, sy+epaisseur_bord);
    for(unsigned t=1;t<n_metres;t++)
      dc.DrawLine(sx+ m*t, sy, sx + m*t, sy+epaisseur);
    dc.DrawText(wxString::Format(RS_CANVAS_ECHELLE,n_metres), sx, sy+10);
  }
}


void CanvasVisualisation::OnMouseEvent(wxMouseEvent& event)
{
  wxPoint position = event.GetPosition();

  wxClientDC dc(this);
  PrepareDC(dc);

  position.x = dc.DeviceToLogicalX(position.x);
  position.y = dc.DeviceToLogicalY(position.y);

  Point2d mousePosition = theDocument->convert( position );

  if (m_solution.get() != NULL)
  {
    bool mouseInside = false;

    unsigned const numLots = m_solution->numLots();
    for (unsigned lotID=0; lotID<numLots && !mouseInside; lotID++)
    {
      Solution::Lot const& lot = m_solution->getLot(lotID);
      MeshConnected const& shape = lot.getShape();

      MeshConnected::polygon_const_iterator pit = shape.polygons_begin();
      MeshConnected::polygon_const_iterator pend = shape.polygons_end();
      while (pit != pend && !mouseInside)
      {
        if (isInsidePolygon(mousePosition, shape, *pit))
        {
          wxString strings[] = { RS_DIALOG_VISU_TYPE_COMMUN, RS_PROPRIETE_T1, RS_PROPRIETE_T2, RS_PROPRIETE_T3, RS_PROPRIETE_T4, RS_PROPRIETE_T5 };
          wxString const& typeString = strings[ lot.getType() ];
          SetToolTip( wxString::Format(RS_DIALOG_VISU_INFOS_LOT, typeString.GetData(), lot.getArea(), lot.getBenefit()) );

          mouseInside = true;
        }
        ++pit;
      }
    }

    if (!mouseInside)
      SetToolTip(_T(""));
  }

  event.Skip();
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

enum ID_CONTROLS_VISUALISATION
{
  ID_NOTEBOOK = 1,
  ID_SOLUTION_LIST,
  ID_VISUALISATION_BUTT = 10000,
  ID_VISUALISATION_QUIT,
  ID_VISUALISATION_IMPRIMER,
  ID_VISUALISATION_EXPORTER,
  ID_VISUALISATION_OK
};

//----------------------------------------------------------------------------

BEGIN_EVENT_TABLE(DlgVisualisation, wxFrame)
  
  EVT_MENU( ID_VISUALISATION_QUIT,  DlgVisualisation::OnQuit  )
  EVT_SIZE( DlgVisualisation::OnSize )
  EVT_LIST_ITEM_SELECTED( ID_SOLUTION_LIST, DlgVisualisation::OnSolutionSelected ) 
  EVT_BUTTON(ID_VISUALISATION_IMPRIMER, DlgVisualisation::OnButtonImprimer)
  EVT_BUTTON(ID_VISUALISATION_EXPORTER, DlgVisualisation::OnButtonExporter)
  EVT_BUTTON(ID_VISUALISATION_OK, DlgVisualisation::OnButtonOk)
  EVT_LIST_COL_CLICK(ID_SOLUTION_LIST, DlgVisualisation::OnListColClick) 

END_EVENT_TABLE()

//----------------------------------------------------------------------------

wxBitmap DlgVisualisation::createFilledBitmap(wxColour c)
{
  wxBitmap bmpBtn(size_iconX,size_iconY);
  wxMemoryDC dcBtn;
  dcBtn.SelectObject( bmpBtn );
  dcBtn.SetPen( *wxBLACK_PEN );
  dcBtn.SetBrush( wxBrush( c, wxSOLID ) );
  dcBtn.DrawRectangle(0, 0, size_iconX,size_iconY);
  dcBtn.SelectObject(wxNullBitmap);
  return bmpBtn;
}
//----------------------------------------------------------------------------

wxBitmap DlgVisualisation::drawSolutionsChart(unsigned graphicSizeX,unsigned graphicSizeY,float currentPos)
{

  float maxFitness = 0.0;
  float minFitness = FLT_MAX;

  unsigned countItem = 0;
  long item = -1;
  for ( ;; )
  {
    item = m_solutionsList->GetNextItem(item);
    if ( item == -1 )
      break;

    unsigned solutionID = m_solutionsList->GetItemData(item);
    if(m_population.SolutionList[solutionID]->Fitness > maxFitness) maxFitness = m_population.SolutionList[solutionID]->Fitness;
    if(m_population.SolutionList[solutionID]->Fitness < minFitness) minFitness = m_population.SolutionList[solutionID]->Fitness;
    countItem ++;
  }

  wxBitmap bmp(graphicSizeX,graphicSizeY);  
  wxMemoryDC dc;
  dc.SelectObject( bmp );

  dc.SetPen( *wxWHITE_PEN );
  dc.DrawRectangle(0, 0, graphicSizeX,graphicSizeY);

  float depY = float(graphicSizeY) / (float(maxFitness) - float(minFitness));
  float sol = 0.0;

  dc.SetPen( *wxRED_PEN );

  if (countItem > 0)
  {
    if(countItem > graphicSizeX )
    {
      float depX = float(countItem) / float(graphicSizeX);

      unsigned solutionID = m_solutionsList->GetItemData(0);
      int oldY = int((m_population.SolutionList[solutionID]->Fitness - minFitness) * depY);
      int oldX = 0;

      for(unsigned x=1;x<graphicSizeX;x++)
      {
        sol += depX;
        solutionID = m_solutionsList->GetItemData(int(sol));
        int y = int((m_population.SolutionList[solutionID]->Fitness - minFitness) * depY);
        dc.DrawLine(x, graphicSizeY - y, oldX,  graphicSizeY - oldY);
        oldX = x;
        oldY = y;
      }

      if(currentPos != -1.0)
      { 
        currentPos *= depX;
        dc.SetPen( *wxGREY_PEN );
        dc.DrawLine(int(currentPos),  0, int(currentPos),  graphicSizeY);
      }
    }
    else
    {
      float depX = float(graphicSizeX) / float(countItem);

      unsigned solutionID = m_solutionsList->GetItemData(0);
      int oldY = int((m_population.SolutionList[solutionID]->Fitness - minFitness) * depY);
      int oldX = 0;

      for(int x=1;x<countItem;x++)
      {
        solutionID = m_solutionsList->GetItemData(x);
        int y = int((m_population.SolutionList[solutionID]->Fitness - minFitness) * depY);
        int newX = int(float(x) * depX);
        dc.DrawLine(newX,  graphicSizeY - y, oldX,  graphicSizeY - oldY);
        oldX = newX;
        oldY = y;
      }
      if(currentPos != -1.0)
      { 
        currentPos *= depX;
        dc.SetPen( *wxGREY_PEN );
        dc.DrawLine(int(currentPos),  0, int(currentPos),  graphicSizeY);
      }
    }
  }
  //dc.EndDrawing();
  dc.SelectObject(wxNullBitmap);
  return bmp;
}


DlgVisualisation::DlgVisualisation( CPopulation& population, wxWindow* parent, wxString title,wxSize size )
: wxFrame( parent, -1, title, wxDefaultPosition, size, wxDEFAULT_FRAME_STYLE),
m_population( population )
{
  //MakeModal(true);
  m_splitter.reset( new wxSplitterWindow(this, -1,wxDefaultPosition, wxDefaultSize, 0) );

  m_currentIndexItem = 0;

  //-------------------------------------------------------------
  //- right pane : visualisation
  //-------------------------------------------------------------

  m_rightPanel = new wxPanel( m_splitter.get() );
  wxBoxSizer *sizer0 = new wxBoxSizer( wxVERTICAL );

  m_noteBook = new wxNotebook(m_rightPanel, ID_NOTEBOOK);

  unsigned numFloors = theDocument->getNumFloors();
  for (unsigned floor=1; floor <= numFloors; floor++)
  {
    std::auto_ptr<CanvasVisualisation> visu( new CanvasVisualisation(m_noteBook, -1, wxPoint(0,0), wxSize(0,0)) );
    m_canvasEtages.push_back( visu.get() );
    m_noteBook->AddPage( visu.release(), RS_ETAGE + wxString::Format(" %d",floor - 1), false );
  }

  m_noteBook->SetSelection(0);  

  sizer0->Add( m_noteBook, 1, wxGROW | wxALL );

  // icones de type d'appartements

  wxStaticBox *item30 = new wxStaticBox( m_rightPanel, -1, RS_INFORMATIONS_TYPE,wxDefaultPosition, wxSize(200,48));
  wxStaticBoxSizer *item20 = new wxStaticBoxSizer( item30, wxHORIZONTAL );
  //m_stats_text = new wxStaticText( m_rightPanel, -1, RS_INFORMATIONS_DEFAULT, wxDefaultPosition, wxSize(-1,48), 0 );


  wxStaticText *st1 = new wxStaticText(m_rightPanel,-1,"T1:");
  item20->Add( st1, 0, wxALIGN_CENTRE|wxALL, 5 );
  wxStaticBitmap *legend1 = new wxStaticBitmap( m_rightPanel, -1, createFilledBitmap(colourT1));
  item20->Add( legend1, 0, wxALIGN_CENTRE|wxALL, 5 );
  wxStaticText *st2 = new wxStaticText(m_rightPanel,-1,"T2:");
  item20->Add( st2, 0, wxALIGN_CENTRE|wxALL, 5 );
  wxStaticBitmap *legend2 = new wxStaticBitmap( m_rightPanel, -1, createFilledBitmap(colourT2));
  item20->Add( legend2, 0, wxALIGN_CENTRE|wxALL, 5 );
  wxStaticText *st3 = new wxStaticText(m_rightPanel,-1,"T3:");
  item20->Add( st3, 0, wxALIGN_CENTRE|wxALL, 5 );
  wxStaticBitmap *legend3 = new wxStaticBitmap( m_rightPanel, -1, createFilledBitmap(colourT3));
  item20->Add( legend3, 0, wxALIGN_CENTRE|wxALL, 5 );
  wxStaticText *st4 = new wxStaticText(m_rightPanel,-1,"T4:");
  item20->Add( st4, 0, wxALIGN_CENTRE|wxALL, 5 );
  wxStaticBitmap *legend4 = new wxStaticBitmap( m_rightPanel, -1, createFilledBitmap(colourT4));
  item20->Add( legend4, 0, wxALIGN_CENTRE|wxALL, 5 );
  wxStaticText *st5 = new wxStaticText(m_rightPanel,-1,"T5:");
  item20->Add( st5, 0, wxALIGN_CENTRE|wxALL, 5 );
  wxStaticBitmap *legend5 = new wxStaticBitmap( m_rightPanel, -1, createFilledBitmap(colourT5));
  item20->Add( legend5, 0, wxALIGN_CENTRE|wxALL, 5 );

  sizer0->Add( item20, 0, wxALIGN_CENTRE | wxALL );

  // boutons de resultats

  wxBoxSizer *item16 = new wxBoxSizer( wxHORIZONTAL );

  wxButton *item17 = new wxButton( m_rightPanel, ID_VISUALISATION_IMPRIMER, RS_DIALOG_VISU_IMPRIMER, wxDefaultPosition, wxDefaultSize, 0 );
  item16->Add( item17, 0, wxALIGN_CENTRE|wxALL, 5 );

  wxButton *item19 = new wxButton( m_rightPanel, ID_VISUALISATION_EXPORTER, RS_DIALOG_VISU_EXPORTER, wxDefaultPosition, wxDefaultSize, 0 );
  item16->Add( item19, 0, wxALIGN_CENTRE|wxALL, 5 );

  wxButton *item18 = new wxButton( m_rightPanel, ID_VISUALISATION_OK, RS_DIALOG_FERMER, wxDefaultPosition, wxDefaultSize, 0 );
  item18->SetDefault();
  item16->Add( item18, 0, wxALIGN_CENTRE|wxALL, 5 );

  sizer0->Add( item16, 0, wxALIGN_CENTRE|wxALL );

  m_rightPanel->SetAutoLayout( TRUE );
  m_rightPanel->SetSizer( sizer0 );
  sizer0->Fit( m_rightPanel );
  sizer0->SetSizeHints( m_rightPanel );

  //-------------------------------------------------------------
  //- left pane
  //-------------------------------------------------------------

  m_leftPanel = new wxPanel( m_splitter.get() );

  wxBoxSizer *sizer = new wxBoxSizer( wxVERTICAL );

  // graphique

  wstb = new wxStaticBitmap(m_leftPanel,-1,wxBitmap(splitterSizeX,128));

  sizer->Add( wstb, 0, wxALIGN_CENTRE | wxALL );

  //--- list of solutions

  m_solutionsList = new wxListCtrl( m_leftPanel, ID_SOLUTION_LIST, wxDefaultPosition, wxSize(splitterSizeX,-1), wxLC_REPORT | wxSUNKEN_BORDER | wxLC_SINGLE_SEL );
  m_solutionsList->InsertColumn(0, RS_DIALOG_VISU_COLONNE_SOLUTION);
  m_solutionsList->InsertColumn(1, RS_DIALOG_VISU_COLONNE_VALEUR);
  m_solutionsList->InsertColumn(2, RS_PROPRIETE_T1);
  m_solutionsList->InsertColumn(3, RS_PROPRIETE_T2);
  m_solutionsList->InsertColumn(4, RS_PROPRIETE_T3);
  m_solutionsList->InsertColumn(5, RS_PROPRIETE_T4);
  m_solutionsList->InsertColumn(6, RS_PROPRIETE_T5);
  m_solutionsList->InsertColumn(7, RS_DIALOG_VISU_COLONNE_TOTAL);
  m_solutionsList->SetColumnWidth(0, wxLIST_AUTOSIZE_USEHEADER);
  m_solutionsList->SetColumnWidth(1, wxLIST_AUTOSIZE_USEHEADER);
  m_solutionsList->SetColumnWidth(2, wxLIST_AUTOSIZE_USEHEADER);
  m_solutionsList->SetColumnWidth(3, wxLIST_AUTOSIZE_USEHEADER);
  m_solutionsList->SetColumnWidth(4, wxLIST_AUTOSIZE_USEHEADER);
  m_solutionsList->SetColumnWidth(5, wxLIST_AUTOSIZE_USEHEADER);
  m_solutionsList->SetColumnWidth(6, wxLIST_AUTOSIZE_USEHEADER);
  m_solutionsList->SetColumnWidth(7, wxLIST_AUTOSIZE_USEHEADER);
  m_solutionsList->SetSize(-1,-1);
  sizer->Add( m_solutionsList, 1, wxGROW | wxALL );

  //-

  m_solutionsList->Show(false);
//  m_reel_count_solution = 0;
  for (int sol=0; sol<m_population.NbSolutions; sol++)
  {
    CSolution const* solution = m_population.SolutionList[sol];

    if(solution->Fitness > 0.0)
    {
      long id = m_solutionsList->InsertItem(sol, wxString::Format("%d", sol));
      m_solutionsList->SetItemData( id, sol );
      m_solutionsList->SetItem(id, 1, wxString::Format("%2.1f", solution->Fitness));

      unsigned numTypes[] = { 0, 0, 0, 0, 0, 0 };
      computeTypeDistribution( *solution, numTypes );

      m_solutionsList->SetItem(id, 2, wxString::Format("%d", numTypes[0]));
      m_solutionsList->SetItem(id, 3, wxString::Format("%d", numTypes[1]));
      m_solutionsList->SetItem(id, 4, wxString::Format("%d", numTypes[2]));
      m_solutionsList->SetItem(id, 5, wxString::Format("%d", numTypes[3]));
      m_solutionsList->SetItem(id, 6, wxString::Format("%d", numTypes[4]));
      m_solutionsList->SetItem(id, 7, wxString::Format("%d", numTypes[5]));

      //m_reel_count_solution++;
    }
  }
  m_solutionsList->SetItemState(0, wxLIST_STATE_SELECTED, wxLIST_STATE_SELECTED);
  m_solutionsList->Show(true);

  //---
  // set bitmap for the chart

  wstb->SetBitmap(drawSolutionsChart(splitterSizeX,128));

  // --

  m_leftPanel->SetAutoLayout( TRUE );
  m_leftPanel->SetSizer( sizer );
  sizer->Fit( m_leftPanel );
  sizer->SetSizeHints( m_leftPanel );

  m_splitter->Initialize(m_rightPanel);
  m_splitter->SplitVertically( m_leftPanel, m_rightPanel, /*sizer->GetMinSize().x*/splitterSizeX );

#ifdef __WXMSW__
  SendSizeEvent();
#endif

  GetParent()->Enable(false);
}

//----------------------------------------------------------------------------

DlgVisualisation::~DlgVisualisation()
{
  GetParent()->Enable(true);
}

//----------------------------------------------------------------------------

void DlgVisualisation::OnQuit( wxCommandEvent& event )
{
  //MakeModal(false);

  Show( FALSE ); // TRICK:: hide it, to avoid flickered destruction
  Close(TRUE);
}

//----------------------------------------------------------------------------

void DlgVisualisation::OnSize(wxSizeEvent& event)
{
  wxSize const size = GetClientSize();
  //m_noteBook->SetSize(0, 0, size.x, size.y);

  m_splitter->SetSize(0, 0, size.x, size.y);

  event.Skip();
}

//----------------------------------------------------------------------------

void DlgVisualisation::OnSolutionSelected(wxListEvent& event)
{
  long index = event.GetIndex();
  m_currentIndexItem = index;
  long solutionID = m_solutionsList->GetItemData(index);

  unsigned const numFloors = theDocument->getNumFloors();
  for (unsigned floor=0; floor<numFloors; floor++)
  {
    std::auto_ptr<Solution> solution;
    if (solutionID < m_population.NbSolutions)
    {
      solution = convert( *theDocument, *m_population.SolutionList[solutionID], floor );
    }
    m_canvasEtages[floor]->setSolution( solution );
  }
  
  wstb->SetBitmap(drawSolutionsChart(splitterSizeX,128,index/*solutionID*/));

}

//----------------------------------------------------------------------------

void DlgVisualisation::OnButtonImprimer( wxCommandEvent& event )
{
}

//----------------------------------------------------------------------------

void  DlgVisualisation::OnButtonExporter( wxCommandEvent& event )
{
}

//----------------------------------------------------------------------------

void  DlgVisualisation::OnButtonOk( wxCommandEvent& event )
{
    Show( FALSE ); 
    Close(TRUE);
}

//----------------------------------------------------------------------------

namespace {

  extern "C" int wxCALLBACK wxListCompareFunction(long item1, long item2, long sortData);

  int wxCALLBACK wxListCompareFunction(long item1, long item2, long sortData)
  {
    DlgVisualisation* dlgVisu = reinterpret_cast<DlgVisualisation*>(sortData);
    return dlgVisu->compareSolutions(item1, item2);
  }

};

int DlgVisualisation::compareSolutions( long item1, long item2 ) const
{
  CSolution *sol1 = NULL, *sol2 = NULL;
  if (item1 < m_population.NbSolutions) sol1 = m_population.SolutionList[item1];
  if (item2 < m_population.NbSolutions) sol2 = m_population.SolutionList[item2];
  
  int result = 0;
  if (sol1==NULL || sol2==NULL) return result;

  bool inverseResult = false;
  int sortColumn = m_solSortColumn;
  if (sortColumn < 0)
  {
    sortColumn = ~sortColumn;
    inverseResult = true;
  }

  unsigned numTypes1[] = { 0, 0, 0, 0, 0, 0 };
  unsigned numTypes2[] = { 0, 0, 0, 0, 0, 0 };
  computeTypeDistribution(*sol1, numTypes1);
  computeTypeDistribution(*sol2, numTypes2);

  switch (sortColumn)
  {
  case 0:
    result = (item1<item2) ? -1 : ((item1==item2) ? 0 : 1);
    break;
  case 1:
    result = (sol1->Fitness>sol2->Fitness) ? -1 : ((sol1->Fitness==sol2->Fitness) ? 0 : 1);
    break;
  case 2:
  case 3:
  case 4:
  case 5:
  case 6:
  case 7:
    {
      int typeNo = sortColumn-2;
      result = (numTypes1[typeNo]<numTypes2[typeNo]) ? -1 : ((numTypes1[typeNo]==numTypes2[typeNo]) ? 0 : 1);
    }
    break;
  }

  if (inverseResult)
    result = -result;

  return result;
}

void DlgVisualisation::OnListColClick( wxListEvent& event )
{
  if (m_solSortColumn == event.m_col)
  {
    setSolutionsListSortColumn( ~event.m_col );
  }
  else
  {
    setSolutionsListSortColumn( event.m_col );
  }
  m_solutionsList->SortItems( wxListCompareFunction, long(this) );

  // -- redraw chart
  wstb->SetBitmap(drawSolutionsChart(splitterSizeX,128,m_currentIndexItem));

}

//----------------------------------------------------------------------------

