#ifndef ABITA_WX_UTILITIES_H
#define ABITA_WX_UTILITIES_H

//----------------------------------------------------------------------------

inline float wxDistance(wxPoint const& a, wxPoint const& b)
{
  float dx = float( a.x - b.x );
  float dy = float( a.y - b.y );
  return sqrtf(dx*dx + dy*dy);
}

//----------------------------------------------------------------------------

inline void drawCenteredText(wxDC& dc, wxString const& text, wxPoint const& position)
{
  int w, h;
  dc.GetTextExtent( text, &w, &h );

  int px, py;
  px = position.x;
  py = position.y;
  px -= w / 2;
  py -= h / 2;

  dc.DrawText(text, px, py);
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

typedef enum
{
  VH_DONT_CARE,
  VH_OK,
  VH_NOK,
  VH_USER_COLOR
}
VertexHandleStatus;

//----------------------------------------------------------------------------

inline void drawVertexHandle(wxDC& dc, wxPoint const& vertexPos, VertexHandleStatus status)
{
  if (status != VH_USER_COLOR)
  {
    switch (status)
    {
    case VH_DONT_CARE:
      dc.SetBrush( *wxWHITE_BRUSH );
      break;
    case VH_OK:
      dc.SetBrush( *wxGREEN_BRUSH );
      break;
    case VH_NOK:
      dc.SetBrush( *wxRED_BRUSH );
      break;
    }

    dc.SetPen( wxPen( wxColour(0,0,255), 1, wxSOLID) );
  }

  int const HANDLE_SIZE = 9;
  int const TOP_LEFT_OFFSET = (-(HANDLE_SIZE-1)/2);

  int logicalHandleSize = dc.DeviceToLogicalXRel(HANDLE_SIZE);
  int logicalTopLeftOffset = dc.DeviceToLogicalXRel(TOP_LEFT_OFFSET);

  dc.DrawRectangle( vertexPos.x+logicalTopLeftOffset, vertexPos.y+logicalTopLeftOffset, logicalHandleSize, logicalHandleSize );
}

//----------------------------------------------------------------------------

inline void redrawVertexHandles(wxDC& dc, VertexHandleStatus status)
{
  Document const& doc = *theDocument;
  MeshConnected const& shape = doc.getShape();

  MeshConnected::vertex_const_iterator v_it  = shape.vertices_begin();
  MeshConnected::vertex_const_iterator v_end = shape.vertices_end();
  while (v_it != v_end)
  {
    MeshConnected::VertexHandle vertex = (*v_it);
    MeshConnected::VertexData* vdata = shape.getVertexData(vertex);
    
    wxPoint position = doc.convert( vdata->position );
    drawVertexHandle(dc, position, status);

    ++v_it;
  }
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

typedef enum
{
  E_DONT_CARE,
  E_OK,
  E_NOK
}
EdgeStatus;

inline void drawEdge(wxDC& dc, MeshConnected const& shape, MeshConnected::EdgeHandle eh, EdgeStatus status)
{
  Document const& doc = *theDocument;

  std::vector<MeshConnected::PolygonHandle> adjPolygons;
  shape.findAdjacentPolygons( eh, adjPolygons );
  
  if (adjPolygons.size() < 2)
  {
    // contour edge
    switch (status)
    {
    case E_DONT_CARE:
      dc.SetPen( wxPen( wxColour(0,0,0), 1, wxSOLID) );
      break;
    case E_OK:
      dc.SetPen( wxPen( wxColour(0,0,255), 1, wxSOLID) );
      break;
    case E_NOK:
      dc.SetPen( wxPen( wxColour(255,0,0), 1, wxSOLID) );
      break;
    }
  }
  else
  {
    // interior edge
    switch (status)
    {
    case E_DONT_CARE:
      dc.SetPen( wxPen( wxColour(0,155,100), 1, wxSOLID) );
      break;
    case E_OK:
      dc.SetPen( wxPen( wxColour(0,255,0), 1, wxSOLID) );
      break;
    case E_NOK:
      dc.SetPen( wxPen( wxColour(255,0,0), 1, wxSOLID) );
      break;
    }
  }

  MeshConnected::VertexHandle vh[2];
  shape.findVertices( eh, vh );

  MeshConnected::VertexData* vdata[2];
  vdata[0] = shape.getVertexData(vh[0]);
  vdata[1] = shape.getVertexData(vh[1]);

  dc.DrawLine( doc.convert(vdata[0]->position), doc.convert(vdata[1]->position) );
}

//----------------------------------------------------------------------------

inline void redrawEdges(wxDC& dc, MeshConnected const& shape, EdgeStatus status)
{
  MeshConnected::edge_const_iterator e_it = shape.edges_begin();
  MeshConnected::edge_const_iterator e_end = shape.edges_end();
  while (e_it != e_end)
  {
    MeshConnected::EdgeHandle eh = *e_it;

    drawEdge(dc, shape, eh, status);

    ++e_it;
  }
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

typedef enum
{
  P_DONT_CARE,
  P_OK,
  P_NOK,
  P_USER_COLOR
}
PolygonStatus;

inline void drawPolygon(wxDC& dc, MeshConnected const& shape, MeshConnected::PolygonHandle poly, PolygonStatus status)
{
  Document const& doc = *theDocument;

  std::vector<MeshConnected::VertexHandle> vertices;
  std::vector<wxPoint> drawPoints;

  shape.findVertices( poly, vertices );

  MeshConnected::PolygonData* pdata = shape.getPolygonData(poly);

  unsigned const numVertices = vertices.size();
  for (unsigned i=0; i<numVertices; i++)
  {
    MeshConnected::VertexData* vdata = shape.getVertexData( vertices[i] );

    wxPoint vertexDrawPos = doc.convert(vdata->position);
    drawPoints.push_back( vertexDrawPos );
  }

  if (status != P_USER_COLOR)
  {
    dc.SetPen( *wxTRANSPARENT_PEN );
    switch (status)
    {
    case P_DONT_CARE:
      {
        switch (pdata->getType())
        {
        case FREE_PART:
          dc.SetBrush( wxBrush(wxColour(255,200,255), wxSOLID) );
          break;
        case POSSIBLE_COMMON_PART:
          dc.SetBrush( wxBrush(wxColour(200,200,255), wxSOLID) );
          break;
        case IMPOSED_COMMON_PART:
          dc.SetBrush( wxBrush(wxColour(200,255,255), wxSOLID) );
          break;
        case IMPOSED_EXIT_PART:
          dc.SetBrush( wxBrush(wxColour(255,255,200), wxSOLID) );
          break;
        }
      }
      break;
    case P_OK:
      dc.SetBrush( *wxGREEN_BRUSH );
      break;
    case P_NOK:
      dc.SetBrush( *wxRED_BRUSH );
      break;
    }
  }

  dc.DrawPolygon( numVertices, &drawPoints[0] );
}

//----------------------------------------------------------------------------

inline void redrawPolygons(wxDC& dc, MeshConnected const& shape, PolygonStatus status)
{
  MeshConnected::polygon_const_iterator p_it  = shape.polygons_begin();
  MeshConnected::polygon_const_iterator p_end = shape.polygons_end();
  while (p_it != p_end)
  {
    MeshConnected::PolygonHandle poly = (*p_it);
    drawPolygon(dc, shape, poly, status);
    ++p_it;
  }
}

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------


#endif