#include "precompiled.h"
#include "Solution.h"

void Solution::addLot(Lot const& lot)
{
  m_lots.push_back( lot );
}