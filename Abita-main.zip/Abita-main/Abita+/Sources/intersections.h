#ifndef ABITA_INTERSECTIONS_H
#define ABITA_INTERSECTIONS_H

//----------------------------------------------------------------------------

bool segments_intersect(Point2d const& seg0_a, Point2d const& seg0_b,
                        Point2d const& seg1_a, Point2d const& seg1_b,
                        int& riQuantity, float afT[2]);

//----------------------------------------------------------------------------

#endif