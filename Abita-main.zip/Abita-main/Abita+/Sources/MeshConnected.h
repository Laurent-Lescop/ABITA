#ifndef MG_MESH_CONNECTED_H
#define MG_MESH_CONNECTED_H

#include <algorithm>
#include <vector>
#include <boost/iterator_adaptors.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/type_traits.hpp>

#include "Point2d.h"

typedef enum
{
  FREE_PART,
  IMPOSED_EXIT_PART,
  IMPOSED_COMMON_PART,
  POSSIBLE_COMMON_PART
}
ElementType;

//----------------------------------------------------------------------------

class ConnectedElement
{
public:

  class data_t
  {
  public:
    virtual ~data_t() {};
    virtual std::auto_ptr<data_t> clone() const = 0;
  protected:
    data_t() {};
  };
  typedef boost::shared_ptr<data_t> data_ptr_t;

  struct handle
  {
    enum { MAX_MAGIC_VALUE = 255 };

    handle() : bits(0) {};
    handle(unsigned _index, unsigned _magic) { index = _index; magic = _magic; };
    union {
      struct {
        unsigned index : 24;
        unsigned magic : 8;
      };
      unsigned bits;
    };
    bool operator==(handle rhs) const { return bits == rhs.bits; };
    bool operator!=(handle rhs) const { return bits != rhs.bits; };
    bool operator<(handle rhs) const { return bits < rhs.bits; };
  };
  typedef std::vector<handle> handle_container;
  typedef handle_container::iterator iterator;
  typedef handle_container::const_iterator const_iterator;

  ConnectedElement() {};
  ConnectedElement(ConnectedElement const&);
  ConnectedElement& operator=(ConnectedElement const&);

  const_iterator begin_up_references() const { return _up_cnx.begin(); };
  const_iterator end_up_references() const { return _up_cnx.end(); };

  const_iterator begin_down_references() const { return _down_cnx.begin(); };
  const_iterator end_down_references() const { return _down_cnx.end(); };

  bool has_up_references() const { return !_up_cnx.empty(); };
  bool has_down_references() const { return !_down_cnx.empty(); };

  size_t up_references_size() const { return _up_cnx.size(); };
  size_t down_references_size() const { return _down_cnx.size(); };

  data_ptr_t  data() const { return _data; };
  void        set_data(data_ptr_t __data) { _data = __data; };

private:

  friend class ElementLayer;

  void add_up_reference(handle element);
  void add_down_reference(handle element);

  void remove_up_reference(handle element);
  void remove_down_reference(handle element);

  void reset_up_references() { _up_cnx.resize(0); };
  void reset_down_references() { _down_cnx.resize(0); };

  handle_container _up_cnx;
  handle_container _down_cnx;
  data_ptr_t _data;
};

//----------------------------------------------------------------------------

class ElementLayer
{

  template <class MaskContainer, class ElemContainer>
  class iterator_policies
  {
  public:
    iterator_policies() { }

    iterator_policies(const MaskContainer& mask, const ElemContainer& elements)
      : m_mask(mask), m_elements(elements) { }

      void initialize(unsigned& base) {
        satisfy_predicate(base);
      }

      // The Iter template argument is neccessary for compatibility with a MWCW
      // bug workaround
      template <class IteratorAdaptor>
        void increment(IteratorAdaptor& x) {
          ++(x.base());
          satisfy_predicate(x.base());
        }

        template <class IteratorAdaptor>
          typename IteratorAdaptor::reference dereference(const IteratorAdaptor& x) const
        { return ConnectedElement::handle(x.base(), m_mask[x.base()]); }

        template <class IteratorAdaptor1, class IteratorAdaptor2>
          bool equal(const IteratorAdaptor1& x, const IteratorAdaptor2& y) const
        { return x.base() == y.base() && x.policies().m_elements.begin() == y.policies().m_elements.begin(); }

  private:

    void satisfy_predicate(unsigned& x)
    {
      unsigned elements_size = unsigned(m_elements.size());

      while (elements_size != x && m_mask[x]==0)
      { ++x; }
    }
    const ElemContainer& m_elements;
    const MaskContainer& m_mask;
  };

  template <class ElementContainer,
  class MaskContainer,
  class Value,
  class Reference = Value,
  class Pointer = Value*,
  class Category = std::input_iterator_tag,
  class Difference = long
  >
  struct iterator_generator
  {
    typedef boost::iterator_adaptor<unsigned, iterator_policies<MaskContainer, ElementContainer>, Value, Reference, Pointer, Category, Difference> iterator;
  };

public:

  typedef ConnectedElement element_t;
  typedef std::vector<element_t> element_container_t;
  typedef element_t::data_t data_t;

  typedef iterator_generator<element_container_t, std::vector<unsigned>, element_t::handle>::iterator const_iterator;

  ElementLayer() : m_current_magic_value(1) {};

  const_iterator  begin() const;
  const_iterator  end() const;
  size_t          size() const
  { return std::count_if(m_elements_magic.begin(), m_elements_magic.end(), std::bind2nd( std::not_equal_to<unsigned>(), 0 )); };

  enum DestroyPolicy
  {
    DESTROY_DOWN_ONLY,
    DESTROY_DANGLING
  };

  ConnectedElement::handle alloc();

  ConnectedElement const& get_element(ConnectedElement::handle h) const { return m_elements[h.index]; }
  ConnectedElement& get_element(ConnectedElement::handle h) { return m_elements[h.index]; }

  void connect_up(ConnectedElement::handle element, ConnectedElement::handle up_element);
  void connect_down(ConnectedElement::handle element, ConnectedElement::handle down_element);

  void deconnect(ConnectedElement::handle h_element);

  void destroy(ConnectedElement::handle h, DestroyPolicy policy);

  void depends_on(ElementLayer* upper_layer);

  void display();

private:

  //! deallocate an element (without notifying its connected elements)
  void free(ConnectedElement::handle h);

  unsigned generate_magic_value();
  unsigned m_current_magic_value;

  element_container_t m_elements;
  std::vector<unsigned> m_free_elements;
  std::vector<unsigned> m_elements_magic;

  ElementLayer* m_upper_layer;
  ElementLayer* m_lower_layer;
};

//----------------------------------------------------------------------------
//----------------------------------------------------------------------------

class MeshConnected
{
public:

  static const ConnectedElement::handle INVALID_HANDLE;

  typedef ElementLayer VertexLayer;
  typedef VertexLayer::const_iterator vertex_const_iterator;

  typedef ElementLayer EdgeLayer;
  typedef EdgeLayer::const_iterator edge_const_iterator;

  typedef ElementLayer PolygonLayer;
  typedef PolygonLayer::const_iterator polygon_const_iterator;


  class VertexHandle
  {
  public:
    VertexHandle(ConnectedElement::handle h=INVALID_HANDLE) : m_h(h) {};
    operator ConnectedElement::handle() const { return m_h; };
    bool operator==(VertexHandle rhs) const { return m_h == rhs.m_h; };
    bool operator!=(VertexHandle rhs) const { return m_h != rhs.m_h; };
    bool operator<(VertexHandle rhs) const { return m_h < rhs.m_h; };
  private:
    ConnectedElement::handle m_h;
  };

  class EdgeHandle
  {
  public:
    EdgeHandle(ConnectedElement::handle h=INVALID_HANDLE) : m_h(h) {};
    operator ConnectedElement::handle() const { return m_h; };
    bool operator==(EdgeHandle rhs) const { return m_h == rhs.m_h; };
    bool operator!=(EdgeHandle rhs) const { return m_h != rhs.m_h; };
    bool operator<(EdgeHandle rhs) const { return m_h < rhs.m_h; };
  private:
    ConnectedElement::handle m_h;
  };

  class PolygonHandle
  {
  public:
    PolygonHandle(ConnectedElement::handle h=INVALID_HANDLE) : m_h(h) {};
    operator ConnectedElement::handle() const { return m_h; };
    bool operator==(PolygonHandle rhs) const { return m_h == rhs.m_h; };
    bool operator!=(PolygonHandle rhs) const { return m_h != rhs.m_h; };
    bool operator<(PolygonHandle rhs) const { return m_h < rhs.m_h; };
  private:
    ConnectedElement::handle m_h;
  };

  //! data associated with each vertex
  class VertexData
  {
  public:
    VertexData() {};
    virtual ~VertexData() {};
    virtual std::auto_ptr<VertexData> clone() const;

    Point2d position;

  private:
    VertexData(VertexData const&);                  //!< undefined
    VertexData& operator=(VertexData const&);       //!< undefined
  };

  //! data associated with each polygon
  class PolygonData
  {
  public:
    explicit PolygonData(ElementType type) : m_type(type) {};
    virtual ~PolygonData() {};
    virtual std::auto_ptr<PolygonData> clone() const;

    ElementType getType() const { return m_type; };
    void setType(ElementType type) { m_type = type; };

  private:
    PolygonData() {};
    PolygonData(PolygonData const&);              //!< undefined
    PolygonData& operator=(PolygonData const&);   //!< undefined

    ElementType m_type;    
  };

  MeshConnected();
  MeshConnected(MeshConnected const&);

  VertexHandle    createVertex( std::auto_ptr<VertexData> vdata );
  EdgeHandle      createEdge( VertexHandle, VertexHandle );
  PolygonHandle   createPolygon( std::vector<VertexHandle> const&, std::auto_ptr<PolygonData> pdata );

  EdgeHandle      findEdge( VertexHandle, VertexHandle ) const;
  void            findVertices( EdgeHandle, VertexHandle vertices[2] ) const;
  void            findVertices( PolygonHandle, std::vector<VertexHandle>& result ) const;
  void            findEdges( PolygonHandle, std::vector<EdgeHandle>& result ) const;

  void findAdjacentEdges( VertexHandle, std::vector<EdgeHandle>& edges ) const;
  void findAdjacentPolygons( VertexHandle, std::vector<PolygonHandle>& polygons ) const;
  void findAdjacentPolygons( EdgeHandle, std::vector<PolygonHandle>& polygons ) const;

  void detachEdge(EdgeHandle eh);
  void detachPolygon(PolygonHandle th);
  void eraseEdge(EdgeHandle eh);
  void erasePolygon(PolygonHandle th);
  void eraseVertex(VertexHandle vh);

  VertexData*  getVertexData( VertexHandle h ) const;
  PolygonData* getPolygonData( PolygonHandle h ) const;

  polygon_const_iterator polygons_begin() const { return m_polygons.begin(); };
  polygon_const_iterator polygons_end() const { return m_polygons.end(); };
  size_t                 polygons_size() const { return m_polygons.size(); };

  edge_const_iterator edges_begin() const { return m_edges.begin(); };
  edge_const_iterator edges_end() const { return m_edges.end(); };
  size_t              edges_size() const { return m_edges.size(); };

  vertex_const_iterator vertices_begin() const { return m_vertices.begin(); };
  vertex_const_iterator vertices_end() const { return m_vertices.end(); };
  size_t                vertices_size() const { return m_vertices.size(); };

  void display();

private:

  MeshConnected& operator=(MeshConnected const&);     //!< undefined

  //-

  class _VertexData : public VertexLayer::data_t
  {
  public:
    _VertexData() {};

    virtual std::auto_ptr<VertexLayer::data_t> clone() const
    {
      std::auto_ptr<_VertexData> result( new _VertexData );
      if (user_data.get()!=NULL)
      {
        result->user_data = boost::shared_ptr<VertexData>( user_data->clone() );
      }
      return result;
    }
    boost::shared_ptr<VertexData> user_data;

  private:
    _VertexData(_VertexData const&);                //!< undefined
    _VertexData& operator=(_VertexData const&);     //!< undefined
  };
  typedef boost::shared_ptr<_VertexData> _VertexDataPtr;

  void alloc_vertex( VertexHandle& handle, _VertexDataPtr& vertex_data );
  _VertexData* get_vertex_data( VertexLayer::element_t const& vertex ) const;

  //-

  class _PolygonData : public PolygonLayer::data_t
  {
  public:
    _PolygonData() {};

    virtual std::auto_ptr<PolygonLayer::data_t> clone() const
    {
      std::auto_ptr<_PolygonData> result( new _PolygonData );
      result->h_vert = h_vert;
      if (user_data.get()!=NULL)
      {
        result->user_data = boost::shared_ptr<PolygonData>( user_data->clone() );
      }
      return result;
    }
    std::vector<VertexHandle> h_vert;
    boost::shared_ptr<PolygonData> user_data;
  private:
    _PolygonData(_VertexData const&);                //!< undefined
    _PolygonData& operator=(_VertexData const&);     //!< undefined
  };
  typedef boost::shared_ptr<_PolygonData> _PolygonDataPtr;

  void alloc_polygon( PolygonHandle& handle, _PolygonDataPtr& tri_data );
  _PolygonData* get_polygon_data( PolygonLayer::element_t const& polygon ) const;

  //-

  VertexLayer m_vertices;
  ElementLayer m_edges;
  PolygonLayer m_polygons;
};

//----------------------------------------------------------------------------

#endif