#include "precompiled.h"
#include "intersections.h"

#include "Point2d.h"

namespace {

  //----------------------------------------------------------------------------

  bool Find (const Point2d& rkP0, const Point2d& rkD0,
    const Point2d& rkP1, const Point2d& rkD1, Point2d& rkDiff,
    float& rfD0SqrLen, int& riQuantity, float afT[2])
  {
    // Intersection is a solution to P0+s*D0 = P1+t*D1.  Rewrite as
    // s*D0 - t*D1 = P1 - P0, a 2x2 system of equations.  If D0 = (x0,y0)
    // and D1 = (x1,y1) and P1 - P0 = (c0,c1), then the system is
    // x0*s - x1*t = c0 and y0*s - y1*t = c1.  The error tests are relative
    // to the size of the direction vectors, |Cross(D0,D1)| >= e*|D0|*|D1|
    // rather than absolute tests |Cross(D0,D1)| >= e.  The quantities
    // P1-P0, |D0|^2, and |D1|^2 are returned for use by calling functions.

    float fDet = rkD1.x*rkD0.y - rkD1.y*rkD0.x;
    rkDiff = rkP1 - rkP0;
    rfD0SqrLen = rkD0.squareLength();

    const float fEpsilon = 1e-06f;
    if ( fDet*fDet > fEpsilon*rfD0SqrLen*rkD1.squareLength() )
    {
      // Lines intersect in a single point.  Return both s and t values for
      // use by calling functions.
      float fInvDet = 1.0f/fDet;
      riQuantity = 1;
      afT[0] = (rkD1.x*rkDiff.y - rkD1.y*rkDiff.x)*fInvDet;
      afT[1] = (rkD0.x*rkDiff.y - rkD0.y*rkDiff.x)*fInvDet;
    }
    else
    {
      // lines are parallel
      fDet = rkD0.x*rkDiff.y - rkD0.y*rkDiff.x;
      if ( fDet*fDet > fEpsilon*rfD0SqrLen*rkDiff.squareLength() )
      {
        // lines are disjoint
        riQuantity = 0;
      }
      else
      {
        // lines are the same
        riQuantity = 2;
      }
    }

    return riQuantity != 0;
  }

  //----------------------------------------------------------------------------

}

//----------------------------------------------------------------------------

bool segments_intersect(Point2d const& seg0_a, Point2d const& seg0_b,
                        Point2d const& seg1_a, Point2d const& seg1_b,
                        int& riQuantity, float afT[2])
{
  Point2d kDiff;
  float fD0SqrLen;
  Point2d const seg0_dir = seg0_b-seg0_a;
  Point2d const seg1_dir = seg1_b-seg1_a;
  bool bIntersects = Find(seg0_a, seg0_dir,
    seg1_a, seg1_dir, 
    kDiff, fD0SqrLen, riQuantity, afT);

  if ( bIntersects )
  {
    if ( riQuantity == 1 )
    {
      if ( afT[0] < 0.0f || afT[0] > 1.0f
        ||   afT[1] < 0.0f || afT[1] > 1.0f )
      {
        // lines intersect, but segments do not
        riQuantity = 0;
      }
    }
    else
    {
      // segments are on the same line
      float fDotRS = seg0_dir * seg1_dir;
      float fDot0, fDot1;
      if ( fDotRS > 0.0f )
      {
        fDot0 = kDiff * seg0_dir;
        fDot1 = fDot0 + fDotRS;
      }
      else
      {
        fDot1 = kDiff * seg0_dir;
        fDot0 = fDot1 + fDotRS;
      }

      // compute intersection of [t0,t1] and [0,1]
      if ( fDot1 < 0.0f || fDot0 > fD0SqrLen )
      {
        riQuantity = 0;
      }
      else if ( fDot1 > 0.0f )
      {
        if ( fDot0 < fD0SqrLen )
        {
          float fInvLen = 1.0f/fD0SqrLen;
          riQuantity = 2;
          afT[0] = ( fDot0 < 0.0f ? 0.0f : fDot0*fInvLen );
          afT[1] = ( fDot1 > fD0SqrLen ? 1.0f : fDot1*fInvLen );
        }
        else  // fT0 == 1
        {
          riQuantity = 1;
          afT[0] = 1.0f;
        }
      }
      else  // fT1 == 0
      {
        riQuantity = 1;
        afT[0] = 0.0f;
      }
    }
  }

  return riQuantity != 0;
}
