#ifndef ABITA_LINE2D_H
#define ABITA_LINE2D_H

#include "Point2d.h"

class Line2d
{
public:

  Line2d() {};

  Line2d(Point2d const& a, Point2d const& b)
  : m_origin(a),
    m_direction(b-a)
  {
    m_normal = Point2d(m_direction.y, -m_direction.x);
    m_constant = m_origin * m_normal;
  }

  float pseudoDistance(Point2d const& point)
  {
    return (m_normal * point) - m_constant;
  }

  Point2d const& getNormal() const { return m_normal; };

private:
  Point2d m_origin;
  Point2d m_direction;
  Point2d m_normal;
  float m_constant;
};

#endif