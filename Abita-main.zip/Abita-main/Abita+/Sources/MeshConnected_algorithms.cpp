#include "precompiled.h"
#include "MeshConnected_algorithms.h"

#include <boost/format.hpp>
#include <map>
#include <set>

#include "intersections.h"
#include "Line2d.h"
#include "RevisitedRadix.h"


//---------------------------------------------------------------------------

// Compute area

void computePolygonArea( MeshConnected const& mesh, MeshConnected::PolygonHandle th, float &area, float &perimeter)
{
  std::vector<MeshConnected::VertexHandle> vertices;
  mesh.findVertices(th,vertices);

  area = perimeter = 0.f;

  if (vertices.size() < 3)
    return;

  MeshConnected::VertexData *vh = mesh.getVertexData( vertices.back() );
  Point2d pt1 = vh->position;

  for(unsigned i=0; i<vertices.size(); i++)
  {
    MeshConnected::VertexData *vh = mesh.getVertexData( vertices[i] );
    Point2d pt2 = vh->position;

    Point2d delta = pt2 - pt1;

    area      += pt1.x * pt2.y - pt2.x * pt1.y;
    perimeter += delta.length();

    pt1 = pt2;
  }

  area *= 0.5f;
}

//---------------------------------------------------------------------------


bool segmentPolygonOverlap( MeshConnected const& mesh, MeshConnected::PolygonHandle poly,
                           Point2d const& segment_a, Point2d const& segment_b )
{
  std::vector<MeshConnected::VertexHandle> vertices;
  mesh.findVertices(poly, vertices);

  MeshConnected::VertexHandle tailVertex = vertices.back();
  MeshConnected::VertexData* tailData = mesh.getVertexData(tailVertex);
  Point2d prevPos = tailData->position;

  unsigned const numV = vertices.size();
  for (unsigned v=0; v<numV; v++)
  {
    MeshConnected::VertexHandle vh = vertices[v];
    MeshConnected::VertexData* vdata = mesh.getVertexData(vh);
    Point2d pos = vdata->position;

    int riQ;
    float ts[2];
    if (segments_intersect(segment_a, segment_b, prevPos, pos, riQ, ts))
    {
      return true;
    }
  }

  return false;
}

//----------------------------------------------------------------------------

namespace {

  typedef enum
  {
    RIGHT,
    LEFT,
    ON_LINE
  }
  VCategory;

  const float EPSILON = 1e-1f;

  void outputDebugPolygon(MeshConnected const& mesh, MeshConnected::PolygonHandle ph)
  {
#ifdef _DEBUG
    std::string output;
    output = boost::io::str( boost::format("  polygon :: handle=%x\r\n") % ConnectedElement::handle(ph).bits );
    output += std::string("    V[");
    std::vector<MeshConnected::VertexHandle> vertices;
    mesh.findVertices( ph, vertices );
    unsigned const numV = vertices.size();
    if (numV > 0)
    {
      output += boost::io::str( boost::format("%x") % ConnectedElement::handle(vertices[0]).bits );
      for (unsigned i=1; i<numV; i++)
      {
        output += boost::io::str( boost::format(",%x") % ConnectedElement::handle(vertices[i]).bits );
      }
    }
    output += std::string("]\r\n");

    OutputDebugString( output.c_str() );
#endif
  }

};

void cutMesh(MeshConnected& mesh, Point2d const& segment_a, Point2d const& segment_b)
{
  Line2d line(segment_a, segment_b);

  //- categorize vertices

  std::map<MeshConnected::VertexHandle, VCategory> verticesCategory;
  {
    MeshConnected::vertex_const_iterator it = mesh.vertices_begin();
    MeshConnected::vertex_const_iterator end = mesh.vertices_end();
    while (it != end)
    {
      MeshConnected::VertexHandle const vh = *it;
      MeshConnected::VertexData* vdata = mesh.getVertexData(vh);

      float distance = line.pseudoDistance( vdata->position );
      VCategory category;
      if (fabsf(distance) < EPSILON)
      {
        category = ON_LINE;
        //Point2d normalizedNormal = line.getNormal();
        //normalizedNormal *= (1.f / normalizedNormal.length());
        //vdata->position += normalizedNormal * (2.f*EPSILON);

        verticesCategory[vh] = category;
        ++it;

        //std::vector<MeshConnected::PolygonHandle> polygons;
        //mesh.findAdjacentPolygons(vh, polygons);
        //unsigned numPolygons = polygons.size();
        //for (unsigned i=0; i<numPolygons; i++)
        //{
        //  typedef std::vector<MeshConnected::VertexHandle> VV;
        //  VV vertices;
        //  mesh.findVertices( polygons[i], vertices );

        //  VV::iterator it = std::find( vertices.begin(), vertices.end(), vh );
        //  _ASSERT( it != vertices.end() );
        //  vertices.insert( it, vh );

        //  mesh.createPolygon(
        //}
      }
      else
      {
        if (distance > 0)
          category = RIGHT;
        else
          category = LEFT;

        verticesCategory[vh] = category;

        ++it;
      }
    }
  }

  //- cut the edges & create replacing edges

  typedef std::map<MeshConnected::EdgeHandle, MeshConnected::VertexHandle> EdgesReplacements;
  EdgesReplacements edgesReplacements;
  typedef std::vector<MeshConnected::VertexHandle> NewVertices;
  {
    std::vector<MeshConnected::EdgeHandle> initial_edges;
    std::copy( mesh.edges_begin(), mesh.edges_end(), std::back_inserter( initial_edges ) );

    {
      typedef std::set<MeshConnected::VertexHandle> AlreadyAddedOnLineVertex;
      AlreadyAddedOnLineVertex alreadyAddedOnLineVertex;

      unsigned const numEdges = initial_edges.size();
      for (unsigned e=0; e<numEdges; e++)
      {
        MeshConnected::EdgeHandle const eh = initial_edges[e];

        MeshConnected::VertexHandle vh[2];
        mesh.findVertices(eh, vh);

        VCategory category[2];
        category[0] = verticesCategory[ vh[0] ];
        category[1] = verticesCategory[ vh[1] ];

        if (category[0] != category[1])
        {
          // the current edge intersects the cutting segment

          if (category[0] != ON_LINE && category[1] != ON_LINE)
          {
            // the current edge is split by the cutting segment

            MeshConnected::VertexData* orig_vdata[2];
            orig_vdata[0] = mesh.getVertexData( vh[0] );
            orig_vdata[1] = mesh.getVertexData( vh[1] );

            int riQ;
            float afT[2];
            bool intersects = segments_intersect( segment_a, segment_b,
              orig_vdata[0]->position, orig_vdata[1]->position, 
              riQ, afT);

            if (intersects)
            {
              // create the intersection vertex

              std::auto_ptr<MeshConnected::VertexData> vdata( new MeshConnected::VertexData );
              Point2d newPosition = orig_vdata[0]->position + ((orig_vdata[1]->position - orig_vdata[0]->position) * afT[1]);
              vdata->position = newPosition;

              MeshConnected::VertexHandle newvh = mesh.createVertex( vdata );
              verticesCategory[ newvh ] = ON_LINE;

              edgesReplacements[ eh ] = newvh;
            }
          }
          else
          {
            if (category[0] == ON_LINE)
            {
              //if (alreadyAddedOnLineVertex.find(vh[0]) == alreadyAddedOnLineVertex.end())
              {
                edgesReplacements[ eh ] = vh[0];
                alreadyAddedOnLineVertex.insert( vh[0] );
              }
            }
            else
            {
              //if (alreadyAddedOnLineVertex.find(vh[1]) == alreadyAddedOnLineVertex.end())
              {
                edgesReplacements[ eh ] = vh[1];
                alreadyAddedOnLineVertex.insert( vh[1] );
              }
            }
          }
        }
      }
    }
  }

  //- affect the polygons
  {
    //- gather the polygons to cut

    typedef std::vector<MeshConnected::PolygonHandle> PolygonsToCut;
    PolygonsToCut polygonsToCut;
    {
      EdgesReplacements::const_iterator it = edgesReplacements.begin();
      EdgesReplacements::const_iterator end = edgesReplacements.end();
      while (it != end)
      {
        MeshConnected::EdgeHandle orig_edge = it->first;
        mesh.findAdjacentPolygons( orig_edge, polygonsToCut );
        ++it;
      }

      std::sort( polygonsToCut.begin(), polygonsToCut.end() );
      polygonsToCut.erase( std::unique( polygonsToCut.begin(), polygonsToCut.end() ), polygonsToCut.end() );
    }

    //--- cut the polygons

    typedef std::vector<MeshConnected::VertexHandle> OriginalVertices;
    OriginalVertices originalVertices;
    std::vector<bool> originalVused;

    PolygonsToCut::iterator it = polygonsToCut.begin();
    PolygonsToCut::iterator end = polygonsToCut.end();
    while (it != end)
    {
      MeshConnected::PolygonHandle const ph = *it;
      MeshConnected::PolygonData const* pdata = mesh.getPolygonData(ph);
      
#ifdef _DEBUG
      OutputDebugString("Polygon to cut ::\r\n");
      outputDebugPolygon(mesh, ph);
#endif

      {
        std::vector<MeshConnected::VertexHandle> original_vertices;
        mesh.findVertices( ph, original_vertices );

        unsigned const numV = original_vertices.size();
        _ASSERT( numV > 2 );

        bool createdNewPolygons = false;

        _ASSERT(RIGHT < LEFT && RIGHT+1==LEFT);
        for (VCategory currentClip=RIGHT; currentClip<=LEFT; currentClip=VCategory(currentClip+1))
        {
          //- find find vertex that is outside the current clip

          std::vector<MeshConnected::VertexHandle> vertices( numV );
          {
            bool found = false;
            for (unsigned i=0; i<numV && !found; i++)
            {
              MeshConnected::VertexHandle vh = original_vertices[i];
              VCategory cat = verticesCategory[vh];
              if (cat != currentClip && cat != ON_LINE)
              {
                found = true;
                std::rotate_copy( original_vertices.begin(), original_vertices.begin()+i, original_vertices.end(), 
                                  vertices.begin() );

                // rotate so that the first _edge_ we analyze starts in the non clipped space
                std::rotate( vertices.begin(), vertices.begin()+1, vertices.end() );
              }
            }

            if (!found)
            {
              // no need to clip here, since there's no vertex outside the clip space
              continue;
            }
          }

          //-

          typedef std::vector<MeshConnected::VertexHandle> CompletePoly;
          CompletePoly completePolygon;   // including intersection points
          std::vector<MeshConnected::VertexHandle> exitingVertices;
          std::vector<MeshConnected::VertexHandle> enteringVertices;
          {
            MeshConnected::VertexHandle curEdge[2];
            curEdge[1] = vertices.back();

            bool currentlyWalkingOnCutLine = false;
            MeshConnected::VertexHandle startWalkingVertex;
            Line2d startWalkingSegment;
            VCategory startWalkingClipSide;

            for (unsigned i=0; i<numV; i++)
            {
              curEdge[0] = curEdge[1];
              curEdge[1] = vertices[i];

              VCategory vcat[2];
              vcat[0] = verticesCategory[curEdge[0]];
              vcat[1] = verticesCategory[curEdge[1]];

              if (vcat[0] != vcat[1])
              {
                if ( vcat[0] != ON_LINE && vcat[1] != ON_LINE )
                {
                  MeshConnected::EdgeHandle eh = mesh.findEdge( curEdge[0], curEdge[1] );
                  MeshConnected::VertexHandle interV = edgesReplacements[ eh ];
                  completePolygon.push_back( interV );

                  if (vcat[0] == currentClip)
                    exitingVertices.push_back( interV );
                  
                  if (vcat[1] == currentClip)
                    enteringVertices.push_back( interV );
                }
                else
                {
                  if (!currentlyWalkingOnCutLine)
                  {
                    if (vcat[1] == ON_LINE)
                    {
                      _ASSERT( vcat[0] != ON_LINE );
                      startWalkingClipSide = vcat[0];
                      currentlyWalkingOnCutLine = true;
                      startWalkingVertex = curEdge[1];

                      MeshConnected::VertexData const* vdata[2];
                      vdata[0] = mesh.getVertexData( curEdge[0] );
                      vdata[1] = mesh.getVertexData( curEdge[1] );

                      startWalkingSegment = Line2d( vdata[0]->position, vdata[1]->position );
                    }
                    else
                    {
                      _ASSERT( vcat[0] == ON_LINE );
                      _ASSERT( false );
                    }
                  }
                  else
                  {
                    if (vcat[0] == ON_LINE)
                    {
                      _ASSERT( vcat[1] != ON_LINE );
                      if (vcat[1] == startWalkingClipSide)
                      {
                        // we get out of the line to go back where we were
                        if (startWalkingClipSide == currentClip)
                        {
                          exitingVertices.push_back( startWalkingVertex );
                          enteringVertices.push_back( curEdge[0] );
                        }
                        else
                        {
                          enteringVertices.push_back( startWalkingVertex );
                          exitingVertices.push_back( curEdge[0] );
                        }
                      }
                      else
                      {
                        std::vector<MeshConnected::VertexHandle>* vertexCategory = NULL;
                        
                        if (startWalkingClipSide != currentClip)
                          vertexCategory = &enteringVertices;
                        else
                          vertexCategory = &exitingVertices;

                        MeshConnected::VertexData const* vdata;
                        vdata = mesh.getVertexData( curEdge[1] );

                        if (startWalkingSegment.pseudoDistance( vdata->position ) <= 0)
                        {
                          vertexCategory->push_back( curEdge[0] );
                        }
                        else
                        {
                          vertexCategory->push_back( startWalkingVertex );
                        }
                      }
                      currentlyWalkingOnCutLine = false;
                    }
                    else
                    {
                      _ASSERT( vcat[1] == ON_LINE );
                      _ASSERT( false );
                    }
                  }

                  //if (vcat[0] == ON_LINE)
                  //{
                  //  if (vcat[1] == RIGHT)
                  //    enteringVertices.push_back( curEdge[0] );
                  //}
                  //else
                  //{
                  //  _ASSERT( vcat[1] == ON_LINE );

                  //  if (vcat[0] == RIGHT)
                  //    exitingVertices.push_back( curEdge[1] );
                  //}
                }
              }
              else
              {
                //if (vcat[0] == ON_LINE)
                //{
                //  _ASSERT( vcat[1] == ON_LINE );
                //  exitingVertices.push_back( curEdge[0] );
                //  enteringVertices.push_back( curEdge[1] );
                //}
              }
              completePolygon.push_back( curEdge[1] );
            }
          }

          if (currentClip == LEFT)
          {
            ////std::reverse( completePolygon.begin(), completePolygon.end() );
            ////std::reverse( completePolygonIntersection.begin(), completePolygonIntersection.end() );
            //enteringVertices.swap( exitingVertices );
          }

          while (!exitingVertices.empty())
          {
            MeshConnected::VertexHandle vh = exitingVertices.back();
            exitingVertices.pop_back();

            CompletePoly ocpoly = completePolygon;
            {
              // make the selected exiting vertex the first vertex of the working polygon
              CompletePoly::iterator start_it = std::find( ocpoly.begin(), ocpoly.end(), vh );
              unsigned startIndex = start_it - ocpoly.begin();
              std::rotate( ocpoly.begin(), start_it, ocpoly.end() );
            }

            CompletePoly::iterator current_pos = ocpoly.begin() + 1;
            // look for the first 'entering' vertex after the current vertex
            CompletePoly::iterator entering_it = std::find_first_of( current_pos, ocpoly.end(), enteringVertices.begin(), enteringVertices.end() );
            if (entering_it != ocpoly.end())
            {
              // setup the projected interval on the cut line
              float validityInterval[2];
              {
                Point2d pos_exit = mesh.getVertexData( *current_pos )->position;
                Point2d pos_enter = mesh.getVertexData( *entering_it )->position;
                float distance[2];
                distance[0] = (pos_exit - segment_a).length();
                distance[1] = (pos_enter - segment_a).length();
                validityInterval[0] = std::min( distance[0], distance[1] );
                validityInterval[1] = std::max( distance[0], distance[1] );
              }

              while (current_pos != ocpoly.end())
              {
                // find an 'exiting' vertex after the current 'entering' vertex
                CompletePoly::iterator reexiting_it = std::find_first_of( entering_it, ocpoly.end(), exitingVertices.begin(), exitingVertices.end() );
                if (reexiting_it != ocpoly.end())
                {
                  // the reexiting vertex is valid is it's contained in the validity interval
                  Point2d pos_exit = mesh.getVertexData( *reexiting_it )->position;
                  float exit_distance = (pos_exit - segment_a).length();
                  if (exit_distance < validityInterval[0] || exit_distance > validityInterval[1])
                  {
                    // the reexiting vertex is not valid, we will erase the remaining vertices of the polygon
                    reexiting_it = ocpoly.end();
                  }
                  else
                  {
                    // we won't start from this 'exiting' vertex again to create another polygon
                    std::vector<MeshConnected::VertexHandle>::iterator erase_it = std::find( exitingVertices.begin(), exitingVertices.end(), *reexiting_it );
                    exitingVertices.erase( erase_it );
                  }                
                }
                if (entering_it+1 < reexiting_it)
                {
                  // we remove the vertices that are behind the clip line (between entering & reexiting vertices)
                  current_pos = ocpoly.erase( entering_it+1, reexiting_it );
                }
                else
                  current_pos = reexiting_it;

                if (current_pos != ocpoly.end())
                {
                  // look for a possible following 'entering' vertex
                  entering_it = std::find_first_of( current_pos, ocpoly.end(), enteringVertices.begin(), enteringVertices.end() );
                }
              }
            }

            std::vector<MeshConnected::VertexHandle> newPolygon = ocpoly;

            if (newPolygon.size() > 2)
            {
              MeshConnected::PolygonHandle newP = mesh.createPolygon( newPolygon, pdata->clone() );
              outputDebugPolygon( mesh, newP );
              newPolygon.resize(0);
              createdNewPolygons = true;
            }
          }
        }

        if (!createdNewPolygons)
        {
          typedef std::vector<MeshConnected::VertexHandle> CompletePoly;
          CompletePoly completePolygon;   // including intersection points
          {
            MeshConnected::VertexHandle curEdge[2];
            curEdge[1] = original_vertices.back();

            for (unsigned i=0; i<numV; i++)
            {
              curEdge[0] = curEdge[1];
              curEdge[1] = original_vertices[i];

              VCategory vcat[2];
              vcat[0] = verticesCategory[curEdge[0]];
              vcat[1] = verticesCategory[curEdge[1]];

              if (vcat[0] != vcat[1])
              {
                if ( vcat[0] != ON_LINE && vcat[1] != ON_LINE )
                {
                  MeshConnected::EdgeHandle eh = mesh.findEdge( curEdge[0], curEdge[1] );
                  MeshConnected::VertexHandle interV = edgesReplacements[ eh ];
                  completePolygon.push_back( interV );
                }
              }
              completePolygon.push_back( curEdge[1] );
            }
          }

          MeshConnected::PolygonHandle newP = mesh.createPolygon( completePolygon, pdata->clone() );
          outputDebugPolygon( mesh, newP );
        }
      }
      ++it;
    }

    //- delete original polygons
    {
      PolygonsToCut::const_iterator it = polygonsToCut.begin();
      PolygonsToCut::const_iterator end = polygonsToCut.end();
      while (it != end)
      {
        mesh.erasePolygon(*it);
        ++it;
      }
    }
  }
}

//----------------------------------------------------------------------------

void removeEdge( MeshConnected& mesh, MeshConnected::EdgeHandle eh )
{
  std::vector<MeshConnected::PolygonHandle> adjPolygons;
  mesh.findAdjacentPolygons( eh, adjPolygons );
  
  if (adjPolygons.size() != 2)
  {
    // contour edge, we delete it completely
    mesh.eraseEdge( eh );
  }
  else
  {
    MeshConnected::VertexHandle edge_v[2];
    mesh.findVertices(eh, edge_v);

    MeshConnected::PolygonData* pdata = mesh.getPolygonData(adjPolygons[0]);

    std::vector<MeshConnected::VertexHandle> vertices1;
    std::vector<MeshConnected::VertexHandle> vertices2;
    mesh.findVertices( adjPolygons[0], vertices1 );
    mesh.findVertices( adjPolygons[1], vertices2 );

    std::vector<MeshConnected::VertexHandle>::iterator edge_pos1 = std::find_first_of( vertices1.begin(), vertices1.end(), edge_v, edge_v+2 );
    if (edge_pos1 == vertices1.end())
      return;
    else
    {
      if (*edge_pos1 == edge_v[0])
      {
        if (*(edge_pos1+1) != edge_v[1])
          edge_pos1 = std::find( edge_pos1+1, vertices1.end(), edge_v[1] );
      }
      else
      {
        if (*(edge_pos1+1) != edge_v[0])
          edge_pos1 = std::find( edge_pos1+1, vertices1.end(), edge_v[0] );
      }
    }

    std::vector<MeshConnected::VertexHandle>::iterator edge_pos2 = std::find_first_of( vertices2.begin(), vertices2.end(), edge_v, edge_v+2 );
    if (edge_pos2 == vertices2.end())
      return;
    else
    {
      if (*edge_pos2 == edge_v[0])
      {
        if (*(edge_pos2+1) != edge_v[1])
          edge_pos2 = std::find( edge_pos2+1, vertices2.end(), edge_v[1] );
      }
      else
      {
        if (*(edge_pos2+1) != edge_v[0])
          edge_pos2 = std::find( edge_pos2+1, vertices2.end(), edge_v[0] );
      }
    }

    if (*edge_pos1 == *edge_pos2)
    {
      // the polygons have different winding rules, we must invert one of them
      std::reverse( vertices2.begin(), vertices2.end() );
      edge_pos2 = std::find_first_of( vertices2.begin(), vertices2.end(), edge_v, edge_v+2 );
    }

    std::rotate( vertices1.begin(), edge_pos1, vertices1.end() );
    std::rotate( vertices2.begin(), edge_pos2, vertices2.end() );

    _ASSERT( *vertices1.begin() == *(vertices2.begin()+1) );
    _ASSERT( *(vertices1.begin()+1) == *vertices2.begin() );

    vertices1.erase( vertices1.begin() );
    vertices2.erase( vertices2.begin() );

    vertices2.insert( vertices2.end(), vertices1.begin(), vertices1.end() );

    mesh.createPolygon( vertices2, pdata->clone() );

    mesh.erasePolygon( adjPolygons[0] );
    mesh.erasePolygon( adjPolygons[1] );
  }
}

//----------------------------------------------------------------------------

void removeVertex( MeshConnected& mesh, MeshConnected::VertexHandle vh )
{
  std::vector<MeshConnected::EdgeHandle> edges;
  mesh.findAdjacentEdges( vh, edges );
  if (edges.size() == 2)
  {
    std::vector<MeshConnected::PolygonHandle> polygons;
    mesh.findAdjacentPolygons(vh, polygons);

    std::vector<MeshConnected::VertexHandle> vertices;

    unsigned const numP = polygons.size();
    for (unsigned i=0; i<numP; i++)
    {
      MeshConnected::PolygonHandle ph = polygons[i];
      MeshConnected::PolygonData const* pdata = mesh.getPolygonData(ph);

      vertices.resize(0);
      mesh.findVertices( ph, vertices );

      std::vector<MeshConnected::VertexHandle>::iterator it = std::find( vertices.begin(), vertices.end(), vh );
      if (it != vertices.end())
      {
        vertices.erase( it );
        if (vertices.size() > 2)
        {
          mesh.createPolygon( vertices, pdata->clone() );
        }
        mesh.erasePolygon( ph );
      }
    }
  }

  mesh.eraseVertex( vh );
}

//----------------------------------------------------------------------------

void mergeVertices( MeshConnected& mesh, MeshConnected::VertexHandle vh[2] )
{
  MeshConnected::EdgeHandle eh = mesh.findEdge(vh[0], vh[1]);

  //{
  //  std::vector<MeshConnected::PolygonHandle> polygonsToRemove;
  //  mesh.findAdjacentPolygons(eh, polygonsToRemove);

  //  unsigned const numToRemove = polygonsToRemove.size();
  //  for (unsigned i=0; i<numToRemove; i++)
  //  {
  //    mesh.erasePolygon( polygonsToRemove[i] );
  //  }
  //}

  {
    std::vector<MeshConnected::PolygonHandle> polygonsToModify;
    mesh.findAdjacentPolygons(vh[0], polygonsToModify);
    //mesh.findAdjacentPolygons(vh[1], polygonsToModify);

    //std::sort( polygonsToModify.begin(), polygonsToModify.end() );
    //std::vector<MeshConnected::PolygonHandle>::iterator end_unique = std::unique(polygonsToModify.begin(), polygonsToModify.end());
    //polygonsToModify.erase( end_unique, polygonsToModify.end() );

    unsigned const numToModify = polygonsToModify.size();
    for (unsigned i=0; i<numToModify; i++)
    {
      MeshConnected::PolygonHandle ph = polygonsToModify[i];
      MeshConnected::PolygonData* pdata = mesh.getPolygonData(ph);

      std::vector<MeshConnected::VertexHandle> vertices;
      mesh.findVertices(ph, vertices);

      std::vector<MeshConnected::VertexHandle>::iterator it_v0 = std::find( vertices.begin(), vertices.end(), vh[0] );
      std::vector<MeshConnected::VertexHandle>::iterator it_v1 = std::find( vertices.begin(), vertices.end(), vh[1] );
      if (it_v1 != vertices.end())
      {
        // here, the polygon contains vh[1], be careful the merge can create two polygons, or a degenerated one, or...
        *it_v0 = vh[1];
        std::rotate( vertices.begin(), it_v0, vertices.end() );

        std::vector<MeshConnected::VertexHandle> newPolygon;
        std::vector<MeshConnected::VertexHandle>::const_iterator orig_it = vertices.begin();
        
        while (orig_it != vertices.end())
        {
          newPolygon.push_back( *orig_it );
          ++orig_it;
          while (orig_it != vertices.end() && *orig_it != newPolygon.front())
          {
            newPolygon.push_back( *orig_it );
            ++orig_it;
          }
          if (newPolygon.size() > 2)
          {
            mesh.createPolygon( newPolygon, pdata->clone() );
          }
          newPolygon.resize(0);
        }
      }
      else
      {
        // here, the polygon does not contain vh[1], just replace
        if (it_v0 != vertices.end())
        {
          *it_v0 = vh[1];
          mesh.createPolygon(vertices, pdata->clone());
        }
        else
          _ASSERT(false);
      }
    }

    mesh.eraseVertex( vh[0] );
  }
  // remove degenerated polygons
  {
    std::vector<MeshConnected::PolygonHandle> polygons;
    mesh.findAdjacentPolygons(vh[1], polygons);
    
    unsigned const numP = polygons.size();
    for (unsigned i=0; i<numP; i++)
    {
      MeshConnected::PolygonHandle ph = polygons[i];

      float area, perimeter;
      computePolygonArea(mesh, ph, area, perimeter);
      if (area == 0 || perimeter == 0)
        mesh.erasePolygon( ph );
    }
  }
}

//----------------------------------------------------------------------------

namespace {

bool insidePolygon( Point2d const& mouse, std::vector<Point2d> const& points )
{
  Point2d prevPnt = points.back();
  bool flag1 = (mouse.y >= prevPnt.y);
  bool inside = false;
  unsigned const numV = points.size();

  for (unsigned v=0; v<numV; v++)
  {
    Point2d pnt = points[v];
    bool flag2 = (mouse.y >= pnt.y);

    if (flag1 != flag2)
    {
      bool flag3 = ((pnt.y - mouse.y) * (prevPnt.x - pnt.x) >=
                    (pnt.x - mouse.x) * (prevPnt.y - pnt.y));

      if (flag3 == flag2)
        inside = !inside;
    }

    prevPnt = pnt;
    flag1 = flag2;
  }

  return inside;
}

};

bool isInsidePolygon( Point2d const& point, MeshConnected const& mesh, MeshConnected::PolygonHandle ph )
{
  std::vector<MeshConnected::VertexHandle> verts;

  mesh.findVertices( ph, verts );

  unsigned const numV = verts.size();

  std::vector<Point2d> vertPos;
  vertPos.reserve(numV);
  for (unsigned v=0; v<numV; v++)
  {
    MeshConnected::VertexData* vdata = mesh.getVertexData( verts[v] );
    vertPos.push_back( vdata->position );
  }

  return insidePolygon(point, vertPos);
}
