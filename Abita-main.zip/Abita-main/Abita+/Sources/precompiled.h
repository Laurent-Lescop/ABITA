#ifndef ABITA_PRECOMPILED_H
#define ABITA_PRECOMPILED_H

#include <wx/wxprec.h>

#include "wx/progdlg.h"
#include "wx/image.h"
#include "wx/filename.h"
#include "wx/toolbar.h"
//#include "wx/msw/tbar95.h"
#include "wx/notebook.h"
#include "wx/config.h"
#include "wx/msw/iniconf.h"
#include "wx/log.h"
#include "wx/tooltip.h"
#include "wx/tipdlg.h"
#include "wx/menuitem.h"
#include "wx/grid.h"
#include "wx/splitter.h"
#include "wx/msgdlg.h"
#include "wx/choicdlg.h"
#include "wx/listctrl.h"
#include "wx/textdlg.h"
#include "wx/splash.h"

#include <crtdbg.h>

#include <cmath>
#include <memory>
#include <vector>

#include "AbitaDocument.h"



#endif