#ifndef MG_GUIQUESTION
#define MG_GUIQUESTION

#include "precompiled.h"
#include "textes.h"

enum ID_CONTROLS_QUESTION
{
  ID_BUTTON = 10000
};


class DlgQuestion: public wxDialog
{

public:
  DlgQuestion( wxWindow* parent, wxString title,wxString texte,wxStringList str_buttons );
  ~DlgQuestion();
  void OnButton( wxCommandEvent& event );
  DECLARE_EVENT_TABLE()
};


/***** Immlementation for class DlgQuestion *****/

BEGIN_EVENT_TABLE(DlgQuestion, wxDialog)
  //EVT_BUTTON( ID_BUTTON, DlgQuestion::OnButt )
END_EVENT_TABLE()


class mgDataObj : public wxObject 
{
public:
  mgDataObj(){}
  virtual ~mgDataObj(){}
  int m_value;
};

class MyButton : public wxButton
{
public:
  MyButton(wxWindow* parent, wxWindowID id, wxString label): wxButton(parent, id,label)
  {  
    m_parent = (DlgQuestion*)parent;
  }
  void execute(wxCommandEvent& event)
  {  
    mgDataObj *obj = (mgDataObj *)event.m_callbackUserData; 
    m_parent->Show( FALSE ); 
    m_parent->Close(TRUE);
    m_parent->SetReturnCode(obj->m_value);
  }
  DlgQuestion *m_parent;
};

DlgQuestion::DlgQuestion( wxWindow* parent, wxString title,wxString texte,wxStringList str_buttons)  : wxDialog( parent, -1, title, wxDefaultPosition, wxDefaultSize, wxCAPTION|wxTHICK_FRAME)
{ 	
    wxBoxSizer *item0 = new wxBoxSizer( wxVERTICAL );

    wxStaticBox *item2 = new wxStaticBox( this, -1, title );
    wxStaticBoxSizer *item1 = new wxStaticBoxSizer( item2, wxHORIZONTAL );

    wxStaticText *item3 = new wxStaticText( this, -1, texte, wxDefaultPosition, wxDefaultSize, 0 );
    item1->Add( item3, 0, wxALIGN_CENTRE|wxALL, 5 );

    item0->Add( item1, 0, wxGROW|wxALL, 5 );

    wxBoxSizer *item4 = new wxBoxSizer( wxHORIZONTAL );

    wxButton **itemBut =new wxButton*[str_buttons.GetCount()];

    for(unsigned i=0;i<str_buttons.GetCount();i++)
    {
      itemBut[i] = new MyButton( this,ID_BUTTON + i, str_buttons.Item(i)->GetData());
      mgDataObj *obj = new mgDataObj();
      obj->m_value = i;
      itemBut[i]->Connect( ID_BUTTON + i,   wxEVT_COMMAND_BUTTON_CLICKED , (wxObjectEventFunction) (wxEventFunction) (wxCommandEventFunction) MyButton::execute,obj);
      item4->Add( itemBut[i], 0, wxALIGN_CENTRE|wxALL, 5 );
    }
    item0->Add( item4, 0, wxALIGN_CENTRE|wxALL, 5 );


    this->SetAutoLayout( TRUE );
    this->SetSizer( item0 );

    item0->Fit( this );
    item0->SetSizeHints( this );

}

DlgQuestion::~DlgQuestion()
{

}




#endif