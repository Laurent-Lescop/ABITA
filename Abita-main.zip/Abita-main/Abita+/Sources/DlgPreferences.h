#ifndef MG_GUIPREFERENCES
#define MG_GUIPREFERENCES

#include "precompiled.h"
#include "Application.h"
#include "textes.h"
#include "AbitaDocument.h"

enum ID_CONTROLS_PREFERENCES
{
  ID_PREFERENCES_OK = 10000,
  ID_PREFERENCES_QUITTER = 1,
  ID_CHECKTIPS,
  ID_TAILLE_GRILLE,
  ID_A1,
  ID_A2,
  ID_A3,
  ID_A4,
};

class DlgPreferences: public wxDialog
{
protected:
  wxCheckBox *m_tips;
  wxConfig *m_config;
  wxTextCtrl *m_taille_grille;
  wxTextCtrl *m_text_a1;
  wxTextCtrl *m_text_a2;
  wxTextCtrl *m_text_a3;
  wxTextCtrl *m_text_a4;  

  wxString m_string;

public:
  DlgPreferences( wxWindow* parent, wxString title );
  ~DlgPreferences();
 
  void OnQuitter( wxCommandEvent& event );
  void OnOk( wxCommandEvent& event );   
  bool OnClose(void) { return TRUE; }

  DECLARE_EVENT_TABLE()
};


/***** Immlementation for class DlgAbout *****/

BEGIN_EVENT_TABLE(DlgPreferences, wxDialog)
  EVT_BUTTON( ID_PREFERENCES_OK,  DlgPreferences::OnOk  )
  EVT_BUTTON( ID_PREFERENCES_QUITTER, DlgPreferences::OnQuitter )
END_EVENT_TABLE()


/*
class mgValidator : public wxValidator
{
  virtual bool Validate(wxWindow* parent)
  {
    wxWindow* wm = GetWindow();
    int u = 0;
    return true;
  }
};
*/

DlgPreferences::DlgPreferences( wxWindow* parent, wxString title )  : wxDialog( parent, -1, title,wxDefaultPosition,wxDefaultSize)
{ 		
  	m_config = new wxConfig("Abita+");

    // -------------

    wxBoxSizer *item0 = new wxBoxSizer( wxVERTICAL );

    wxStaticBox *item2 = new wxStaticBox( this, -1, RS_MENU_CONFIGURATION_INFO );
    wxStaticBoxSizer *item1 = new wxStaticBoxSizer( item2, wxVERTICAL );
  
    // -- les tips

    m_tips = new wxCheckBox( this, ID_CHECKTIPS, RS_PREFERENCES_TEXTE_TIPS, wxDefaultPosition, wxDefaultSize, 0 );
    item1->Add( m_tips, 0, wxALIGN_LEFT|wxALL, 5 );

    // --- taille de la grille

    wxBoxSizer *item10 = new wxBoxSizer( wxHORIZONTAL );
    wxStaticText *st = new wxStaticText(this, -1, RS_PREFERENCES_TAILLE_GRILLE);
    item10->Add( st, 0, wxALIGN_LEFT|wxALL, 5 );
    m_taille_grille = new wxTextCtrl( this, ID_TAILLE_GRILLE, wxString::Format("%.2f",wxGetApp().getGridSize()) , wxDefaultPosition, wxSize(80,-1), 0 );
    item10->Add( m_taille_grille, 0, wxALIGN_CENTRE|wxALL, 5 );
    item1->Add( item10, 0, wxALIGN_LEFT|wxALL, 5 );

    // --- parametres du solver

    wxStaticText *item108= new wxStaticText(this, -1, RS_PREFERENCES_SOLVER);
    item1->Add( item108, 0, wxALIGN_LEFT|wxALL, 5 );

    wxBoxSizer *item100 = new wxBoxSizer( wxHORIZONTAL );
    wxStaticText *item101= new wxStaticText(this, -1, RS_PREFERENCES_A1);
    item100->Add( item101, 0, wxALIGN_LEFT|wxALL, 5 );

    m_text_a1 = new wxTextCtrl( this, ID_A1, wxString::Format("%d",wxGetApp().get_a1()) , wxDefaultPosition, wxSize(80,-1), 0 /*,  mgValidator()*/ );
    item100->Add( m_text_a1, 0, wxALIGN_CENTRE|wxALL, 5 );
    item1->Add( item100, 0, wxALIGN_LEFT|wxALL, 5 );

    wxBoxSizer *item102 = new wxBoxSizer( wxHORIZONTAL );
    wxStaticText *item103= new wxStaticText(this, -1, RS_PREFERENCES_A2);
    item102->Add( item103, 0, wxALIGN_LEFT|wxALL, 5 );
    m_text_a2 = new wxTextCtrl( this, ID_A2, wxString::Format("%d",wxGetApp().get_a2()) , wxDefaultPosition, wxSize(80,-1), 0 );
    item102->Add( m_text_a2, 0, wxALIGN_CENTRE|wxALL, 5 );
    item1->Add( item102, 0, wxALIGN_LEFT|wxALL, 5 );

    wxBoxSizer *item104 = new wxBoxSizer( wxHORIZONTAL );
    wxStaticText *item105= new wxStaticText(this, -1, RS_PREFERENCES_A3);
    item104->Add( item105, 0, wxALIGN_LEFT|wxALL, 5 );
    m_text_a3 = new wxTextCtrl( this, ID_A3, wxString::Format("%d",wxGetApp().get_a3()) , wxDefaultPosition, wxSize(80,-1), 0 );
    item104->Add( m_text_a3, 0, wxALIGN_CENTRE|wxALL, 5 );
    item1->Add( item104, 0, wxALIGN_LEFT|wxALL, 5 );

    wxBoxSizer *item106 = new wxBoxSizer( wxHORIZONTAL );
    wxStaticText *item107= new wxStaticText(this, -1, RS_PREFERENCES_A4);
    item106->Add( item107, 0, wxALIGN_LEFT|wxALL, 5 );
    m_text_a4 = new wxTextCtrl( this, ID_A4, wxString::Format("%.2f",wxGetApp().get_a4()) , wxDefaultPosition, wxSize(80,-1), 0 );
    item106->Add( m_text_a4, 0, wxALIGN_CENTRE|wxALL, 5 );
    item1->Add( item106, 0, wxALIGN_LEFT|wxALL, 5 );

    // ---

    item0->Add( item1, 0, wxALIGN_LEFT|wxALL, 5 );

    wxBoxSizer *item4 = new wxBoxSizer( wxHORIZONTAL );

    wxButton *item5 = new wxButton( this, ID_PREFERENCES_OK, RS_DIALOG_OK, wxDefaultPosition, wxDefaultSize, 0 );
    item5->SetDefault();
    item4->Add( item5, 0, wxALIGN_CENTRE|wxALL, 5 );

    wxButton *item6 = new wxButton( this, ID_PREFERENCES_QUITTER, RS_DIALOG_ANNULER, wxDefaultPosition, wxDefaultSize, 0 );
    item4->Add( item6, 0, wxALIGN_CENTRE|wxALL, 5 );

    item0->Add( item4, 0, wxALIGN_CENTRE|wxALL, 5 );


    this->SetAutoLayout( TRUE );
    this->SetSizer( item0 );

    item0->Fit( this );
    item0->SetSizeHints( this );


    // ------------
    // init default preferences

    wxString str_temp;
    if(m_config)
				str_temp = m_config->Read("/GUI/showTips", "");
    if ( str_temp.IsEmpty() || (str_temp == "true") )
      m_tips->SetValue(true);
    else
      m_tips->SetValue(false);

}

DlgPreferences::~DlgPreferences()
{
    //delete m_tips
}

void DlgPreferences::OnOk( wxCommandEvent& event )
{
  if(m_tips->GetValue())
    m_config->Write("/GUI/showTips", "true");
  else
    m_config->Write("/GUI/showTips", "false");

  double d;
  // grid size
  m_taille_grille->GetValue().ToDouble(&d);
  wxGetApp().setGridSize((float)d);
  // fond d'ecran
  /*
  m_taille_fond->GetValue().ToDouble(&d);
  wxGetApp().m_frame->setSizeFondEcran((float)d);
*/
  long l;
  m_text_a1->GetValue().ToLong(&l);
  wxGetApp().set_a1(l);
  m_text_a2->GetValue().ToLong(&l);
  wxGetApp().set_a2(l);
  m_text_a3->GetValue().ToLong(&l);
  wxGetApp().set_a3(l);
  m_text_a4->GetValue().ToDouble(&d);
  wxGetApp().set_a4(d);

  Show( FALSE ); // TRICK:: hide it, to avoid flickered destruction

  Close(TRUE);
}

void DlgPreferences::OnQuitter( wxCommandEvent& event )
{
  Show( FALSE ); // TRICK:: hide it, to avoid flickered destruction

  Close(TRUE);

}

#endif
