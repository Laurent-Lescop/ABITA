#include "precompiled.h"
#include "InterfaceSolveur.h"

#include <map>

#include "Solution.h"
#include "Solveur/AbiFile.h"
#include "Solveur/Algo.h"
#include "Solveur/Geom.h"

//----------------------------------------------------------------------------

void convert(Document& document, CGeom &geom, CPopulation &popu, CAlgo &algo)
{
  typedef std::map<MeshConnected::VertexHandle, CPt*> Points;
  Points points;

  unsigned currentPointID = 1;
  unsigned currentElementID = 1;

  unsigned oldCurrentFloor = document.getCurrentFloor();

  for (unsigned currentFloorID=0; currentFloorID < document.getNumFloors(); currentFloorID++)
  {
    document.setCurrentFloor(currentFloorID);
    MeshConnected const& mesh = document.getShape();

    geom.AddFloor( new CFloor(currentFloorID) );

    //- add the points
    {
      MeshConnected::vertex_const_iterator it  = mesh.vertices_begin();
      MeshConnected::vertex_const_iterator end = mesh.vertices_end();
      while (it != end)
      {
        MeshConnected::VertexHandle vh = *it;
        MeshConnected::VertexData* vdata = mesh.getVertexData(vh);

        std::auto_ptr<CPt> newPt( new CPt(vdata->position.x, vdata->position.y, currentFloorID, currentPointID++) );
        points[vh] = newPt.get();
        geom.AddPoint( newPt.release() );
        
        ++it;
      }
    }

    //- add the elements
    {
      MeshConnected::polygon_const_iterator it = mesh.polygons_begin();
      MeshConnected::polygon_const_iterator end = mesh.polygons_end();
      while (it != end)
      {
        MeshConnected::PolygonHandle ph = *it;

        std::vector<MeshConnected::VertexHandle> vertices;
        mesh.findVertices(ph, vertices);

        std::auto_ptr<CElement> elt( new CElement(currentFloorID, currentElementID++) );
        unsigned const numVertices = vertices.size();
        for (unsigned i=0; i<numVertices; i++)
        {
          MeshConnected::VertexHandle vh = vertices[i];
          CPt* pt = points[vh];

          elt->AddPoint(pt);
        }

        MeshConnected::PolygonData* pdata = mesh.getPolygonData(ph);

        elt->Bonus   = 0.0f;
        elt->Imposed = false;
        elt->Common  = false;
        elt->Exit    = false;
        switch (pdata->getType())
        {
        case FREE_PART:
          break;
        case POSSIBLE_COMMON_PART:
          elt->Common = true;
          break;
        case IMPOSED_COMMON_PART:
          elt->Imposed = true;
          elt->Common  = true;
          break;
        case IMPOSED_EXIT_PART:
          elt->Common  = true;
          elt->Imposed = true;
          elt->Exit    = true;
          break;
        }

        geom.AddElement(elt.release());

        ++it;
      }
    }
  }

  document.setCurrentFloor(oldCurrentFloor);

  //- add the types

  for (unsigned i=0; i<5; i++)
  {
    Document::InfosTypeLogement const& infos = theDocument->getInfoTypeAppartement( Document::TypeLogement(i) );
    
    algo.AddType( new CTx(infos.benefit, infos.areaMin, infos.areaMax, infos.numMin, infos.numMax, i) );
  }

  algo.InitIT = wxGetApp().get_a1();
  algo.EndIT  = wxGetApp().get_a2();
  algo.NbSols = wxGetApp().get_a3();
  algo.Alpha  = wxGetApp().get_a4();

  //- validate the structures

  geom.Build();

  //- save the input structure in a dummy ABI file (for debugging & maintenance purpose)
  {
    CAbiFile file("structure.abi");
    file.Write( geom, popu, algo );
  }
}

//----------------------------------------------------------------------------

std::auto_ptr<Solution> convert( Document const& document,
                                 CSolution const& solution,
                                 unsigned floorID )
{
  std::auto_ptr<Solution> result( new Solution );

  unsigned const numLots = solution.NbLots;
  for (unsigned lotID=0; lotID<numLots; lotID++)
  {
    typedef std::map<int, MeshConnected::VertexHandle> ElemsDone;
    ElemsDone vertsDone;
  
    CLot const* lot = solution.LotList[lotID];

    std::auto_ptr<MeshConnected> meshForLot( new MeshConnected );

    for (int i=0; i<lot->NbElements; i++)
    {
      CElement const* elt = lot->ElementList[i];
      if (elt->FloorId == floorID)
      {
        std::vector<MeshConnected::VertexHandle> polygonForElement;

        for(int j=0; j<elt->NbPoints-1; j++)
        {
          CPt const* pt = elt->PointList[j];
          if (vertsDone.find(pt->No) == vertsDone.end())
          {
            std::auto_ptr<MeshConnected::VertexData> vdata( new MeshConnected::VertexData );
            vdata->position = Point2d(pt->X, pt->Y);
            vertsDone[pt->No] = meshForLot->createVertex( vdata );
          }

          polygonForElement.push_back( vertsDone[pt->No] );
        }

        std::auto_ptr<MeshConnected::PolygonData> pdata;
        if (elt->Exit)
        {
          pdata.reset( new MeshConnected::PolygonData( IMPOSED_EXIT_PART ) );
        }
        else
        {
          if (elt->Imposed)
          {
            pdata.reset( new MeshConnected::PolygonData( IMPOSED_COMMON_PART ) );
          }
          else
          {
            if (elt->Common)
            {
              pdata.reset( new MeshConnected::PolygonData( POSSIBLE_COMMON_PART ) );
            }
            else
            {
              pdata.reset( new MeshConnected::PolygonData( FREE_PART) );
            }
          }
        }
        meshForLot->createPolygon( polygonForElement, pdata );
      }
    }

    Solution::Lot::Type type;
    if (lotID == 0)
    {
      type = Solution::Lot::COMMON;
    }
    else
    {
      type = Solution::Lot::Type( Solution::Lot::T1 + lot->TypeNo );
    }

    Solution::Lot resultLot( type, meshForLot, lot->Area, lot->Fitness );
    result->addLot( resultLot );
  }

  return result;
}

//----------------------------------------------------------------------------
