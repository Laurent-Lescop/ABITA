#ifndef ABITA_DLG_VISUALISATION_H
#define ABITA_DLG_VISUALISATION_H

#include "Solution.h"
#include "textes.h"
#include "Solveur/Population.h"

//----------------------------------------------------------------------------

class CanvasVisualisation : public wxScrolledWindow
{
public:
  CanvasVisualisation() {};
  CanvasVisualisation( wxWindow *parent, wxWindowID, const wxPoint &pos, const wxSize &size );
  virtual ~CanvasVisualisation();

  void setSolution(std::auto_ptr<Solution> solution);

private:

  void OnMouseEvent(wxMouseEvent& event);
  void OnPaint( wxPaintEvent &event );
  void OnSize(wxSizeEvent& event);
  void OnScroll(wxScrollWinEvent &e);

  void PrepareDC(wxDC& dc);

  void  setSize();

  wxPoint convert(wxSize const& clientSize, Point2d const& position) const;

  DECLARE_DYNAMIC_CLASS(CanvasVisualisation)
  DECLARE_EVENT_TABLE()

  std::auto_ptr<Solution> m_solution;

  float m_minX, m_minY;
  float m_maxX, m_maxY;
};

//----------------------------------------------------------------------------

class DlgVisualisation: public wxFrame
{
public:

  DlgVisualisation( CPopulation& population, wxWindow* parent, wxString title ,wxSize size);
  ~DlgVisualisation();

  void OnQuit( wxCommandEvent& event );    
  bool OnClose(void) { return TRUE; }
  void OnSize(wxSizeEvent& event);
  void OnSolutionSelected(wxListEvent& event);
  void OnButtonImprimer( wxCommandEvent& event );    
  void OnButtonExporter( wxCommandEvent& event );    
  void OnButtonOk( wxCommandEvent& event );    
  void OnListColClick( wxListEvent& event );

  CPopulation const& getPopulation() const { return m_population; };

  wxBitmap drawSolutionsChart(unsigned graphicSizeX = 128,unsigned graphicSizeY = 128,float currentPos = -1.0);
  void setSolutionsListSortColumn(int column) { m_solSortColumn = column; };
  int compareSolutions( long item1, long item2 ) const;

  DECLARE_EVENT_TABLE()

private:
  CPopulation& m_population;

  wxBitmap createFilledBitmap(wxColour c);

  std::auto_ptr<wxSplitterWindow> m_splitter;

  wxStaticText *m_stats_text;

  wxStaticBitmap *wstb;
  wxListCtrl* m_solutionsList;                        //!< owned by m_leftPanel
  wxPanel* m_leftPanel;                               //!< owned by m_splitter
  wxPanel* m_rightPanel;                              //!< owned by m_splitter
  wxNotebook* m_noteBook;                             //!< owned by m_splitter
  std::vector<CanvasVisualisation*> m_canvasEtages;   //!< owned by m_noteBook

  int m_solSortColumn;
  unsigned m_currentIndexItem;
};


//----------------------------------------------------------------------------

#endif