#include "precompiled.h"
#include "AbitaDocument.h"

//----------------------------------------------------------------------------

extern Document* theDocument = new Document;

//----------------------------------------------------------------------------

Document::Document()
: m_pixelsPerMeter(10),
  m_sizeX(30),
  m_sizeY(30),
  m_currentFloor( 0 )
{
  m_shapes.push_back( boost::shared_ptr<MeshConnected>(new MeshConnected) );

  setInfoTypeAppartement( TypeLogement::T1, InfosTypeLogement( 70.f, 30.f, 45.f, 0, 1000 ));
  setInfoTypeAppartement( TypeLogement::T2, InfosTypeLogement( 80.f, 45.f, 60.f, 0, 1000 ));
  setInfoTypeAppartement( TypeLogement::T3, InfosTypeLogement(100.f, 60.f, 65.f, 0, 1000 ));
  setInfoTypeAppartement( TypeLogement::T4, InfosTypeLogement( 50.f, 75.f, 85.f, 0, 1000 ));
  setInfoTypeAppartement( TypeLogement::T5, InfosTypeLogement( 40.f, 85.f,100.f, 0, 1000 ));
}

Document::InfosTypeLogement const& Document::getInfoTypeAppartement(TypeLogement type) const
{
  return m_infosTypesLogements[type];
}

bool Document::isEmpty()
{
  unsigned const numFloors = m_shapes.size();

  for (unsigned floor=0; floor<numFloors; floor++)
  {
    if (m_shapes[floor]->vertices_size() != 0)
      return false;
  }
  
  return true;
}

void Document::setInfoTypeAppartement(TypeLogement type, InfosTypeLogement const& infos)
{
  m_infosTypesLogements[type] = infos;
}
