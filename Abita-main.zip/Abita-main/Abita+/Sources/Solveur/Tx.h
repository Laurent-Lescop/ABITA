// Tx.h: interface for the CTx class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TX_H__968A00AB_E4FB_4209_A4F6_81AE79A5720E__INCLUDED_)
#define AFX_TX_H__968A00AB_E4FB_4209_A4F6_81AE79A5720E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CTx  
{
public:
	float Benefit;
	float AreaMin;
	float AreaMax;
	int   NbMin;
	int   NbMax;
	int   No;
	int   Nb;
 CTx(float benefit, float areaMin, float areaMax, int nbMin, int nbMax, int no);
	CTx();
	virtual ~CTx();

};

#endif // !defined(AFX_TX_H__968A00AB_E4FB_4209_A4F6_81AE79A5720E__INCLUDED_)
