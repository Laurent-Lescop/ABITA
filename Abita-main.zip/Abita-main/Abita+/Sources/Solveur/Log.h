// Log.h: interface for the CLog class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LOG_H__3146A2C3_57A2_4155_A78F_227E58926D15__INCLUDED_)
#define AFX_LOG_H__3146A2C3_57A2_4155_A78F_227E58926D15__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include<iostream>
#include<fstream>
#include<string.h>

class CLog  
{
public:
  std::ofstream &GetStream() const { return Stream; }
	CLog(const char * const fileName=0);
	virtual ~CLog();

protected:
  static std::ofstream Stream;
};

#endif // !defined(AFX_LOG_H__3146A2C3_57A2_4155_A78F_227E58926D15__INCLUDED_)
