// Algo.h: interface for the CAlgo class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ALGO_H__58F66CA7_F943_4445_9441_923B5D74CFF4__INCLUDED_)
#define AFX_ALGO_H__58F66CA7_F943_4445_9441_923B5D74CFF4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Population.h"
#include "Geom.h"
#include "Lot.h"
#include "Tx.h"
#include "Log.h"

class CAlgo  
{
public:
	float Alpha;
	int   InitIT;
	int   EndIT;
	int   NbSols;

	int   NbTypes;
 CTx **TypeList;
	void  AddType(CTx * const type);

	void Evaluate(CSolution * const sol);
	int  CurrentIteration() { return CurrentIT; }
	bool Run();

	CPopulation * const Popu;
	CGeom * const Geom;

	CAlgo(CGeom * const geom, CPopulation * const popu);
	virtual ~CAlgo();

protected:
	int   MinLots;
	int   MaxLots;
	int   CurrentIT;
	float Rnd() { return float(rand()) / RAND_MAX; }
	float Rnd(float low, float high);
	int   Rnd(int low, int high);
	void  Error(int err);
	void  Init();
};

#endif // !defined(AFX_ALGO_H__58F66CA7_F943_4445_9441_923B5D74CFF4__INCLUDED_)
