// Population.cpp: implementation of the CPopulation class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <stdio.h>
#include "Population.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPopulation::CPopulation()
{
 SolutionList = 0;
 NbSolutions  = 0;
 MaxFitness   = 0;
 MinFitness   = 0;
 AveFitness   = 0;
 NbTest       = 0;
 SizeMax      = 2147483647;
}

CPopulation::~CPopulation()
{
 for(int i=0; i<NbSolutions; i++) delete SolutionList[i];
 delete SolutionList;
 NbSolutions  = 0;
 SolutionList = 0;
}

//////////////////////////////////////////////////////////////////////

void CPopulation::AddSolution(CSolution * const sol)
{
 int i;

 // Check argument

 if(sol==0) Error(1); 
 for(i=0; i<NbSolutions; i++) if(sol == SolutionList[i]) Error(2,i);

 // Save list address 
 
 CSolution** oldlist = SolutionList;
 
 // Create new list 

 SolutionList = new CSolution*[NbSolutions+1];
 if(SolutionList==0) Error(3);

 // Duplicate old pointers in new list

 for (i=0; i<NbSolutions; i++) SolutionList[i]=oldlist[i];
  
 // Add the new pointer to the list  

 SolutionList[NbSolutions++] = sol;

 // Free old list memory

 delete oldlist;
}

//////////////////////////////////////////////////////////////////////

void CPopulation::RemoveSolution(int index)
{
 if(index<0 || index>NbSolutions-1) return;

 delete SolutionList[index];
 for(int i=index; i<NbSolutions-1; i++) SolutionList[i]=SolutionList[i+1];

 NbSolutions--;
}

//////////////////////////////////////////////////////////////////////

bool CPopulation::InsertSolution(CSolution *const sol)
{
 int i,j;

 // if first time
 
 if(NbSolutions==0 && SizeMax>0) { AddSolution(sol); return true; }

 // check if solution already in 

 for(j=0; j<NbSolutions; j++)  if((*sol)==(*SolutionList[j])) return false;
 NbTest++;

 // get the position
 
 for(i=0; i<NbSolutions; i++) if(sol->Fitness>SolutionList[i]->Fitness) break;

 // insert the solution

 if(i==NbSolutions)
 {
  if(NbSolutions==SizeMax) return false;
  AddSolution(sol); 
 }
 else
 {
  if(NbSolutions==SizeMax) delete SolutionList[NbSolutions-1];
  else                     AddSolution(sol);
  for(j=NbSolutions-1; j>i; j--) SolutionList[j]=SolutionList[j-1];
  SolutionList[i] = sol;
 }

 return true;
}

//////////////////////////////////////////////////////////////////////

void CPopulation::Resize(int sizeMax)
{
 if(sizeMax<0) return;
 for(int i=sizeMax; i<NbSolutions; i++) delete SolutionList[i];
 SizeMax = sizeMax;
}

//////////////////////////////////////////////////////////////////////

void CPopulation::SortSolutions()
{
 int i,j,k;
 if(NbSolutions<1) return;

 // Save list address 
 
 CSolution** oldList = SolutionList;
 
 // Create new list 

 bool *id = new bool[NbSolutions];
 if(id==0) Error(4);
 for(i=0; i<NbSolutions; i++) id[i]=true;

 SolutionList = new CSolution*[NbSolutions];
 if(SolutionList==0) Error(5);

 // Sort the solution by decreasing fitness
 
 float maxFitness;
 float minFitness = oldList[0]->Fitness;
 for(i=1; i<NbSolutions; i++) 
  if(oldList[i]->Fitness<minFitness) { minFitness=oldList[i]->Fitness;}


 for(k=0; k<NbSolutions; k++)
 {
  maxFitness = minFitness;
  for(i=0; i<NbSolutions; i++) 
  {
   if(oldList[i]->Fitness >= maxFitness && id[i])
   {
    maxFitness = oldList[i]->Fitness; 
    j = i;
   }
  }
  SolutionList[k] = oldList[j]; 
  id[j] = false;
 }

 // Free memory

 delete oldList;
 delete id;

}

//////////////////////////////////////////////////////////////////////

void CPopulation::Stats()
{
 int i,nbval;
 float fitness;

 // Compute the Min, Max and Averaged fitness 

 MaxFitness = NbSolutions>0 ? SolutionList[0]->Fitness : 0.0f;
 MinFitness = NbSolutions>0 ? SolutionList[0]->Fitness : 0.0f;
 AveFitness = NbSolutions>0 ? SolutionList[0]->Fitness : 0.0f;
 for(i=1, nbval=0; i<NbSolutions; i++) 
 {
  fitness = SolutionList[i]->Fitness;
  if(fitness>0) // avoid out of bound solutions
  {
   AveFitness += fitness;
   if(fitness>MaxFitness)      MaxFitness = fitness;
   else if(fitness<MinFitness) MinFitness = fitness;
   nbval++;
  }
 }
 AveFitness /= nbval>0 ? nbval : 1;
}

//////////////////////////////////////////////////////////////////////

void CPopulation::Error(int err, int id)
{
 CLog log;
 std::ofstream& slog = log.GetStream();

 slog << "\n\n";
 slog << "=====================================\n";
 slog << "=====================================\n";
 slog << "=============   ERROR   =============\n";
 slog << "=====================================\n";
 slog << "=====================================\n";

 slog << "\nPopulation : \n----------\n\n ";

 switch (err)
 {
  case 1: slog << "AddSolutionError : null sol";                    break;
  case 2: slog << "AddSolutionError : S" << id<< "already defined"; break;
  case 3: slog << "AddSolutionError : null SolutionList";           break;
  case 4: slog << "SortSolutionError : null id";                    break;
  case 5: slog << "SortSolutionError : null SolutionList";          break;
  default : slog << "UnknownError";
 }

 throw std::runtime_error("");
}

//////////////////////////////////////////////////////////////////////
