// Segment.h: interface for the CSegment class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SEGMENT_H__9F40671B_948E_423E_A56D_8EE2C73E7EC6__INCLUDED_)
#define AFX_SEGMENT_H__9F40671B_948E_423E_A56D_8EE2C73E7EC6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#include "Element.h"
class CElement;
class CPt;

class CSegment  
{
public:
	const int FloorId;
	bool  Mark;
	float Length;
	bool SetElement(CElement * const elt);
	CElement * NextOf(const CElement * const elt) { return E1==elt ? E2 : E2==elt ? E1 : 0; }
	CPt * const P1;
	CPt * const P2;
	CElement * E1;
	CElement * E2;
	CSegment(CPt * const p1, CPt * const p2);
	virtual ~CSegment();
 bool operator == (const CSegment &seg) const;

};

#endif // !defined(AFX_SEGMENT_H__9F40671B_948E_423E_A56D_8EE2C73E7EC6__INCLUDED_)
