// VisuCase.h: interface for the CVisuCase class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_VISUCASE_H__E91AD1EF_C062_4362_8321_867392EF29B8__INCLUDED_)
#define AFX_VISUCASE_H__E91AD1EF_C062_4362_8321_867392EF29B8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CVisuCase  
{
public:
	void ClearAll();
 int CurrentSolution;
 int CurrentFloor;
 int CurrentLot;
 int CurrentElement; 

	void SetCase(HTREEITEM hitem);
	void AddCase(HTREEITEM hitem, int solution, int floor, int lot, int element);
	CVisuCase();
	virtual ~CVisuCase();
private:
	int  NbCase;
	int * Solution;
	int * Floor;
	int * Lot;
	int * Element;
 HTREEITEM * hItem;
};

#endif // !defined(AFX_VISUCASE_H__E91AD1EF_C062_4362_8321_867392EF29B8__INCLUDED_)
