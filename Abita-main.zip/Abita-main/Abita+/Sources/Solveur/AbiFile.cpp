// AbiFile.cpp: implementation of the CAbiFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <string.h>
#include <stdio.h>
#include "AbiFile.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CAbiFile::CAbiFile(const char* fileName)
{
 FileName=strdup(fileName);
}

CAbiFile::~CAbiFile()
{
 free(FileName);
}

//////////////////////////////////////////////////////////////////////

void CAbiFile::Read(CGeom &geom, CPopulation &popu, CAlgo &algo)
{
 char c;
 float x,y,f,b,a1,a2;
 int floorId = 0;
 int solId = -1;
 int i,j,nb,id,ie,i1,i2;
 CElement  * elt;
 CSolution * sol;


 // Open the file 
 
 FILE *fp = fopen(FileName,"r"); 
 if(fp==0) Error(7,FileName);

 // Read file

 do
 {
  c = ' ';
  fscanf(fp, "%1s", &c );

  switch(c)
  {
   // Solver's parameters 
   // -------------------

   case 'A' :

    if(fscanf(fp, "%d", &id) != 1) Error(8,"A");
    switch(id)
    {
     case 1:
      if(fscanf(fp, "%d", &i1) != 1) Error(8,"A1");
      algo.InitIT = i1;
      break;
     case 2:
      if(fscanf(fp, "%d", &i1) != 1) Error(8,"A2");
      algo.EndIT = i1;
      break;
     case 3:
      if(fscanf(fp, "%d", &i1) != 1) Error(8,"A3");
      algo.NbSols = i1;
      break;
     case 4:
      if(fscanf(fp, "%f", &f) != 1) Error(8,"A4");
      algo.Alpha = f;
      break;
     default:
      Error(8);
    }
    break;

   // Bonus 
   // -----

   case 'B' :

    if(fscanf(fp, "%d %f", &ie, &b) != 2) Error(8,"B");

    // check if element exists and find its index

    for(j=0; j<geom.NbElements; j++) if(geom.ElementList[j]->No==ie) break; 
    if(j==geom.NbElements) Error(13,"",ie);

    // save bonus

    geom.ElementList[j]->Bonus=f;
    break;

   // Communs 
   // -------

   case 'C' :

    if(fscanf(fp, "%d", &ie) != 1) Error(8,"C");

    // check if element exists and find its index

    for(j=0; j<geom.NbElements; j++) if(geom.ElementList[j]->No==ie) break; 
    if(j==geom.NbElements) Error(13,"",ie);

    // mark element as possible common element

    geom.ElementList[j]->Common=true;
    break;

   // Element 
   // -------

   case 'E' :
    
    if(fscanf(fp, "%d %d", &ie, &nb) != 2) Error(8,"E",-1);

    // check if element not already defined

    for(i=0; i<geom.NbElements; i++) if(geom.ElementList[i]->No==ie) Error(10,"",ie);

    // create new element

    geom.AddElement(elt = new CElement(floorId,ie));

    // define element by points name

    for(i=0; i<nb; i++) 
    {
     if(fscanf(fp, "%d", &id) != 1) Error(8,"E",i);

     // check if point not already used for this element

     for(j=0; j<elt->NbPoints; j++) if(elt->PointList[j]->No==id) break;
     if(j<elt->NbPoints) Error(12,"",ie);

     // check if point exists and find its index

     for(j=0; j<geom.NbPoints; j++) if(geom.PointList[j]->No==id) break; 
     if(j==geom.NbPoints) Error(11,"",ie);

     // add point to element definition

     elt->AddPoint(geom.PointList[j]);
    }
    break;

   // floor
   // -----

   case 'F' :
    
    if(fscanf(fp, "%d", &i) != 1) Error(8,"F");
    geom.AddFloor(new CFloor(i));
    floorId=geom.NbFloors-1;
    break;

   // Imposed 
   // -------

   case 'I' :

    if(fscanf(fp, "%d", &ie) != 1) Error(8,"I");

    // check if elmement exists and find its index

    for(j=0; j<geom.NbElements; j++) if(geom.ElementList[j]->No==ie) break; 
    if(j==geom.NbElements) Error(13,"",ie);

    // mark element as imposed common element

    geom.ElementList[j]->Common  = true;
    geom.ElementList[j]->Imposed = true;
    break;

   // lot
   // ---

   case 'L' :
    
    if(fscanf(fp, "%d %d %f %d", &id, &i1, &f, &nb) != 4) Error(8,"L",-1);

    // set part of the distribution

    for(i=0; i<nb; i++) 
    {
     if(fscanf(fp, "%d", &ie) != 1) Error(8,"L",i);
     for(j=0; j<geom.NbElements; j++) if(geom.ElementList[j]->No==ie) break;
     popu.SolutionList[solId]->Distribution[j]=id;
    }
    break;

   // point 
   // -----

   case 'P' :
    
    if(fscanf(fp, "%d %f %f", &id, &x, &y ) != 3) Error(8,"P"); 

    // check if point not already exist

    for(i=0; i<geom.NbPoints; i++) if(geom.PointList[i]->No==id) Error(9,"",id);

    // create new point

    geom.AddPoint(new CPt(x,y,floorId,id));
    break;

   // solution
   // --------

   case 'S' :
    
    if(fscanf(fp, "%d %f", &i, &f) != 2) Error(8,"S");
    sol = new CSolution(&geom);
    popu.AddSolution(sol);
    sol->Fitness = f;
    solId++;
    break;

   // Type 
   // ----

   case 'T' :
    
    if(fscanf(fp, "%d %f %f %f %d %d", &id, &b, &a1, &a2, &i1, &i2) != 6) Error(8,"T"); 

    // check if Type not already exist

    for(i=0; i<algo.NbTypes; i++) if(algo.TypeList[i]->No==id) Error(6,"",id);

    // create new Type

    algo.AddType(new CTx(b,a1,a2,i1,i2,id));
    break;

   // Exit 
   // ----

   case 'X' :

    if(fscanf(fp, "%d", &ie) != 1) Error(8,"X");

    // check if elmement exists and find its index

    for(j=0; j<geom.NbElements; j++) if(geom.ElementList[j]->No==ie) break; 
    if(j==geom.NbElements) Error(13,"",ie);

    // mark element as imposed common element

    geom.ElementList[j]->Common  = true;
    geom.ElementList[j]->Imposed = true;
    geom.ElementList[j]->Exit    = true;
    break;

  }

 }

 while(!feof(fp));
 fclose(fp);

 // initialize geometry, population and algorithm

 geom.Build();
 for(i=0; i<popu.NbSolutions; i++) algo.Evaluate(popu.SolutionList[i]);
 popu.Stats();

}

//////////////////////////////////////////////////////////////////////

void CAbiFile::Write(CGeom &geom, CPopulation &popu, CAlgo &algo)
{
 int i,j,k;
 CSolution *sol;
 CElement  *elt;
 CFloor    *floor;
 CLot      *lot;
 CPt       *pt;
 CTx       *type;

 // Open the file 
 // -------------
 
 FILE *fp = fopen(FileName,"w"); 
 if(fp==0) Error(14,FileName);

 // Write algorithm parameters
 // --------------------------

 // solver's parameters

 fprintf(fp, "A1 %8d\n",   algo.InitIT);
 fprintf(fp, "A2 %8d\n",   algo.EndIT);
 fprintf(fp, "A3 %8d\n",   algo.NbSols);
 fprintf(fp, "A4 %8.2f\n", algo.Alpha);

 // types definition

 for(i=0; i<algo.NbTypes; i++)
 {
  type = algo.TypeList[i]; 
  fprintf(fp, "T%d %8.2f %8.2f %8.2f %6d %6d\n", type->No,
                                                 type->Benefit,
                                                 type->AreaMin,
                                                 type->AreaMax,
                                                 type->NbMin,
                                                 type->NbMax);
 }

 // Write geometry
 // --------------

 for(i=0; i<geom.NbFloors; i++)
 {
  // floor no

  floor = geom.FloorList[i];
  fprintf(fp, "F%d\n", floor->No);

  // points coordinates

  for(j=0; j<geom.NbPoints; j++)
  {
   pt = geom.PointList[j];
   if(pt->FloorId==i) 
   {
    if(pt->No<10)       fprintf(fp, "P%d   %8.2f %8.2f\n", pt->No, pt->X, pt->Y);
    else if(pt->No<100) fprintf(fp, "P%d  %8.2f %8.2f\n", pt->No, pt->X, pt->Y);
    else                fprintf(fp, "P%d %8.2f %8.2f\n", pt->No, pt->X, pt->Y);
   }
  }

  // elements definition

  for(j=0; j<floor->NbElements; j++)
  {
   elt = floor->ElementList[j];
   if(elt->No<10)       fprintf(fp, "E%d   %5d", elt->No, elt->NbPoints-1);
   else if(elt->No<100) fprintf(fp, "E%d  %5d", elt->No, elt->NbPoints-1);
   else                 fprintf(fp, "E%d %5d", elt->No, elt->NbPoints-1);
   for(k=0; k<elt->NbPoints-1; k++) fprintf(fp," %5d",elt->PointList[k]->No); 
   fprintf(fp, "\n");
  }

  // list of common elements

  for(j=0; j<floor->NbElements; j++)
   if(floor->ElementList[j]->Common && !floor->ElementList[j]->Imposed) 
    fprintf(fp, "C%d\n", floor->ElementList[j]->No);

  // list of imposed common element

  for(j=0; j<floor->NbElements; j++)
   if(floor->ElementList[j]->Imposed && !floor->ElementList[j]->Exit) 
    fprintf(fp, "I%d\n", floor->ElementList[j]->No);

  // list of exit imposed common element

  for(j=0; j<floor->NbElements; j++)
   if(floor->ElementList[j]->Exit) 
    fprintf(fp, "X%d\n", floor->ElementList[j]->No);

  // list of bonus

  for(j=0; j<floor->NbElements; j++)
   if(floor->ElementList[j]->Bonus != 0.f) 
    fprintf(fp, "B%d %8.2f\n", floor->ElementList[j]->No, floor->ElementList[j]->Bonus);
 }

 // Write solutions
 // ---------------

 for(i=0; i<popu.NbSolutions; i++)
 {
  sol = popu.SolutionList[i];

  if(sol->Fitness>0)  // remove out of bound solutions
  {
   // solution No and fitness

   fprintf(fp, "S%d %8.2f\n", i, sol->Fitness); 

   // lots definition

   for(j=0; j<sol->NbLots; j++)
   {
    lot = sol->LotList[j];
    if(j<10)       fprintf(fp, "L%d   %3d %8.2f %4d", j, lot->TypeNo, lot->Fitness, lot->NbElements);
    else if(j<100) fprintf(fp, "L%d  %3d %8.2f %4d", j, lot->TypeNo, lot->Fitness, lot->NbElements);
    else           fprintf(fp, "L%d %3d %8.2f %5d", j, lot->TypeNo, lot->Fitness, lot->NbElements);
    for(k=0; k<lot->NbElements; k++) fprintf(fp," %5d",lot->ElementList[k]->No);
    fprintf(fp, "\n");
   }
  }
 }

 fclose(fp);
}

//////////////////////////////////////////////////////////////////////

void CAbiFile::Error(int err, const char *msg, int id)
{
 CLog log;
 std::ofstream& slog = log.GetStream();

 slog << "\n\n";
 slog << "=====================================\n";
 slog << "=====================================\n";
 slog << "=============   ERROR   =============\n";
 slog << "=====================================\n";
 slog << "=====================================\n";

 slog << "\nAbiFile : \n-------\n\n ";

 switch (err)
 {
  case 6:   slog << "ReadError : Type T" << id << " already defined";    break;
  case 7:   slog << "ReadError : Cannot open file " << msg;              break;
  case 8:   slog << "ReadError : wrong format";                          break;
  case 9:   slog << "ReadError : Point P" << id << " already defined";   break;
  case 10:  slog << "ReadError : Element E" << id << " already defined"; break;
  case 11:  slog << "ReadError : Undefined point in element E" << id;    break;
  case 12:  slog << "ReadError : Double point in element E"<< id ;       break;
  case 13:  slog << "ReadError : Undefined element E"<< id ;             break;
  case 14:  slog << "WriteError : Cannot open file " << msg;             break;
  default : slog << "UnknownError";
 }

 throw std::runtime_error("");
}

//////////////////////////////////////////////////////////////////////
