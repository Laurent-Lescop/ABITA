// graphdrawer.h: interface for the CGraphDrawer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GRAPHDRAWER_H__414883E7_055B_4862_8125_E4B41FEF493B__INCLUDED_)
#define AFX_GRAPHDRAWER_H__414883E7_055B_4862_8125_E4B41FEF493B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Population.h"

class CGraphDrawer 
{
public:
	void SetSize(CPopulation *const pPopu, int w, int h);
	void DrawCurve(CPopulation *const pPopu, CDC *pDC);
	void DrawSolution(float x, float y, CDC *pDC);
	CGraphDrawer();
	virtual ~CGraphDrawer();

private:
	int W;
	int H;
 float Xmin;
 float Xmax;
 float Ymin;
 float Ymax;
};

#endif // !defined(AFX_GRAPHDRAWER_H__414883E7_055B_4862_8125_E4B41FEF493B__INCLUDED_)
