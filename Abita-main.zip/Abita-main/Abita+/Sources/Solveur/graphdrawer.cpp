// graphdrawer.cpp: implementation of the CGraphDrawer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "../visualiseur/visualiseur.h"
#include "graphdrawer.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGraphDrawer::CGraphDrawer()
{
 W=100;
 H=100;
 Xmin=0;
 Xmax=1;
 Ymin=0;
 Ymax=1;
}

CGraphDrawer::~CGraphDrawer()
{

}

//////////////////////////////////////////////////////////////////////

void CGraphDrawer::DrawCurve(CPopulation *const pPopu, CDC *pDC)
{
 float x,y;
 CPen pen;

  // select the right pen
 
 pen.CreatePen(PS_SOLID, 1, RGB(0, 0, 255));
 CPen* pOldPen = pDC->SelectObject(&pen);

 // Build, draw and free the polyline
 
 CPoint *poly = new CPoint[pPopu->NbSolutions];
 for(int i=0; i<pPopu->NbSolutions; i++)
 {
  x    = float(i);
  y    = pPopu->SolutionList[i]->Fitness;
  poly[i].x = int(W*(x-Xmin)/(Xmax-Xmin));
  poly[i].y = int(H*(y-Ymax)/(Ymin-Ymax));
 }
 pDC->Polyline(poly, pPopu->NbSolutions);
 delete [] poly;

 // Put back the old objects.

 pDC->SelectObject(pOldPen);
}

//////////////////////////////////////////////////////////////////////

void CGraphDrawer::SetSize(CPopulation *const pPopu, int w, int h)
{
 float f;

 if(pPopu->NbSolutions<1) return;

 W = w-1;
 H = h-1;

 Xmin = 0;
 Xmax = float(pPopu->NbSolutions-1);

 Ymin = pPopu->SolutionList[0]->Fitness;
 Ymax = pPopu->SolutionList[0]->Fitness;

 for(int i=1; i<pPopu->NbSolutions; i++)
 {
  f = pPopu->SolutionList[i]->Fitness;
  if(Ymin>f) Ymin = f;
  if(Ymax<f) Ymax = f;
 }

 if(Ymin==Ymax)
 {
  Ymin -= 10; 
  Ymax += 10; 
 }
}

//////////////////////////////////////////////////////////////////////

void CGraphDrawer::DrawSolution(float x, float y, CDC *pDC)
{
 CPen pen;

  // select the right pen
 
 pen.CreatePen(PS_SOLID, 1, RGB(255, 0, 0));
 CPen* pOldPen = pDC->SelectObject(&pen);

 // Put back the old objects.

 pDC->MoveTo(int(W*(x-Xmin)/(Xmax-Xmin)), H); 
 pDC->LineTo(int(W*(x-Xmin)/(Xmax-Xmin)), int(H*(y-Ymax)/(Ymin-Ymax))); 
 
 // Put back the old objects.

 pDC->SelectObject(pOldPen);
}

//////////////////////////////////////////////////////////////////////
