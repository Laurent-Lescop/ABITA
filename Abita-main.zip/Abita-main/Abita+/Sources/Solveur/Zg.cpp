// Zg.cpp: implementation of the CZg class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <math.h>
#include "Zg.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CZg::CZg()
{
 // On initialise le zoom
 
 Zoom = 1;

 // On initialise par la transformation identit�

 SetTransfo(0., 0., 1., 0.);

 // Les dimensions par d�faut de l'espace "absolu"
 Xmin=Ymin=0;
 Xmax=Ymax=1;
}

CZg::~CZg()
{

}

//////////////////////////////////////////////////////////////////////
// Mise en place automatique d'un objet centr� en (xc,yc) et d'�tendue
// (dx,dy).
//////////////////////////////////////////////////////////////////////

void CZg::AutoScale(int w, int h)
{

 // On d�finie les envergures et le centre
 
 float dx = Xmax-Xmin;
 float dy = Ymax-Ymin;
 float xc =(Xmax+Xmin)/2;
 float yc =(Ymax+Ymin)/2;
 
 // On choisi la longueur (lx) la plus contraigante selon x pour que le 
 // point de coordonn�es absolues (xc,yc) se retrouve au centre et pour  
 // que la zone d'�tendue (dx,dy) soit enti�rement visible sachant que  
 // la transformation reste isom�trique.
 
 float lx = dx*h>dy*w ? float(0.5)*dx : float(0.5)*dy*w/h;
 float ly = lx*h/w;
 float scale = w/lx/2;

 SetTransfo(xc-lx, yc+ly, xc+lx, yc+ly, scale);
}



//////////////////////////////////////////////////////////////////////

float CZg::SetZoom(const float &zoom)
{
 float z= zoom/Zoom;

 // On modifie les constantes de la transformation

 Ar *= z;
 Br *= z;
 A  /= z;
 B  /= z;

 // on sauvegarde la nouvelle valeur de l'�chelle

 z    = Zoom;
 Zoom = zoom;

 // on retourne l'ancien zoom

 return z;

}

//////////////////////////////////////////////////////////////////////


void CZg::SetSize(const float &xmin, const float &xmax, 
                  const float &ymin, const float &ymax)
{
 Xmin=xmin;
 Xmax=xmax;
 Ymin=ymin;
 Ymax=ymax;
}

//////////////////////////////////////////////////////////////////////

void CZg::SetTransfo(float x0, float y0, float x1, float y1, float scale)
{
 // On commence par v�rifier que la transformation est valide
 
 float li = (x1-x0)*(x1-x0) + (y1-y0)*(y1-y0);
 li=(float)(1/sqrt(li));

 // On sauvegarde la valeur de l'echelle
 // Echelle = Longueur dans le r�f�renciel physique d'une unit�
 //           du r�f�renciel transform�

 Scale = scale;
 
 // On calcul les constantes de la tranformation physique->transform�
 // U = Ar.X + Br.Y + Cr
 // V = Br.X - Ar.Y - Dr

 Ar = (x1-x0) * li * Scale;
 Br = (y1-y0) * li * Scale;
 Cr =-Ar*x0 - Br*y0;
 Dr = Br*x0 - Ar*y0;

 // On calcul les constantes de la tranformation transform�->physique
 // X = A.U + B.V + C
 // Y = B.U - A.V - D

 A = (x1-x0) * li / Scale;
 B = (y0-y1) * li / Scale;
 C = x0;
 D = y0;

}

