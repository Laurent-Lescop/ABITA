// Floor.cpp: implementation of the CFloor class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <stdio.h>
#include "Floor.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CFloor::CFloor(int no) : No(no)
{
 NbElements  = 0;
 ElementList = 0;
}

CFloor::~CFloor()
{

}

//////////////////////////////////////////////////////////////////////

void CFloor::AddElement(CElement *const elt)
{
 int i;

 // Check argument

 if(elt==0) Error(1); 
 for(i=0; i<NbElements; i++) if(elt == ElementList[i]) Error(2,"",elt->No);

 // Save list address 
 
 CElement** oldlist = ElementList;
 
 // Create new list 

 ElementList = new CElement*[NbElements+1];
 if(ElementList==0) Error(3);

 // Duplicate old pointers in new list

 for(i=0; i<NbElements; i++) ElementList[i]=oldlist[i];
  
 // Add the new pointer to the list  

 ElementList[NbElements++] = elt;

 // Free old list memory

 delete oldlist;
}

//////////////////////////////////////////////////////////////////////

void CFloor::Error(int err, const char * msg, int id)
{
 CLog log;
 std::ofstream& slog = log.GetStream();

 slog << "\n\n";
 slog << "=====================================\n";
 slog << "=====================================\n";
 slog << "=============   ERROR   =============\n";
 slog << "=====================================\n";
 slog << "=====================================\n";

 slog << "\nFloor : \n----\n\n ";

 switch (err)
 {
  case 1: slog << "AddElementError : null elt";                          break;
  case 2: slog << "AddElementError : elt E" << id << " already defined"; break;
  case 3: slog << "AddElementError : null ElementList";                  break;
  default : slog << "UnknownError";
 }

 throw std::runtime_error("");
}

//////////////////////////////////////////////////////////////////////
