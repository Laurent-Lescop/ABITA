// Algo.cpp: implementation of the CAlgo class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <stdio.h>
#include <time.h>
#include "Algo.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CAlgo::CAlgo(CGeom * const geom, CPopulation * const popu) 
     : Geom(geom), Popu(popu)
{
 // initialise the iteration counter
 
 CurrentIT = 0;

 // seed the random-number generator 

 srand( (unsigned)time( NULL ) );

 // default values
 
 NbSols   = 100;
 MinLots  =   0;
 MaxLots  =   0;
 InitIT   =  -1;
 EndIT    =  -1;
 Alpha    = 0.0f;

 NbTypes  = 0;
 TypeList = 0;
}

CAlgo::~CAlgo()
{
 for(int i=0; i<NbTypes; i++) delete TypeList[i];
 delete TypeList;
}

//////////////////////////////////////////////////////////////////////

bool CAlgo::Run()
{
 int i,j,k;
 CSolution *newSol;
 CSolution *sol;
 CPopulation newPopu;


 // initialiazing: first iteration
 // ------------------------------
 
 if(CurrentIT==0)
 {
  Init();
  Popu->SortSolutions();
 }

 // update the iteration counter
 // ----------------------------
 
 CurrentIT++;
 if(CurrentIT > InitIT+EndIT) return false;


 // generate randomized solutions 
 // -----------------------------

 if(CurrentIT<=InitIT)
 {
  newSol = new CSolution(Geom);

   newSol->RndSet(Rnd(MinLots,MaxLots));

  Evaluate(newSol);

  if(!Popu->InsertSolution(newSol)) 
  { 
   delete newSol; 
  }
  else
  {
   newPopu.Resize(Popu->NbSolutions);
   for(j=0; j<newSol->NbLots; j++)
   {
    for(k=0; k<newSol->LotList[j]->NbSegments; k++)
    {
     sol = new CSolution(newSol);
     sol->Swap(j,k);
     Evaluate(sol);
     if(!newPopu.InsertSolution(sol)) delete sol;
    }
   }
   for(i=0; i<newPopu.NbSolutions; i++)
    if(Popu->InsertSolution(newPopu.SolutionList[i])) newPopu.SolutionList[i]=0;
  }
 }

 // Finish by local improvements
 // ----------------------------

 else
 {
  newPopu.Resize(Popu->NbSolutions);

  for(i=0; i<Popu->NbSolutions; i++)
  {
   for(j=0; j<Popu->SolutionList[i]->NbLots; j++)
   {
    for(k=0; k<Popu->SolutionList[i]->LotList[j]->NbSegments; k++)
    {
     newSol = new CSolution(Popu->SolutionList[i]);
     newSol->Swap(j,k);
     Evaluate(newSol);
     if(!newPopu.InsertSolution(newSol)) delete newSol;
    }
   }
  }

  for(i=k=0; i<newPopu.NbSolutions; i++)
  {
   if(Popu->InsertSolution(newPopu.SolutionList[i])) 
   { 
    newPopu.SolutionList[i]=0; 
    k++; 
   }
  }

  if(k==0) return false;   
 }

 // Evaluate the population
 // -----------------------

 Popu->Stats();

 return true;
}

//////////////////////////////////////////////////////////////////////

int CAlgo::Rnd(int low, int high)
{
 int i = int((high - low + 1) * Rnd()) + low;
 return i>high ? high : i<low ? low : i;
}

float CAlgo::Rnd(float low, float high)
{
 float f = (high - low) * Rnd() + low;
 return f>high ? high : f<low ? low : f;
}

//////////////////////////////////////////////////////////////////////

void CAlgo::Evaluate(CSolution *const sol)
{
 int i,j;
 CLot *lot;

 // Build lots if needed
 // --------------------

 if(sol->NbLots==0) sol->SetLots();

 // Initialize quantities
 // ---------------------

 sol->Fitness = 0;
 float sumArea = sol->LotList[0]->Area;

 for(j=0; j<NbTypes; j++) TypeList[j]->Nb=0;

 // Compute fitness
 // ---------------

 for(i=1; i<sol->NbLots; i++)
 {
  lot = sol->LotList[i];

  // Compute the TYPE benefit

  for(j=0; j<NbTypes; j++) 
  {
   if(lot->Area>TypeList[j]->AreaMin && lot->Area<=TypeList[j]->AreaMax)
   {
    lot->Fitness = lot->Area * TypeList[j]->Benefit;
    lot->TypeNo  = TypeList[j]->No;
    TypeList[j]->Nb++;
   }
  }

  // Add (or remove) bonus for good (bad) elements

  if(lot->Fitness>0)
   for(j=0; j<lot->NbElements; j++) 
    lot->Fitness += lot->ElementList[j]->Bonus * lot->ElementList[j]->Area;

  // Penalize for aspect ratio

  lot->Fitness *= 1 + Alpha*(lot->Area/(lot->Length*lot->Length)-1);

  // Accumulate solution fitness

  sol->Fitness += lot->Fitness;
  sumArea += lot->Area;
 }

 // Penalize for out of bounds
 // --------------------------

 for(i=j=0; j<NbTypes; j++) 
 { 
  i += TypeList[j]->Nb; 
  if(TypeList[j]->Nb>TypeList[j]->NbMax || TypeList[j]->Nb<TypeList[j]->NbMin) 
  {
   sol->Fitness = 0;
   break;
  }
 }
 if(i != sol->NbLots-1) sol->Fitness = 0;

 // Reduce benefits to unit area
 // ----------------------------

 for(i=1; i<sol->NbLots; i++) sol->LotList[i]->Fitness /= sol->LotList[i]->Area;
 sol->Fitness /= sumArea;
 
 // Sort lots for future comparison
 // -------------------------------

 sol->SortLots();
}

//////////////////////////////////////////////////////////////////////

void CAlgo::Init()
{
 int i,sum;
 CElement *elt;
 CSegment *seg;
 CLot     *lot;
 CSolution sol(Geom);

 // set the default types if not already specified

 if(NbTypes==0)
 {
  AddType(new CTx(70.,  30., 45.,  0, 1000, 1));
  AddType(new CTx(80.,  45., 60.,  0, 1000, 2));
  AddType(new CTx(100., 60., 75.,  0, 1000, 3));
  AddType(new CTx(50.,  75., 85.,  0, 1000, 4));
  AddType(new CTx(40.,  85., 100., 0, 1000, 5));
 }

 // compute the maximum number of lots

 lot = new CLot(&sol,0);

  for(i=0; i<Geom->NbElements; i++)
   if(Geom->ElementList[i]->Common) lot->AddElement(Geom->ElementList[i]);

  lot->BuildBorder();

  for(i=0; i<Geom->NbElements; i++) Geom->ElementList[i]->Mark=false;

  for(i=MaxLots=0; i<lot->NbSegments; i++) 
  {
   seg = lot->SegmentList[i];
   elt = lot->Contain(seg->E1) ? seg->E2 : seg->E1;
   if(elt!=0) elt->Mark=true;
  }
  for(i=MaxLots=0; i<Geom->NbElements; i++) 
   if(Geom->ElementList[i]->Mark) MaxLots++;

 delete lot;

 for(i=sum=0; i<NbTypes; i++) sum += TypeList[i]->NbMax;
 if(MaxLots>sum) MaxLots=sum;

 MinLots = 1;
 for(i=sum=0; i<NbTypes; i++) sum += TypeList[i]->NbMin;
 if(MinLots<sum) MinLots=sum;

 // update default values if not specified yet
 
 if(InitIT<0) InitIT = 250 * MaxLots;
 if(EndIT<0)  EndIT  = 10  * MaxLots;

 // resize the population

 Popu->Resize(NbSols);

 // evaluate the initializing polulation

 for(i=0; i<Popu->NbSolutions; i++) Evaluate(Popu->SolutionList[i]);
 Popu->Stats();
 
}

//////////////////////////////////////////////////////////////////////

void CAlgo::AddType(CTx * const type)
{
 int i;

 // Check argument

 if(type==0) Error(1); 
 for(i=0; i<NbTypes; i++) if(type == TypeList[i]) Error(2);

 // Save list address 
 
 CTx** oldlist = TypeList;
 
 // Create new list 

 TypeList = new CTx*[NbTypes+1];
 if(TypeList==0) Error(3);

 // Duplicate old pointers in new list

 for (i=0; i<NbTypes; i++) TypeList[i]=oldlist[i];
  
 // Add the new pointer to the list  

 TypeList[NbTypes++] = type;

 // Free old list memory

 delete oldlist;

}
//////////////////////////////////////////////////////////////////////

void CAlgo::Error(int err)
{
 CLog log;
 std::ofstream& slog = log.GetStream();
 
 slog << "\n\n";
 slog << "=====================================\n";
 slog << "=====================================\n";
 slog << "=============   ERROR   =============\n";
 slog << "=====================================\n";
 slog << "=====================================\n";

 slog << "\nAlgo : \n----\n\n ";

 switch (err)
 {
  case 1:   slog << "AddTypeError : null type";             break;
  case 2:   slog << "AddTypeError : type already exist";    break;
  case 3:   slog << "AddTypetError : null TypeList";        break;
  default : slog << "UnknownError";
 }

 throw std::runtime_error("");
}
