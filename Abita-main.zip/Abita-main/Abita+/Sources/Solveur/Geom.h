// Geom.h: interface for the CGeom class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GEOM_H__3F89D120_819F_43BD_A4FD_A3610079FEAF__INCLUDED_)
#define AFX_GEOM_H__3F89D120_819F_43BD_A4FD_A3610079FEAF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Pt.h"
#include "Element.h"
#include "Segment.h"
#include "Floor.h"

class CGeom  
{
public:
	CSegment ** SegmentList;
	int NbSegments;

	void Build();

 void AddPoint  (CPt      * const pt);
 void AddElement(CElement * const elt);
 void AddFloor  (CFloor   * const floor);

 int NbPoints;
 int NbElements;
 int NbFloors;

 CPt**      PointList;
 CElement** ElementList;
 CFloor**   FloorList;


 CGeom();
 virtual ~CGeom();

private:
	CSegment *AddSegment(CSegment *const seg);

	void Error(int err, const char * msg="", int id=0);

};

#endif // !defined(AFX_GEOM_H__3F89D120_819F_43BD_A4FD_A3610079FEAF__INCLUDED_)
