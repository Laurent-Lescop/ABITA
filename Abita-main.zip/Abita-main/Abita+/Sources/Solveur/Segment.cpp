// Segment.cpp: implementation of the CSegment class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "math.h"
#include "Pt.h"
#include "Segment.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSegment::CSegment(CPt * const p1, CPt * const p2) : P1(p1), P2(p2), FloorId(p1->FloorId)
{
 Mark = false;
 E1   = 0;
 E2   = 0;
 Length = float(sqrt( (P2->X - P1->X)*(P2->X - P1->X) + 
                      (P2->Y - P1->Y)*(P2->Y - P1->Y) ));
}

CSegment::~CSegment()
{

}

//////////////////////////////////////////////////////////////////////

bool CSegment::operator ==(const CSegment &seg) const
{
 return (seg.P1==P1 && seg.P2==P2) || (seg.P1==P2 && seg.P2==P1);
}

//////////////////////////////////////////////////////////////////////

bool CSegment::SetElement(CElement * const elt)
{
 if(E1 == 0)      E1 = elt;
 else if(E2 == 0) E2 = elt;
 else return E1==elt || E2==elt;
 return true;
}

//////////////////////////////////////////////////////////////////////
