// ABITA_SOLVEUR.cpp : Defines the entry point for the console application.
//

#include <string.h>
#include <stdio.h>
#include "AbiFile.h"
#include "Algo.h"
#include "Log.h"

int main(int argc, char* argv[])
{
 char fileName1[1000];
 char fileName2[1000];
 char buf[40];

 CLog logfile("Abita.log");
 ofstream slog = logfile.GetStream();

 CGeom geom;
 CPopulation popu;
 CAlgo algo(&geom, &popu);

 slog << "\n=====================================";
 slog << "\n=                                   =";
 slog << "\n=            ABITA  v1.0            =";
 slog << "\n=                                   =";
 slog << "\n=           www.mfrdc.com           =";
 slog << "\n=                                   =";
 slog << "\n=====================================";

 if(argc==1)
 {
  printf("\n=====================================");
  printf("\n=                                   =");
  printf("\n=            ABITA  v1.0            =");
  printf("\n=                                   =");
  printf("\n=           www.mfrdc.com           =");
  printf("\n=                                   =");
  printf("\n=====================================");
 }

 switch (argc)
 {
  case 1:
   do
   {
    printf("\n\nEntrez le nom du fichier entr\202e : ");
    gets(fileName1);
   }
   while(strlen(fileName1)==0);
   printf("Entrez le nom du fichier sortie : ");
   gets(fileName2);
   if(strlen(fileName2)==0) strcpy(fileName2,fileName1);
   break;
  case 2:
   strcpy(fileName1,argv[1]);
   strcpy(fileName2,argv[1]);
   break;
  case 3:
   strcpy(fileName1,argv[1]);
   strcpy(fileName2,argv[2]);
   break;
  default:
   printf("\n\nTrop de param�tres");
   slog << "\n\nTrop de param�tres";
   exit(1);
 }


 if(argc==1)
 {
  printf("\n\nFichier entr\202e : %s",fileName1);
  printf("\nFichier sortie : %s",fileName2);
 }
 slog << "\n\nFichier entr�e : " << fileName1;
 slog << "\nFichier sortie : "<< fileName2;

 CAbiFile file(fileName1);
 file.Read(geom, popu, algo);

 if(argc==1)
 {
  printf("\n\n");
  printf("\n            statistiques\n");
  printf("\n-------------------------------------");
  printf("\n iter   minimun    moyenne    maximum");
  printf("\n-------------------------------------\n");
 }
 slog << "\n\n";
 slog << "\n            statistiques\n";
 slog << "\n-------------------------------------";
 slog << "\n iter   minimun    moyenne    maximum";
 slog << "\n-------------------------------------\n";

 while(algo.Run())
 {
  if((algo.CurrentIteration()<algo.InitIT && algo.CurrentIteration()%1000==0) ||
      algo.CurrentIteration()>=algo.InitIT)
  {
   sprintf(buf,"%5d %8.2f %10.2f %10.2f\n",algo.CurrentIteration(),popu.MinFitness,
                                                                   popu.AveFitness,
                                                                   popu.MaxFitness);
   if(argc==1) printf(buf);
   slog << buf;
  }
 };

 if(argc==1) printf("-------------------------------------\n\n");
 slog << "-------------------------------------\n\n";

 CAbiFile file2(fileName2);
 file2.Write(geom, popu, algo);

	return 0;
}

