// Geom.cpp: implementation of the CGeom class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <stdio.h>
#include "Geom.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGeom::CGeom()
{
 PointList   = 0;
 ElementList = 0;
 SegmentList = 0;
 FloorList   = 0;
 NbPoints    = 0;
 NbElements  = 0;
 NbSegments  = 0;
 NbFloors    = 0;
}

CGeom::~CGeom()
{
 int i;
 for (i=0; i<NbPoints;   i++) delete PointList[i];
 for (i=0; i<NbElements; i++) delete ElementList[i];
 for (i=0; i<NbSegments; i++) delete SegmentList[i];
 for (i=0; i<NbFloors;   i++) delete FloorList[i];
 delete PointList;
 delete ElementList;
 delete SegmentList;
 delete FloorList;
}

//////////////////////////////////////////////////////////////////////

void CGeom::AddPoint(CPt* const pt)
{
 int i;

 // Check argument

 if(pt==0) Error(1); 
 for(i=0; i<NbPoints; i++) if(pt == PointList[i]) Error(2);

 // Save list address 
 
 CPt** oldlist = PointList;
 
 // Create new list 

 PointList = new CPt*[NbPoints+1];
 if(PointList==0) Error(3);

 // Duplicate old pointers in new list

 for (i=0; i<NbPoints; i++) PointList[i]=oldlist[i];
  
 // Add the new pointer to the list  

 PointList[NbPoints++] = pt;

 // Free old list memory

 delete oldlist;
}


//////////////////////////////////////////////////////////////////////

void CGeom::AddElement(CElement* const elt)
{
 int i;

 // Check argument

 if(elt==0) Error(4); 
 for(i=0; i<NbElements; i++) if(elt == ElementList[i]) Error(5,"",elt->No);

 // Save list address 
 
 CElement** oldlist = ElementList;
 
 // Create new list 

 ElementList = new CElement*[NbElements+1];
 if(ElementList==0) Error(6);

 // Duplicate old pointers in new list

 for(i=0; i<NbElements; i++) ElementList[i]=oldlist[i];
  
 // Add the new pointer to the list  

 ElementList[NbElements] = elt;

 // Update index for distribution ordering

 elt->Index = NbElements++;

 // Free old list memory

 delete oldlist;
}

//////////////////////////////////////////////////////////////////////

void CGeom::AddFloor(CFloor* const floor)
{
 int i;

 // Check argument

 if(floor==0) Error(14); 
 for(i=0; i<NbFloors; i++) if(floor == FloorList[i]) Error(15,"",floor->No);

 // Save list address 
 
 CFloor** oldlist = FloorList;
 
 // Create new list 

 FloorList = new CFloor*[NbFloors+1];
 if(FloorList==0) Error(16);

 // Duplicate old pointers in new list

 for(i=0; i<NbFloors; i++) FloorList[i]=oldlist[i];
  
 // Add the new pointer to the list  

 FloorList[NbFloors++] = floor;

 // Free old list memory

 delete oldlist;
}

//////////////////////////////////////////////////////////////////////

CSegment *CGeom::AddSegment(CSegment *const seg)
{
 int i;

 // Check argument
 //  if already in return seg for delete

 if(seg==0) Error(17); 
 for(i=0; i<NbSegments; i++) if((*seg) == (*(SegmentList[i]))) return seg;

 // Save list address 
 
 CSegment** oldlist = SegmentList;
 
 // Create new list 

 SegmentList = new CSegment*[NbSegments+1];
 if(SegmentList==0) Error(18);

 // Duplicate old pointers in new list

 for(i=0; i<NbSegments; i++) SegmentList[i]=oldlist[i];
  
 // Add the new pointer to the list  

 SegmentList[NbSegments++] = seg;

 // Free old list memory

 delete oldlist;

 // Segement added => nothing to delete i.e. return 0

 return 0;
}

//////////////////////////////////////////////////////////////////////

void CGeom::Build()
{
 int i,j,k;
 CElement *elt;
 CSegment *seg;
 CPt *p1;
 CPt *p2;

 // Close elements
 // --------------

 for (i=0; i<NbElements; i++) ElementList[i]->Close();


 // Generate segments list
 // ----------------------

 for (i=0; i<NbElements; i++)
 {
  elt = ElementList[i];
  for (j=0; j<elt->NbPoints-1; j++)
  {
   seg = new CSegment(elt->PointList[j], elt->PointList[j+1]);
   delete AddSegment(seg);   
  }
 }


 // Brut force connectivity finding
 // -------------------------------

 for (i=0; i<NbElements; i++)
 {
  elt = ElementList[i];
  for (j=0; j<elt->NbPoints-1; j++)
  {
   p1 = elt->PointList[j];
   p2 = elt->PointList[j+1];
   for(k=0; k<NbSegments; k++)
   {
    seg = SegmentList[k];
    if((p1==seg->P1 && p2==seg->P2) || (p2==seg->P1 && p1==seg->P2))
    {
     seg->SetElement(elt);
     elt->SegmentList[elt->NbSegments++]=seg;
     break;
    }
   }
  }
 }
   
 // Sort elements by floor
 // ----------------------

 for (i=0; i<NbElements; i++) 
 for (j=0; j<NbFloors; j++) 
  if(ElementList[i]->FloorId==j) 
    FloorList[j]->AddElement(ElementList[i]); 


 // Debug printings
 // ---------------
  
/*
  printf("\n\n");
  printf("CGeom::Build");
  printf("\n\n");
  printf("NbPoints   = %d\n",NbPoints);
  printf("NbFloors   = %d\n",NbFloors);
  printf("NbElements = %d\n",NbElements);
  printf("NbSegments = %d\n",NbSegments);
  printf("\n");
  printf("  Seg   P1   P2   E1   E2  Ex1  Ex2 \n" );
  printf("\n");
  for(i=0; i<NbSegments; i++)
  {
   seg = SegmentList[i];
   printf(" %4d %4d %4d %4d %4d\n",i,
          seg->P1->No,seg->P2->No, seg->E1==0 ? -1 : seg->E1->No,
          seg->E2==0 ? -1 : seg->E2->No);
  }
*/

}

//////////////////////////////////////////////////////////////////////

void CGeom::Error(int err, const char * msg, int id)
{
 CLog log;
 std::ofstream& slog = log.GetStream();

 slog << "\n\n";
 slog << "=====================================\n";
 slog << "=====================================\n";
 slog << "=============   ERROR   =============\n";
 slog << "=====================================\n";
 slog << "=====================================\n";

 slog << "\nGeom : \n----\n\n ";

 switch (err)
 {
  case 1:   slog << "AddPointError : null pt";                               break;
  case 2:   slog << "AddPointError : pt already exist";                      break;
  case 3:   slog << "AddPointError : null PointList";                        break;
  case 4:   slog << "AddElementError : null elt";                            break;
  case 5:   slog << "AddElementError : elt E" << id << " already defined";   break;
  case 6:   slog << "AddElementError : null ElementList";                    break;
  case 14:  slog << "AddFloorError : null floor";                            break;
  case 15:  slog << "AddFloorError : floor F" << id << " already defined";   break;
  case 16:  slog << "AddFloorError : null FloorList";                        break;
  case 17:  slog << "AddSegmentError : null seg";                            break;
  case 18:  slog << "AddSegmentError : null SegmentList";                    break;
  default : slog << "UnknownError";
 }

 throw std::runtime_error("");
}

