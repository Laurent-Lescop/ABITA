// AbiFile.h: interface for the CAbiFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ABIFILE_H__61C6000C_1685_4D39_9DE0_7115BDB81B23__INCLUDED_)
#define AFX_ABIFILE_H__61C6000C_1685_4D39_9DE0_7115BDB81B23__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Algo.h"
#include "Log.h"

class CAbiFile  
{
public:
	void Write(CGeom &geom, CPopulation &popu, CAlgo &algo);
	void Read(CGeom &geom, CPopulation &popu, CAlgo &algo);
	CAbiFile(const char * filename);
	virtual ~CAbiFile();

private:
 void  Error(int err, const char *msg="", int id=0);
	char* FileName;

};

#endif // !defined(AFX_ABIFILE_H__61C6000C_1685_4D39_9DE0_7115BDB81B23__INCLUDED_)
