// Zg.h: interface for the CZg class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ZG_H__02707269_0DB9_4232_9471_806B6A779A1B__INCLUDED_)
#define AFX_ZG_H__02707269_0DB9_4232_9471_806B6A779A1B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CZg  
{
public:
 void  SetSize   (const float &xmin, const float &xmax, const float &ymin, const float &ymax);
 float SetZoom   (const float &zoom);
 void  AutoScale (int w, int h);
 const float &GetZoom() const { return Zoom;  }

 float X(const float &u, const float &v) const { return A*u + B*v + C; }
 float Y(const float &u, const float &v) const { return B*u - A*v - D; }
 int   U(const float &x, const float &y) const { return int(Ar*x + Br*y + Cr); }
 int   V(const float &x, const float &y) const { return int(Br*x - Ar*y - Dr); }

 CZg();
 virtual ~CZg();

private:

 void SetTransfo(float x0, float y0, float x1, float y1, float scale=1);

 float A, B, C, D;
 float Ar,Br,Cr,Dr;
 float Scale, Zoom;
 float Xmin, Xmax;
 float Ymin, Ymax;
};

#endif // !defined(AFX_ZG_H__02707269_0DB9_4232_9471_806B6A779A1B__INCLUDED_)
