// PlanDrawer.h: interface for the CPlanDrawer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PLANDRAWER_H__34A6C686_F0E4_40E2_9ABF_763618F81B75__INCLUDED_)
#define AFX_PLANDRAWER_H__34A6C686_F0E4_40E2_9ABF_763618F81B75__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Zg.h"
#include "Geom.h"
#include "Lot.h"
#include "Population.h"

class CPlanDrawer : public CZg  
{
public:
	void DrawBackGround(LPCRECT lpRect,CDC *pDC);
	void DrawElement(CElement *elt, bool highlight, CDC *pDC);
	void DrawLot(int floorID, CLot *lot, bool highlight, CDC *pDC);
	void SetSize(CGeom *geom);
	CPlanDrawer();
	virtual ~CPlanDrawer();
};

#endif // !defined(AFX_PLANDRAWER_H__34A6C686_F0E4_40E2_9ABF_763618F81B75__INCLUDED_)
