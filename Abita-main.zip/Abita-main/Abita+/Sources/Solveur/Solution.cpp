// Solution.cpp: implementation of the CSolution class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <stdio.h>
#include "Solution.h"
#include "Geom.h"
#include "Lot.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSolution::CSolution()
{
 Mark = false;
 NbLots       = 0;
 LotList      = 0;
 NbElements   = 0;
 ElementList  = 0;
 Fitness      = 0;
 Distribution = 0;
}

CSolution::CSolution(const CGeom * const geom)
{
 Mark = false;
 NbLots       = 0;
 LotList      = 0;
 NbElements   = 0;
 ElementList  = 0;
 Fitness      = 0;
 Distribution = 0;
 Init(geom);
}

CSolution::CSolution(const CSolution * const sol)
{
 Mark = false;
 NbLots      = 0;
 LotList     = 0;
 NbElements  = sol->NbElements;
 ElementList = sol->ElementList;
 Distribution = new int[NbElements];
 if(Distribution==0) Error(6);
 for(int i=0; i<NbElements; i++) Distribution[i] = sol->Distribution[i];
 SetLots();
}

CSolution::~CSolution()
{
 for(int i=0; i<NbLots; i++) delete LotList[i];
 delete LotList;
 delete Distribution;
}

//////////////////////////////////////////////////////////////////////

void CSolution::SetLots()
{
 int i,j;

 if(NbElements==0) return;

 // Clean the current lot list
 // --------------------------

 for(i=0; i<NbLots; i++) delete LotList[i];
 delete LotList;
 LotList = 0;

 // Count the lots
 // --------------

 NbLots=-1;
 for(i=0; i<NbElements; i++) 
  if(Distribution[i]>NbLots) NbLots=Distribution[i];
 if(++NbLots == 0) return;


 // Create new LotList
 // ------------------

 LotList = new CLot*[NbLots];
 if(LotList==0) Error(1);

 for(i=0; i<NbLots; i++)  
 {
  LotList[i] = new CLot(this, i);
  if(LotList[i]==0) Error(2);
 }

 // Build each lot from the distribution
 // ------------------------------------

 // set element list

 for(j=0; j<NbElements; j++) 
  if(Distribution[j]>-1) LotList[Distribution[j]]->AddElement(ElementList[j]); 
  
 // build borders

 for(i=0; i<NbLots; i++) LotList[i]->BuildBorder();  

}

//////////////////////////////////////////////////////////////////////

bool CSolution::operator ==(const CSolution &sol) const
{
 if(NbLots != sol.NbLots || NbElements != sol.NbElements ||
    ElementList != sol.ElementList) return false;

 for(int i=0; i<NbElements; i++) 
  if(Distribution[i]!=sol.Distribution[i]) return false;

 return true;
}

//////////////////////////////////////////////////////////////////////

void CSolution::SortLots()
{
 int i,j,k;

 if(NbLots<2) return;
 
 // Save list address 
 
 CLot** oldList = LotList;
 
 // Create new list 

 LotList = new CLot*[NbLots];
 if(LotList==0) Error(4);

 // Sort following the Distribution order

 LotList[0]=oldList[0]; 
 for(k=1; k<NbLots; k++) LotList[k]=0;

 for(i=0, j=1; i<NbElements && j<NbLots; i++)
 {
  for(k=0; k<j; k++) if(oldList[Distribution[i]]==LotList[k]) break;
  if(k==j) LotList[j++]=oldList[Distribution[i]]; 
 }

 // Rebuild the distribution

 for(i=0; i<NbLots; i++) 
 {
  LotList[i]->Index = i;
  for(j=0; j<LotList[i]->NbElements; j++) 
   Distribution[LotList[i]->ElementList[j]->Index]=i;
 }

 // Free old list memory

 delete oldList;
}

//////////////////////////////////////////////////////////////////////

void CSolution::RndSet(int nbSeeds)
{
 int i,j,k,l,imax,nelt,nb;
 CElement *next;
 CElement *elt;
 CSegment *seg;

 if(NbElements==0) return;
/*
 // Temporarily build lot 0
 CElement **eltList = new CElement*[maxLots];
 CLot     *lot = new CLot(this,0);
 for(i=0; i<NbElements; i++)
  if(ElementList[i]->Common) lot->AddElement(ElementList[i]); 
 lot->BuildBorder();
 for(i=0; i<NbElements; i++) ElementList[i]->Mark=false;
 for(i=j=0; i<lot->NbSegments; i++)
 {
  seg = lot->SegmentList[i];
  elt = lot->Contain(seg->E1) ? seg->E2 : seg->E1;
  if(elt!=0) if(!elt->Mark) { eltList[j++]=elt; elt->Mark=true; }
 }

 // Seed the domain

 int d[30];
for(i=0;i<NbElements; i++) d[i]=Distribution[i];

 nb = 0;
 while(nb<nbSeeds)
 {
  i = int((maxLots+1) * float(rand()) / RAND_MAX);
  i = i>maxLots ? maxLots : i;
  k=-1;
  while(k<i)
  {
   for(j=0; j<maxLots && k<i; j++) if(Distribution[j]<0) { k++; break; }
  }
  Distribution[j] = ++nb;
 }
 delete lot;
 delete eltList;
*/

 // Maximum fill of the outbuildings 
 
 for(i=nelt=0; i<NbElements; i++)
 {
  if(ElementList[i]->Common && Distribution[i]<0) { Distribution[i]=0; nelt++; }
 }

 // Seed the domain : NOT OPTIMAL YET

 nb = 0;
 while(nb<nbSeeds)
 {
  imax = NbElements - nelt - 1;
  i = int((imax+1) * float(rand()) / RAND_MAX);
  i = i>imax ? imax : i;
  k=-1;
  while(k<i)
  {
   for(j=0; j<NbElements; j++)
   {
    if(Distribution[j]<0) 
    {
     elt = ElementList[j];
     for(l=0; l<elt->NbSegments; l++)
     {
      seg = elt->SegmentList[l];
      next=seg->NextOf(elt);
      if(next != 0 ) if(Distribution[next->Index]==0) { k++; break; }
     }
    }
    if(k==i) break;
   }
  }
  nb++;
  nelt++;
  Distribution[j] = nb;
 }

 // Build the lots

 SetLots();

 // Diffusion filling (not for lot 0)

 do
 {
  for(i=1, nb=0; i<NbLots; i++) if(LotList[i]->Diffuse()) nb++;
 }
 while(nb>0);

 // Complete empty zones if ever

 do
 {
  for(i=0, nb=0; i<NbElements; i++) 
   if(Distribution[i]<0) 
   {
    nb++;
    Distribution[i]=NbLots;
    SetLots();
    while(LotList[NbLots-1]->Diffuse()) {};
   }
 }
 while(nb>0);
 
}

//////////////////////////////////////////////////////////////////////

bool CSolution::Swap(int lotID, int segID)
{
 int i,j,nlot;
 CLot *lot;
 CSegment *seg;
 CElement *elt;
 CElement *next;
 
 if(NbLots<2) return false;

 // check the lot ID

 if(lotID>NbLots-1 || lotID<0) return false;
 lot = LotList[lotID];

 // check the seg ID
 
 if(segID>lot->NbSegments-1 || segID<0) return false;
 seg = lot->SegmentList[segID];

 // check if neighbour element exist and not imposed
  
 elt = lot->Contain(seg->E1) ? seg->E2 : seg->E1;
 if(elt==0 || elt->Imposed) return false;
 
 // check neighbour lot

 nlot = Distribution[elt->Index];

 if(lotID==0 && !elt->Common) return false;
 if(LotList[nlot]->NbElements<2) return false;

 // check if neighbour lot remains connex
 
 if(nlot>0) if(!LotList[nlot]->StillConnex(elt)) return false; 

 // check if neighbour lot remains connected

 if(lotID>0)
 {
  for(j=0; j<elt->NbSegments; j++)
  {
   seg  = elt->SegmentList[j];
   next = seg->NextOf(elt);
   i    = next==0 ? -1 : Distribution[next->Index];
   if(i>-1 && i!=lotID) if(!LotList[i]->StillConnected(elt)) break;
  }
  if(j<elt->NbSegments) return false;
 }
  
 // remove elt from neighbour

 LotList[nlot]->RemoveElement(elt);

 // add element to the lot

 lot->MergeElement(elt);

 return true;

}

//////////////////////////////////////////////////////////////////////

void CSolution::Error(int err, int id)
{
 CLog log;
 std::ofstream& slog = log.GetStream();

 slog << "\n\n";
 slog << "=====================================\n";
 slog << "=====================================\n";
 slog << "=============   ERROR   =============\n";
 slog << "=====================================\n";
 slog << "=====================================\n";

 slog << "\nSolution : \n-------\n\n ";

 switch (err)
 {
  case 1: slog << "SetLotsError : null LotList";     break;
  case 2: slog << "SetLotsError : null Lot";         break;
  case 3: slog << "SetLotsError : wrong lotId";      break;
  case 4: slog << "SortLotsError : null LotList";    break;
  case 5: slog << "InitError : already initialized"; break;
  case 6: slog << "InitError : null Distribution";   break;
  default : slog << "UnknownError";
 }

 throw std::runtime_error("");
}

//////////////////////////////////////////////////////////////////////

void CSolution::Init(const CGeom * const geom)
{
 if(NbElements>0) Error(5);
 NbElements   = geom->NbElements;
 ElementList  = geom->ElementList;
 Distribution = new int[NbElements];
 if(Distribution==0) Error(6);
 for(int i=0; i<NbElements; i++) Distribution[i]=-1;
}

//////////////////////////////////////////////////////////////////////
