// VisuCase.cpp: implementation of the CVisuCase class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "../visualiseur/visualiseur.h"
#include "VisuCase.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CVisuCase::CVisuCase()
{
 Solution = 0;
 Floor    = 0;
 Lot      = 0;
 Element  = 0; 
 hItem    = 0; 
 NbCase   = 0;
 CurrentSolution = -100;
 CurrentFloor    = -100;
 CurrentLot      = -100;
 CurrentElement  = -100; 
}

CVisuCase::~CVisuCase()
{
 delete Solution;
 delete Floor;
 delete Lot;
 delete Element;
 delete hItem;
}

//////////////////////////////////////////////////////////////////////

void CVisuCase::AddCase(HTREEITEM hitem, int solution, int floor, int lot, int element)
{
 // Save lists address 
 
 int* oldSolution = Solution;
 int* oldFloor    = Floor;
 int* oldLot      = Lot;
 int* oldElement  = Element;
 HTREEITEM * oldhItem  = hItem;
 
 // Create new lists 

 Solution = new int[NbCase+1];
 Floor    = new int[NbCase+1];
 Lot      = new int[NbCase+1];
 Element  = new int[NbCase+1];
 hItem    = new HTREEITEM[NbCase+1];

 // Duplicate old values in new lists

 for (int i=0; i<NbCase; i++) 
 {
  Solution[i] = oldSolution[i];
  Floor[i]    = oldFloor[i];
  Lot[i]      = oldLot[i];
  Element[i]  = oldElement[i];
  hItem[i]    = oldhItem[i];
 }
  
 // Add the new values to the lists  

 Solution[NbCase] = solution;
 Floor   [NbCase] = floor;
 Lot     [NbCase] = lot;
 Element [NbCase] = element;
 hItem   [NbCase] = hitem;
 NbCase++;

 // Free old lists memory

 delete oldSolution;
 delete oldFloor;
 delete oldLot;
 delete oldElement;
 delete oldhItem;

}

//////////////////////////////////////////////////////////////////////

void CVisuCase::SetCase(HTREEITEM hitem)
{
 for(int i=0; i<NbCase; i++) if(hitem==hItem[i]) break;

 if(i==NbCase) 
 { 
  CurrentSolution = -100;
  CurrentFloor    = -100;
  CurrentLot      = -100;
  CurrentElement  = -100; 
 }
 else 
 { 
  CurrentSolution = Solution[i];
  CurrentFloor    = Floor[i];
  CurrentLot      = Lot[i];
  CurrentElement  = Element[i]; 
 }

}

//////////////////////////////////////////////////////////////////////

void CVisuCase::ClearAll()
{
 NbCase          =    0;
 CurrentSolution = -100;
 CurrentFloor    = -100;
 CurrentLot      = -100;
 CurrentElement  = -100; 
}
