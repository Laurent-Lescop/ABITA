// Element.cpp: implementation of the CElement class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <stdio.h>
#include "Element.h"
#include "Segment.h"
#include "Pt.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CElement::CElement(int floorId, int no) : FloorId(floorId), No(no)
{
 PointList   = 0;
 SegmentList = 0;
 Area        = 0.0;
 Bonus       = 0.0;
 Common      = false;
 Exit        = false;
 Imposed     = false;
 NbPoints    = 0;
 NbSegments  = 0;
 Index       =-1;
}

CElement::~CElement()
{
 delete SegmentList;
 delete PointList;
}

//////////////////////////////////////////////////////////////////////

void CElement::AddPoint(CPt *const pt)
{
 // Check argument

 if(pt==0) Error(1); 

 // Save list address 
 
 CPt** oldlist = PointList;
 
 // Create new list 

 PointList = new CPt*[NbPoints+1];
 if(PointList==0) Error(2); 

 // Duplicate old pointers in new list

 for (int i=0; i<NbPoints; i++) PointList[i]=oldlist[i];
  
 // Add the new pointer to the list  

 PointList[NbPoints++] = pt;

 // Free old list memory

 delete oldlist;
}

//////////////////////////////////////////////////////////////////////

void CElement::Close()
{ 
 // Check the number of points

 if(NbPoints<2) Error(6);

 // Add the first point in last position

 AddPoint(PointList[0]);

 // Compute area

 float x1, y1;
 float x2 = PointList[0]->X;
 float y2 = PointList[0]->Y;
 Area = 0.0;
 for(int i=1; i<NbPoints; i++)
 {
  x1 = x2;
  y1 = y2;
  x2 = PointList[i]->X;
  y2 = PointList[i]->Y;
  Area += x2*y1-x1*y2;
 }
 Area *= 0.5;
 if(Area<0.0) Area=-Area;
 if(Area==0.0) Error(7);

 // Generate empty segment list

 SegmentList = new CSegment*[NbPoints-1];

}

//////////////////////////////////////////////////////////////////////

void CElement::Error(int err)
{
 CLog log;
 std::ofstream& slog = log.GetStream();

 slog << "\n\n";
 slog << "=====================================\n";
 slog << "=====================================\n";
 slog << "=============   ERROR   =============\n";
 slog << "=====================================\n";
 slog << "=====================================\n";

 slog << "\nElement No : " << No << "\n-------\n\n ";

 switch (err)
 {
  case 1: slog << "AddPointError : null pt";           break;
  case 2: slog << "AddPointError : null PointList";    break;
  case 3: slog << "CloseError : null SegmentList";     break;
  case 6: slog << "CloseError : NbPoints<2";           break;
  case 7: slog << "CloseError : Area=0";               break;
  case 8: slog << "CloseError : SetElement=false";     break;
  default : slog << "UnknownError";
 }

 throw std::runtime_error("");
}

//////////////////////////////////////////////////////////////////////
