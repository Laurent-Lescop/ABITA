// Lot.cpp: implementation of the CLot class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <stdio.h>
#include "Geom.h"
#include "Lot.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLot::CLot(CSolution * const sol, int index) : Solution(sol)
{
 Index       = index;
 SizeElts    = 10;
 SizeSegs    = 40;
 NbElements  = 0;
 NbSegments  = 0;
 ElementList = 0;
 SegmentList = 0;
 Area        = 0.0;
 Length      = 0.0;
 Common      = false;
 TypeNo      = 0;
 Fitness     = 0;
}

CLot::~CLot()
{
 delete ElementList;
 delete SegmentList;
}

//////////////////////////////////////////////////////////////////////
//
// Build a predifined valid lot. Don't build the border so that
// elements can be added in any order.
//
//////////////////////////////////////////////////////////////////////
 

void CLot::AddElement(CElement *elt)
{
 int i;

 // Check validity
 // --------------

 if(elt==0) Error(4); 
 for(i=0; i<NbElements; i++) if(elt == ElementList[i]) Error(5,elt->No);

 // Check Elementlist size
 // ----------------------
 
 if(NbElements == SizeElts || NbElements == 0)
 {
  
  // Save list address 
 
  CElement** oldlist = ElementList;
 
  // Create new list 

  ElementList = new CElement*[SizeElts+=10];
  if(ElementList==0) Error(6);

  // Duplicate old pointers in new list

  for(i=0; i<NbElements; i++) ElementList[i]=oldlist[i];
  
  // Free old list memory

  delete oldlist;
 }

 // Add the new pointer to the list  
 // -------------------------------

 ElementList[NbElements++] = elt;

 // Update the solution distribution
 // --------------------------------

 Solution->Distribution[elt->Index]=Index;
 if(elt->Exit) Common=true;

 // Update area
 // -----------

 Area += elt->Area;

}

//////////////////////////////////////////////////////////////////////

bool CLot::RemoveElement(CElement *elt)
{
 int i,j;

 for(i=0; i<NbElements; i++) 
 {
  if(ElementList[i]==elt)
  {
   // remove element
   
   for(j=i; j<NbElements-1; j++) ElementList[j]=ElementList[j+1];
   NbElements--;

   // Rebuild border list of segments

   for(j=0; j<elt->NbSegments; j++)
   {
    if(Contain(elt->SegmentList[j]->NextOf(elt)))
     AddSegment(elt->SegmentList[j]);
    else
     RemoveSegment(elt->SegmentList[j]);
   }

   // Update the solution distribution

   Solution->Distribution[elt->Index]=-1;

   // Update area

   Area -= elt->Area;

   // Exit

   return true;
  }
 }

 // Element not found in this lot

 return false;
}

//////////////////////////////////////////////////////////////////////

bool CLot::Diffuse()
{
 int i,j,lotID;
 CElement *elt;
 CElement *next;
 CSegment *seg;
 
 for(i=0; i<NbSegments; i++)
 {
  seg = SegmentList[i];

  // retreive the neighbour element
  
  elt = Contain(seg->E1) ? seg->E2 : seg->E1;

  // if the neighbour exist

  if(elt!=0)
  {
   lotID = elt->GetLot(Solution);

   // if the neighbour is free merge it
   // ---------------------------------
   
   if(lotID<0 && !elt->Imposed) 
   {
    if(MergeElement(elt)) return true;
   }

   // elseif neighbour in common test before merging
   // ----------------------------------------------

   else if(lotID==0 && !elt->Imposed)
   {
    // test if neighbour lot remains connected

    for(j=0; j<elt->NbSegments; j++)
    {
     seg   = elt->SegmentList[j];
     next  = seg->NextOf(elt);
     lotID = next==0 ? -1 : next->GetLot(Solution);
     if(lotID>-1 && lotID!=Index) 
      if(!Solution->LotList[lotID]->StillConnected(elt)) break;
    }

    if(j==elt->NbSegments)
    {
     // remove element from common lot

     Solution->LotList[0]->RemoveElement(elt);

     // add element to this lot

     if(MergeElement(elt)) return true;
    }

   }

  }

 }

 // return false if no element merged

 return false;
}

//////////////////////////////////////////////////////////////////////

void CLot::RemoveSegment(CSegment * const seg)
{
 for(int i=0; i<NbSegments;   i++) if(SegmentList[i]==seg) break;
 for(int j=i; j<NbSegments-1; j++) SegmentList[j]=SegmentList[j+1];
 if(i<NbSegments) 
 {
  NbSegments--;
  Length -= seg->Length;
 }
}

//////////////////////////////////////////////////////////////////////

void CLot::AddSegment(CSegment * const seg)
{

 // Check list size
 // ---------------

 if(NbSegments == SizeSegs || NbSegments == 0)
 {
  // Save list address 
 
  CSegment** oldlist = SegmentList;
 
  // Create new list 

  SegmentList = new CSegment*[SizeSegs+=10];
  if(SegmentList==0) Error(7);

  // Duplicate old pointers in new list

  for(int i=0; i<NbSegments; i++) SegmentList[i]=oldlist[i];
  
  // Free old list memory

  delete oldlist;
 }

 // Add the new pointer to the list  
 // -------------------------------

 SegmentList[NbSegments++] = seg;

 // Update border length
 // --------------------

 Length += seg->Length;

}

//////////////////////////////////////////////////////////////////////
//
// Merge a neighbour element to the lot and rebuild the border so that
// elements have to be added in a valid order (e.g. diffusion algo).
//
//////////////////////////////////////////////////////////////////////

bool CLot::MergeElement(CElement *elt)
{
 int i;

 // Check validity
 // --------------

 if(elt==0) return false; 
 for(i=0; i<NbElements; i++) if(elt == ElementList[i]) return false;

 // Check Elementlist size
 // ----------------------
 
 if(NbElements == SizeElts || NbElements == 0)
 {
  
  // Save list address 
 
  CElement** oldlist = ElementList;
 
  // Create new list 

  ElementList = new CElement*[SizeElts+=10];
  if(ElementList==0) Error(6);

  // Duplicate old pointers in new list

  for(i=0; i<NbElements; i++) ElementList[i]=oldlist[i];
  
  // Free old list memory

  delete oldlist;
 }

 // Add the new pointer to the list  
 // -------------------------------

 ElementList[NbElements++] = elt;

 // Rebuild border list of segments
 // -------------------------------

 for(i=0; i<elt->NbSegments; i++)
 {
  if(Contain(elt->SegmentList[i]->NextOf(elt)))
     RemoveSegment(elt->SegmentList[i]);
  else
     AddSegment(elt->SegmentList[i]);
 }

 // Update the solution distribution
 // --------------------------------

 Solution->Distribution[elt->Index]=Index;

 // Update area
 // -----------

 Area += elt->Area;

 return true;

}

//////////////////////////////////////////////////////////////////////

void CLot::BuildBorder()
{
 int i,j;
 CElement *elt;
 CSegment *seg;

 for(j=0; j<NbElements; j++)
 {
  elt = ElementList[j];
  for(i=0; i<elt->NbSegments; i++)
  {
   seg = elt->SegmentList[i];
   if(Contain(seg->NextOf(elt))) 
     RemoveSegment(seg);
   else 
     AddSegment(seg);
  }
 }

}

//////////////////////////////////////////////////////////////////////

void CLot::Error(int err, int id)
{
 std::cerr << "\n\n";
 std::cerr << "=====================================\n";
 std::cerr << "=====================================\n";
 std::cerr << "=============   ERROR   =============\n";
 std::cerr << "=====================================\n";
 std::cerr << "=====================================\n";

 std::cerr << "\nLot : \n---\n\n ";

 switch (err)
 {
  case 4:   std::cerr << "AddElementError : null elt";                   break;
  case 5:   std::cerr << "AddElementError : E" << id << "already added"; break;
  case 6:   std::cerr << "MergeElementError : null ElementList";         break;
  case 7:   std::cerr << "MergeSegmentError : null SegmentList";         break;
  default : std::cerr << "UnknownError";
 }

 throw std::runtime_error("");
}

//////////////////////////////////////////////////////////////////////
// 
// 1- In case of the common lot: return true if every element remains 
//    connected to at least one entrance.
//
// 2- In case of other lots return true if the lot keeps contact to 
//    the lot 0.
//
//////////////////////////////////////////////////////////////////////


bool CLot::StillConnected(CElement *const removed)
{
 int i, nb, lot;
 CElement *elt;
 CSegment *seg;

 // retreive the lot of the removed element

 lot = removed->GetLot(Solution);

 // elt is in lot 0
 // ===============

 if(lot == 0)
 {

  // Common lot
  // ----------

  if(Common)
  {
   // eliminate the imposed elements

   if(removed->Imposed) return false;

   // Initialiase the marks
 
   for(i=0; i<NbElements; i++) ElementList[i]->Mark = ElementList[i]->Exit;
   removed->Mark = true;

   // Diffuse the marks from entrance
 
   for(i=0; i<NbElements; i++)
    if(ElementList[i]->Exit) MarkFrom(ElementList[i]); 

   // Count the marks

   for(i=0, nb=0; i<NbElements; i++) if(ElementList[i]->Mark) nb++;

   // return true if all elements have been marked

   return nb==NbElements;
  }

  // Other lots
  // ----------

  else
  {

   for(i=0; i<NbSegments; i++)
   {
    seg = SegmentList[i];

    // retreive the neighbour element
  
    elt = Contain(seg->E1) ? seg->E2 : seg->E1;

    // if the neighbour exist check its lot

    if(elt!=0 && elt!=removed) if(elt->GetLot(Solution) == 0) return true;
   }
   return false;
  }

 }

 // elt is not in lot 0
 // ===================

 else
 {
  if(lot!=Index) return true;
  else
  {
   for(i=0; i<NbSegments; i++)
   {
    seg = SegmentList[i];

    if(removed != seg->E1 && removed != seg->E2)
    {
     // retreive the neighbour element
  
     elt = Contain(seg->E1) ? seg->E2 : seg->E1;

     // if the neighbour exist check its lot

     if(elt!=0 && elt!=removed) if(elt->GetLot(Solution) == 0) return true;
    }
   }
   return false;
  }

 }

}

//////////////////////////////////////////////////////////////////////

bool CLot::StillConnex(CElement *const removed)
{
 int i, nb, lot;
 CElement *elt;
 CSegment *seg;

 // check that the element is in this lot

 lot = removed->GetLot(Solution);
 if(lot!=Index) return false;

 // check that the element can be removed

 if(NbElements<2 || removed->Imposed) return false;


 // Initialiase the marks
 
 for(i=0; i<NbElements; i++) ElementList[i]->Mark = false;
 removed->Mark = true;

 // Get first neigbour in this lot

 for(i=0; i<removed->NbSegments; i++)
 {
  seg = removed->SegmentList[i];
  elt = seg->NextOf(removed);
  if(elt != 0) if(elt->GetLot(Solution)==Index) break;
 }

 // Diffuse the marks from first neigbour in this lot
 
 MarkFrom(elt); 

 // Count the marks

 for(i=0, nb=0; i<NbElements; i++) if(ElementList[i]->Mark) nb++;

 // return true if all elements have been marked

 return nb==NbElements;
}

//////////////////////////////////////////////////////////////////////
//
// Diffuse a mark from elt in the entire lot if possible.
// Recursive call. No diffusion from already marked elements. 
// The member variable CElement::Mark must be initialised.
// elt is marked for safety.
//
//////////////////////////////////////////////////////////////////////


void CLot::MarkFrom(CElement *const elt)
{
 CElement *next;
 elt->Mark = true;
 for(int i=0; i<elt->NbSegments; i++)
 {
  next = elt->SegmentList[i]->NextOf(elt);
  if(next!=0)
  if(next->GetLot(Solution)==Index && !next->Mark) 
  {
   next->Mark = true;
   this->MarkFrom(next);
  }
 }
}

//////////////////////////////////////////////////////////////////////

