// Tx.cpp: implementation of the CTx class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Tx.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTx::CTx()
{
 Benefit = 0.f;
 AreaMin = 0.f;
 AreaMax = 0.f;
 NbMin   = 0;
 NbMax   = 1000;
 No      = 0;
 Nb      = 0;
}

CTx::CTx(float benefit, float areaMin, float areaMax, 
                    int nbMin, int nbMax, int no)
{
 Benefit = benefit;
 AreaMin = areaMin;
 AreaMax = areaMax;
 NbMin   = nbMin;
 NbMax   = nbMax;
 No      = no;
 Nb      = 0;
}

CTx::~CTx()
{

}

//////////////////////////////////////////////////////////////////////
