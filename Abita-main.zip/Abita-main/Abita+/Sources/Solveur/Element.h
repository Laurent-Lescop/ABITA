// Element.h: interface for the CElement class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ELEMENT_H__012914F5_34B1_4996_AB54_8EE128B1FA32__INCLUDED_)
#define AFX_ELEMENT_H__012914F5_34B1_4996_AB54_8EE128B1FA32__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <iostream>
#include <stdlib.h>
#include "Solution.h"
#include "Log.h"
class CSegment;
class CPt;

class CElement  
{
public:
  float Bonus;
  int   GetLot(CSolution * sol) { return Index<0 ? -1 : sol->Distribution[Index]; }
  bool  Mark;
  const int No;
  const int FloorId;
  int   Index;
  bool  Exit;
  bool  Common;
  bool  Imposed;
  float Area;
  int   NbPoints;
  int   NbSegments;

  void  AddPoint(CPt * const pt);
  void  Close();
  
  CPt**      PointList;
  CSegment** SegmentList;
  CElement(int floorId, int no);
  virtual ~CElement();
private:
  void Error(int err);
};

#endif // !defined(AFX_ELEMENT_H__012914F5_34B1_4996_AB54_8EE128B1FA32__INCLUDED_)
