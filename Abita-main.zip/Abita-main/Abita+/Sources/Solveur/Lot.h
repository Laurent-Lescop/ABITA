// Lot.h: interface for the CLot class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LOT_H__A94DEB6B_DEE6_440A_A3F5_8A185A2418B3__INCLUDED_)
#define AFX_LOT_H__A94DEB6B_DEE6_440A_A3F5_8A185A2418B3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CSolution;
class CSegment;
#include "Element.h"

class CLot  
{
public:

	float Fitness;
	float Length;
	int   Index;
	bool  Common;
	float Area;
	int   TypeNo;

 bool  StillConnex(CElement * const removed);
	bool  StillConnected(CElement * const removed);
	bool  Diffuse();
 void  BuildBorder();

	CSolution * const Solution;

	CSegment ** SegmentList;
	CElement ** ElementList;
	int SizeElts;
	int SizeSegs;
	int NbElements;
	int NbSegments;

	bool Contain(CElement *elt) { return elt==0 ? false : Index == elt->GetLot(Solution); }

	void AddElement   (CElement *elt);
	bool MergeElement (CElement *elt);
	bool RemoveElement(CElement *elt);

	CLot(CSolution * const sol, int index);
	virtual ~CLot();

private:
	void MarkFrom      (CElement * const elt);
	void AddSegment    (CSegment * const seg);
	void RemoveSegment (CSegment * const seg);
	void Error(int err, int id=0);

};

#endif // !defined(AFX_LOT_H__A94DEB6B_DEE6_440A_A3F5_8A185A2418B3__INCLUDED_)
