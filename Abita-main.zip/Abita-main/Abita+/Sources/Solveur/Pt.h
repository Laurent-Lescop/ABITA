// Point.h: interface for the CPoint class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PT_H__EE81525A_64E9_427C_B555_58746564ED20__INCLUDED_)
#define AFX_PT_H__EE81525A_64E9_427C_B555_58746564ED20__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CPt  
{
public:
	const int   No;
	const int   FloorId;
	const float X;
	const float Y;
	CPt(float x, float y, int floor, int no);
	virtual ~CPt();
};

#endif // !defined(AFX_POINT_H__EE81525A_64E9_427C_B555_58746564ED20__INCLUDED_)
