// Floor.h: interface for the CFloor class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FLOOR_H__25A371F9_45EA_49C1_9A36_075FD073FA4B__INCLUDED_)
#define AFX_FLOOR_H__25A371F9_45EA_49C1_9A36_075FD073FA4B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Element.h"

class CFloor  
{
 public:
	 void AddElement(CElement * const elt);

	 const int No;
	 CFloor(int no);
	 virtual ~CFloor();

  CElement** ElementList;
  int NbElements;

private:

	void Error(int err, const char * msg="", int id=0);

};

#endif // !defined(AFX_FLOOR_H__25A371F9_45EA_49C1_9A36_075FD073FA4B__INCLUDED_)
