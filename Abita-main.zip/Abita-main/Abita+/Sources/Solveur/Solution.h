// Solution.h: interface for the CSolution class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SOLUTION_H__706A774C_0492_42C3_80F1_D8561786F2FE__INCLUDED_)
#define AFX_SOLUTION_H__706A774C_0492_42C3_80F1_D8561786F2FE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CLot;
class CElement;
class CGeom;

class CSolution  
{
public:
	bool Mark;
	void Init(const CGeom * const geom);
	bool Swap(int lotID, int segID);
	void SortLots();
	void RndSet(int nbSeeds);
	void SetLots();

	CLot ** LotList;
 CElement ** ElementList;
 int *Distribution;

	int   NbLots;
	float Fitness;
	int   NbElements;

	CSolution(const CSolution * const sol);
	CSolution(const CGeom * const geom);
	CSolution();
	virtual ~CSolution();
 bool operator == (const CSolution &sol) const;

private:
	void Error(int err, int id=0);
};

#endif // !defined(AFX_SOLUTION_H__706A774C_0492_42C3_80F1_D8561786F2FE__INCLUDED_)
