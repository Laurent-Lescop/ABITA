// PlanDrawer.cpp: implementation of the CPlanDrawer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PlanDrawer.h"
#include "../visualiseur/visualiseur.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPlanDrawer::CPlanDrawer()
{

}

CPlanDrawer::~CPlanDrawer()
{

}

//////////////////////////////////////////////////////////////////////

void CPlanDrawer::SetSize(CGeom *geom)
{
 float x, xmin, xmax;
 float y, ymin, ymax;

 // on initialise la recherche des valeurs MIN et MAX

 if(geom->NbPoints==0) return;
 
 xmin=xmax=geom->PointList[0]->X;
 ymin=ymax=geom->PointList[0]->X;
 
 // on recherche les valeurs MIN et MAX

 for(int i=0; i<geom->NbPoints; i++) 
 {
  x=geom->PointList[i]->X;
  y=geom->PointList[i]->Y;
  if(x<xmin) xmin=x;
  if(y<ymin) ymin=y;
  if(x>xmax) xmax=x;
  if(y>ymax) ymax=y;
 }

 // On calcul une marge de 5%

 float mx = (xmax-xmin)*float(0.05);
 float my = (ymax-ymin)*float(0.05);

 // On installe l'espace physique � repr�senter
 
 CZg::SetSize(xmin-mx, xmax+mx, ymin-my, ymax+my);

}

//////////////////////////////////////////////////////////////////////

void CPlanDrawer::DrawElement(CElement *elt, bool highlight, CDC * pDC)
{
 CPen   pen;
 CBrush brush;

  // select the right pen
 
 if(highlight) pen.CreatePen(PS_SOLID, 1, RGB(  0,   0,   0));
 else          pen.CreatePen(PS_SOLID, 1, RGB(170, 170, 170));
 CPen* pOldPen = pDC->SelectObject(&pen);

 // select the right brush

 if(highlight) 
  if(elt->Imposed)     brush.CreateSolidBrush(RGB(140, 140, 140));
  else if(elt->Common) brush.CreateSolidBrush(RGB(255, 120, 100));
  else                 brush.CreateSolidBrush(RGB(255, 200, 100));
 else
  if(elt->Imposed)     brush.CreateSolidBrush(RGB(215, 215, 215));
  else if(elt->Common) brush.CreateSolidBrush(RGB(255, 225, 200));
  else                 brush.CreateSolidBrush(RGB(255, 235, 200));

 CBrush* pOldBrush = pDC->SelectObject(&brush);

 // Build, draw and free the polyline
 
 CPoint *poly = new CPoint[elt->NbPoints];
 for(int i=0; i<elt->NbPoints; i++)
 {
  poly[i].x = U(elt->PointList[i]->X, elt->PointList[i]->Y);
  poly[i].y = V(elt->PointList[i]->X, elt->PointList[i]->Y);
 }
 pDC->Polygon(poly, elt->NbPoints);
 delete [] poly;

 // Put back the old objects.

 pDC->SelectObject(pOldPen);
 pDC->SelectObject(pOldBrush);

}

//////////////////////////////////////////////////////////////////////

void CPlanDrawer::DrawLot(int floorId, CLot *lot, bool highlight, CDC * pDC)
{
 int i,j;
 CPen   penS;
 CPen   penD;
 CBrush brush;
 CPoint P1;
 CPoint P2;
 CPoint *poly;
 CElement *elt;
 CSegment *seg;


 // Select the right brush

 COLORREF brushColor;
 if(highlight)
  brushColor = lot->Common ? RGB(140,140,140) : RGB(100,200,255);
 else 
  brushColor = lot->Common ? RGB(215,215,215) : RGB(200,235,255);
 brush.CreateSolidBrush(brushColor);

 // Select the right pen
 
 if(highlight) penS.CreatePen(PS_SOLID, 1, RGB(  0,   0,   0));
 else          penS.CreatePen(PS_SOLID, 1, RGB(170, 170, 170));
 penD.CreatePen(PS_SOLID, 1, brushColor);

 // Save old objects

 CPen* pOldPen     = pDC->SelectObject(&penD);
 CBrush* pOldBrush = pDC->SelectObject(&brush);
 COLORREF bkColor  = pDC->SetBkColor(brushColor);

 // Draw the elements
 
 for(i=0; i<lot->NbElements; i++)
 {
  // Build, draw and free polygons with no boders

  elt = lot->ElementList[i];

  if(elt->FloorId == floorId)
  {
   poly = new CPoint[elt->NbPoints];
   for(j=0; j<elt->NbPoints; j++)
   {
    poly[j].x = U(elt->PointList[j]->X, elt->PointList[j]->Y);
    poly[j].y = V(elt->PointList[j]->X, elt->PointList[j]->Y);
   }
   pDC->Polygon(poly, elt->NbPoints);
   delete [] poly;
  }

 }

 // Draw borders

 pDC->SelectObject(&penS);

 for(i=0; i<lot->NbSegments; i++)
 {
   seg  = lot->SegmentList[i];

   if(seg->FloorId == floorId)
   {
    P1.x = U(seg->P1->X, seg->P1->Y);
    P1.y = V(seg->P1->X, seg->P1->Y);

    P2.x = U(seg->P2->X, seg->P2->Y);
    P2.y = V(seg->P2->X, seg->P2->Y);

    pDC->MoveTo(P1);
    pDC->LineTo(P2);
   }
 }

 // Put back the old objects.

 pDC->SelectObject(pOldPen);
 pDC->SelectObject(pOldBrush);
 pDC->SetBkColor(bkColor);
}

//////////////////////////////////////////////////////////////////////

void CPlanDrawer::DrawBackGround(LPCRECT lpRect, CDC *pDC)
{
 CPen   pen;
 CBrush brush;

 // select the right pen
 
 pen.CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
 CPen* pOldPen = pDC->SelectObject(&pen);

 // select the right brush

 brush.CreateSolidBrush(RGB(255, 255, 255));
 CBrush* pOldBrush = pDC->SelectObject(&brush);

 // Draw background

 pDC->Rectangle(lpRect);
 
 // Put back the old objects.

 pDC->SelectObject(pOldPen);
 pDC->SelectObject(pOldBrush);
}

//////////////////////////////////////////////////////////////////////
