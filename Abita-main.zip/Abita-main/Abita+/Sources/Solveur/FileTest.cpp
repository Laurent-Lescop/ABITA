// FileTest.cpp : Defines the entry point for the console application.
//

#include "AbiFile.h"

int main(int argc, char* argv[])
{
 CGeom geom;
 CPopulation popu;
 CAlgo algo(&geom,&popu);
 CAbiFile file("../../data/G001new.aop");
 file.Read(geom,popu,algo);
 CAbiFile file2("../../data/G001newbis.aop");
 file2.Write(geom,popu,algo);
	return 0;
}

