// Population.h: interface for the CPopulation class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_POPULATION_H__EBB20C78_1492_447E_99AB_4771FBCED010__INCLUDED_)
#define AFX_POPULATION_H__EBB20C78_1492_447E_99AB_4771FBCED010__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <iostream>
#include <stdlib.h>
#include "Solution.h"
#include "Geom.h"

class CPopulation  
{
public:
	int NbTest;
	void  Resize(int sizeMax);
	bool  InsertSolution(CSolution * const sol);
	void  RemoveSolution(int index);
	void  AddSolution(CSolution * const sol);
	void  SortSolutions();
 void  Stats();

	float MaxFitness;
	float MinFitness;
	float AveFitness;
	int   NbSolutions;

	CSolution ** SolutionList;

	CPopulation();
	virtual ~CPopulation();

private:
	int  SizeMax;
	void Error(int err, int id=0);
};

#endif // !defined(AFX_POPULATION_H__EBB20C78_1492_447E_99AB_4771FBCED010__INCLUDED_)
