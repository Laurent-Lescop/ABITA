#ifndef MG_GUIPROPRIETES
#define MG_GUIPROPRIETES

#include "precompiled.h"
#include "Application.h"
#include "textes.h"
#include "AbitaDocument.h"


// const values

//----------------------------------------------------------------------------

const wxString DEFAULT_LARGEUR = _T("30");
const wxString DEFAULT_LONGUEUR = _T("30");

const unsigned DEFAULT_CAMEMBER_SIZEX = 128;
const unsigned DEFAULT_CAMEMBER_SIZEY = 128;

//const wxString DEFAULT_NB_ETAGES = _T("1");

//----------------------------------------------------------------------------


enum ID_CONTROLS_PROPRIETES
{
  ID_PROPRIETES_OK = 10000,
  ID_PROPRIETES_QUITTER,
  ID_PROPRIETES_DEFAULT,

  ID_LONGUEUR,
  ID_NBETAGE,
  ID_LARGEUR,
  ID_ANNOTATIONS,
  ID_TYPOLOGIE
};

enum ROWS
{
  ID_TITLE_R  = 0,
  ID_T1,
  ID_T2,
  ID_T3,
  ID_T4,
  ID_T5
};

enum COLUMS
{
  ID_TITLE_C  = 0,
  ID_BENEFIT  = 1,
  ID_MIN_AREA,
  ID_MAX_AREA,
  ID_NB_MIN,
  ID_NB_MAX
};

//----------------------------------------------------------------------------

class DlgProprietes: public wxDialog
{
protected:
  wxConfig *m_config;
  wxGrid *m_grid;
  wxStaticBitmap *bmpProportions;

  wxTextCtrl *m_annotations;
  wxTextCtrl *m_tailleX;
  wxTextCtrl *m_tailleY;

  bool m_isnew;
public:
  DlgProprietes( wxWindow* parent, bool isnew,wxString title );
  ~DlgProprietes();

  void OnOk( wxCommandEvent& event );    
  void OnQuitter( wxCommandEvent& event );
  void OnDefault( wxCommandEvent& event );
  bool OnClose(void) { return TRUE; }

  void setCellBorder(unsigned y,unsigned x);
  void SetDefaultValues();
  void ReadConfigValues();

  wxBitmap SetTrans(wxBitmap in);

  DECLARE_EVENT_TABLE()
};

//----------------------------------------------------------------------------

BEGIN_EVENT_TABLE(DlgProprietes, wxDialog)
EVT_BUTTON( ID_PROPRIETES_OK,  DlgProprietes::OnOk  )
EVT_BUTTON( ID_PROPRIETES_QUITTER, DlgProprietes::OnQuitter )
EVT_BUTTON( ID_PROPRIETES_DEFAULT, DlgProprietes::OnDefault )

END_EVENT_TABLE()

//----------------------------------------------------------------------------

void DlgProprietes::SetDefaultValues()
{
  m_grid->SetCellValue( ID_T1, ID_BENEFIT, "70.0" );
  m_grid->SetCellValue( ID_T2, ID_BENEFIT, "80.0" );
  m_grid->SetCellValue( ID_T3, ID_BENEFIT, "100.0" );
  m_grid->SetCellValue( ID_T4, ID_BENEFIT, "50.0" );
  m_grid->SetCellValue( ID_T5, ID_BENEFIT, "40.0" );

  m_grid->SetCellValue( ID_T1, ID_MIN_AREA, "30.0" );
  m_grid->SetCellValue( ID_T2, ID_MIN_AREA, "45.0" );
  m_grid->SetCellValue( ID_T3, ID_MIN_AREA, "60.0" );
  m_grid->SetCellValue( ID_T4, ID_MIN_AREA, "75.0" );
  m_grid->SetCellValue( ID_T5, ID_MIN_AREA, "85.0" );

  m_grid->SetCellValue( ID_T1, ID_MAX_AREA, "45.0" );
  m_grid->SetCellValue( ID_T2, ID_MAX_AREA, "60.0" );
  m_grid->SetCellValue( ID_T3, ID_MAX_AREA, "65.0" );
  m_grid->SetCellValue( ID_T4, ID_MAX_AREA, "85.0" );
  m_grid->SetCellValue( ID_T5, ID_MAX_AREA, "100.0" );

  m_grid->SetCellValue( ID_T1, ID_NB_MIN, "0" );
  m_grid->SetCellValue( ID_T2, ID_NB_MIN, "0" );
  m_grid->SetCellValue( ID_T3, ID_NB_MIN, "0" );
  m_grid->SetCellValue( ID_T4, ID_NB_MIN, "0" );
  m_grid->SetCellValue( ID_T5, ID_NB_MIN, "0" );

  m_grid->SetCellValue( ID_T1, ID_NB_MAX, "1000" );
  m_grid->SetCellValue( ID_T2, ID_NB_MAX, "1000" );
  m_grid->SetCellValue( ID_T3, ID_NB_MAX, "1000" );
  m_grid->SetCellValue( ID_T4, ID_NB_MAX, "1000" );
  m_grid->SetCellValue( ID_T5, ID_NB_MAX, "1000" );
}

//----------------------------------------------------------------------------

void DlgProprietes::ReadConfigValues()
{
  for(unsigned x=1; x<=5; x++)
  {
    Document::TypeLogement type = Document::TypeLogement( x-1 );

    Document::InfosTypeLogement const& infos = theDocument->getInfoTypeAppartement(type);

    m_grid->SetCellValue( x, ID_BENEFIT,  wxString::Format("%.1f", infos.benefit) );
    m_grid->SetCellValue( x, ID_MIN_AREA, wxString::Format("%.1f", infos.areaMin) );
    m_grid->SetCellValue( x, ID_MAX_AREA, wxString::Format("%.1f", infos.areaMax) );
    m_grid->SetCellValue( x, ID_NB_MIN,   wxString::Format("%d", infos.numMin) );
    m_grid->SetCellValue( x, ID_NB_MAX,   wxString::Format("%d", infos.numMax) );
  }
}

//----------------------------------------------------------------------------

void DlgProprietes::setCellBorder(unsigned y,unsigned x)
{
  m_grid->SetReadOnly( y, x );
  m_grid->SetCellTextColour(y, x, *wxBLACK);
  m_grid->SetCellBackgroundColour(y, x, *wxLIGHT_GREY);
}



//----------------------------------------------------------------------------

wxBitmap DlgProprietes::SetTrans(wxBitmap in)
{
  in.SetMask(new wxMask(in,wxColour(255,255,255)));
  return in;
}

//----------------------------------------------------------------------------


DlgProprietes::DlgProprietes( wxWindow* parent, bool isnew,wxString title )  : wxDialog( parent, -1, title,wxDefaultPosition,wxDefaultSize)
{ 		
  m_config = new wxConfig("Abita+");
  m_isnew = isnew;
  // -------------

  wxBoxSizer *item0 = new wxBoxSizer( wxVERTICAL );

  wxBoxSizer *item1 = new wxBoxSizer( wxHORIZONTAL );

  wxStaticBitmap *item2 = new wxStaticBitmap(this, -1, SetTrans(wxBitmap("logo_abita_big")));  

  item1->Add( item2, 0, wxALIGN_LEFT|wxALL, 5 );

  wxStaticBox *item4 = new wxStaticBox( this, -1, RS_PROPRIETE_SURFACE_TITRE );
  //item4->SetSize(wxSize(100,-1));
  wxStaticBoxSizer *item3 = new wxStaticBoxSizer( item4, wxHORIZONTAL );

  wxGridSizer *item5 = new wxGridSizer( 3, 0, 0 );

  wxStaticText *item6 = new wxStaticText( this, -1, RS_PROPRIETE_LONGUEUR, wxDefaultPosition, wxDefaultSize, 0 );
  item5->Add( item6, 0, wxALIGN_CENTRE|wxALL, 5 );

  if(!theDocument->isEmpty() && (isnew == false))
  {
    m_tailleX = new wxTextCtrl( this, ID_LONGUEUR, wxString::Format("%.2f",theDocument->getSizeX()), wxDefaultPosition, wxSize(80,-1), wxTE_READONLY );
    m_tailleX->SetBackgroundColour(*wxLIGHT_GREY);
  }
  else
    m_tailleX = new wxTextCtrl( this, ID_LONGUEUR, wxString::Format("%.2f",theDocument->getSizeX()), wxDefaultPosition, wxSize(80,-1), 0 );
  item5->Add( m_tailleX, 0, wxALIGN_CENTRE|wxALL, 5 );

  wxStaticText *item8 = new wxStaticText( this, -1, RS_PROPRIETE_UNITE, wxDefaultPosition, wxDefaultSize, 0 );
  item5->Add( item8, 0, wxALIGN_CENTRE|wxALL, 5 );

  wxStaticText *item9 = new wxStaticText( this, -1, RS_PROPRIETE_LARGEUR, wxDefaultPosition, wxDefaultSize, 0 );
  item5->Add( item9, 0, wxALIGN_CENTRE|wxALL, 5 );

  if(!theDocument->isEmpty()&& (isnew == false))
  {
    m_tailleY = new wxTextCtrl( this, ID_LARGEUR, wxString::Format("%.2f",theDocument->getSizeY()), wxDefaultPosition, wxSize(80,-1), wxTE_READONLY );
    m_tailleY->SetBackgroundColour(*wxLIGHT_GREY);
  }
  else
    m_tailleY = new wxTextCtrl( this, ID_LARGEUR, wxString::Format("%.2f",theDocument->getSizeY()), wxDefaultPosition, wxSize(80,-1), 0 );
  item5->Add( m_tailleY, 0, wxALIGN_CENTRE|wxALL, 5 );

  wxStaticText *item11 = new wxStaticText( this, -1, RS_PROPRIETE_UNITE, wxDefaultPosition, wxDefaultSize, 0 );
  item5->Add( item11, 0, wxALIGN_CENTRE|wxALL, 5 );

  item3->Add( item5, 0, wxALIGN_CENTRE|wxALL, 5 );

  item1->Add( item3, 0, wxALIGN_CENTRE|wxALL, 5 );

  item0->Add( item1, 0, wxALIGN_LEFT|wxALL, 5 );

  // ------------------------ grid

  wxStaticText *item12 = new wxStaticText( this, -1, RS_PROPRIETE_TYPOLOGIE, wxDefaultPosition, wxDefaultSize, 0 );
  item0->Add( item12, 0, wxALIGN_LEFT|wxALL, 5 );

  wxBoxSizer *item13 = new wxBoxSizer( wxVERTICAL );


  m_grid = new wxGrid( this, ID_TYPOLOGIE, wxDefaultPosition, wxSize(500, 200), wxWANTS_CHARS );
  m_grid->CreateGrid( 6, 6, wxGrid::wxGridSelectCells );

  // Init read-only grid zones

  m_grid->SetCellValue( 0, 0, RS_PROPRIETE_TYPE );
  setCellBorder(0,0);

  m_grid->SetCellValue( ID_T1, ID_TITLE_C, RS_PROPRIETE_T1 ); setCellBorder( ID_T1, ID_TITLE_C );
  m_grid->SetCellValue( ID_T2, ID_TITLE_C, RS_PROPRIETE_T2 ); setCellBorder( ID_T2, ID_TITLE_C );
  m_grid->SetCellValue( ID_T3, ID_TITLE_C, RS_PROPRIETE_T3 ); setCellBorder( ID_T3, ID_TITLE_C );
  m_grid->SetCellValue( ID_T4, ID_TITLE_C, RS_PROPRIETE_T4 ); setCellBorder( ID_T4, ID_TITLE_C);
  m_grid->SetCellValue( ID_T5, ID_TITLE_C, RS_PROPRIETE_T5 ); setCellBorder( ID_T5, ID_TITLE_C );

  m_grid->SetCellValue( ID_TITLE_R, ID_BENEFIT,  RS_PROPRIETE_VALEURM2 ); setCellBorder( ID_TITLE_R, ID_BENEFIT );
  m_grid->SetCellValue( ID_TITLE_R, ID_MIN_AREA, RS_PROPRIETE_AIREMINI ); setCellBorder( ID_TITLE_R, ID_MIN_AREA );
  m_grid->SetCellValue( ID_TITLE_R, ID_MAX_AREA, RS_PROPRIETE_AIREMAXI ); setCellBorder( ID_TITLE_R, ID_MAX_AREA );
  m_grid->SetCellValue( ID_TITLE_R, ID_NB_MIN,   RS_PROPRIETE_QTEMINI );  setCellBorder( ID_TITLE_R, ID_NB_MIN );
  m_grid->SetCellValue( ID_TITLE_R, ID_NB_MAX,   RS_PROPRIETE_QTEMAXI );  setCellBorder( ID_TITLE_R, ID_NB_MAX );

  m_grid->SetLabelSize(wxVERTICAL, 0);
  m_grid->SetLabelSize(wxHORIZONTAL, 0);
  // set the float type zones

  m_grid->SetColFormatFloat( 1, 4, 2 );
  m_grid->SetColFormatFloat( 2, 4, 2 );
  m_grid->SetColFormatFloat( 3, 4, 2 );
  m_grid->SetColFormatNumber( 4 );
  m_grid->SetColFormatNumber( 5 );

  // set the initial values

  ReadConfigValues();

  item13->Add( m_grid, 1, wxGROW|wxALL, 5 );

  item0->Add( item13, 0, wxALIGN_CENTRE|wxALL, 5 );

  // -------------------- annotations du projet

  wxBoxSizer *item1200 = new wxBoxSizer( wxHORIZONTAL );

  wxStaticText *item1300 = new wxStaticText( this, -1, RS_PROPRIETES_ANNOTATIONS, wxDefaultPosition, wxDefaultSize, 0 );
  item1200->Add( item1300, 0, wxALIGN_CENTRE|wxALL, 5 );

  m_annotations = new wxTextCtrl( this, ID_ANNOTATIONS, theDocument->getGlobalAnnotations(), wxDefaultPosition, wxSize(450,64),wxTE_RICH | wxTE_MULTILINE );
  item1200->Add( m_annotations, 0, wxALIGN_CENTRE|wxALL, 5 );

  item0->Add( item1200, 0, wxALIGN_CENTER_VERTICAL|wxALL, 5 );

  // ---------------------

  wxBoxSizer *item16 = new wxBoxSizer( wxHORIZONTAL );

  wxButton *item17 = new wxButton( this, ID_PROPRIETES_DEFAULT, RS_DIALOG_PROPRIETE_DEFAULT, wxDefaultPosition, wxDefaultSize, 0 );
  item16->Add( item17, 0, wxALIGN_CENTRE|wxALL, 5 );

  wxButton *item18 = new wxButton( this, ID_PROPRIETES_OK, RS_DIALOG_OK, wxDefaultPosition, wxDefaultSize, 0 );
  item18->SetDefault();
  item16->Add( item18, 0, wxALIGN_CENTRE|wxALL, 5 );

  wxButton *item19 = new wxButton( this, ID_PROPRIETES_QUITTER, RS_DIALOG_ANNULER, wxDefaultPosition, wxDefaultSize, 0 );
  item16->Add( item19, 0, wxALIGN_CENTRE|wxALL, 5 );

  item0->Add( item16, 0, wxALIGN_CENTRE|wxALL, 5 );


  this->SetAutoLayout( TRUE );
  this->SetSizer( item0 );

  item0->Fit( this );
  item0->SetSizeHints( this );

  
  // ------------
  // init default preferences
  /*
  wxString str_temp;
  if(m_config)
  str_temp = m_config->Read("/GUI/showTips", "");
  if ( str_temp.IsEmpty() || (str_temp == "true") )
  m_tips->SetValue(true);
  else
  m_tips->SetValue(false);
  */

}

//----------------------------------------------------------------------------

DlgProprietes::~DlgProprietes()
{

}

//----------------------------------------------------------------------------

void DlgProprietes::OnOk( wxCommandEvent& event )
{
  if(m_isnew)
  {
    // init the document
    if(theDocument)
      delete theDocument;
    theDocument = new Document;

  }

  for (unsigned x=1; x<=5; x++)
  {
    double benefit, areaMin, areaMax;
    long nbMin, nbMax;

    m_grid->GetCellValue(x, ID_BENEFIT).ToDouble( &benefit );
    m_grid->GetCellValue(x, ID_MIN_AREA).ToDouble( &areaMin );
    m_grid->GetCellValue(x, ID_MAX_AREA).ToDouble( &areaMax );
    m_grid->GetCellValue(x, ID_NB_MIN).ToLong( &nbMin );
    m_grid->GetCellValue(x, ID_NB_MAX).ToLong( &nbMax );

    theDocument->setInfoTypeAppartement( Document::TypeLogement(x-1), 
                                         Document::InfosTypeLogement( float(benefit),
                                                                      float(areaMin), float(areaMax),
                                                                      nbMin, nbMax));
  }
  theDocument->setGlobalAnnotations(m_annotations->GetValue());

  // etages

  double dX,dY;
  m_tailleX->GetValue().ToDouble(&dX);
  m_tailleY->GetValue().ToDouble(&dY);
  if( (dX != theDocument->getSizeX()) || (dY != theDocument->getSizeY()) )
  {
    wxGetApp().m_frame->refreshCanvas();
  }
  theDocument->setSizeX((float)dX);
  theDocument->setSizeY((float)dY);

  Show( FALSE ); // TRICK:: hide it, to avoid flickered destruction
  Close(TRUE);

  SetReturnCode(wxOK);
}

//----------------------------------------------------------------------------

void DlgProprietes::OnQuitter( wxCommandEvent& event )
{

  Show( FALSE ); // TRICK:: hide it, to avoid flickered destruction
  Close(TRUE);

  SetReturnCode(wxCANCEL);

}

//----------------------------------------------------------------------------

void DlgProprietes::OnDefault( wxCommandEvent& event )
{
  SetDefaultValues();
}

//----------------------------------------------------------------------------

#endif
