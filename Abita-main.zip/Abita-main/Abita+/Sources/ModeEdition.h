#ifndef ABITA_MODE_EDITION_H
#define ABITA_MODE_EDITION_H

#include "Application.h"
#include "EditContext.h"
#include "MeshConnected.h"
#include "MeshConnected_algorithms.h"
#include "Point2d.h"
#include "wxUtilities.h"
#include "AbitaDocument.h"

//----------------------------------------------------------------------------

class ModeEdition : public InputMode
{
public:

  ModeEdition(CanvasDraw& owner) : InputMode(owner)
  {
  };

  virtual ~ModeEdition()
  {
    m_owner.SetToolTip( _T("") );
  }

  virtual void OnEvent(wxMouseEvent& event)
  {
    Document const& doc = *theDocument;

    bool const isNearUniquePolygon = theEditContext.isNearUniquePolygon();

    if (isNearUniquePolygon)
    {
      MeshConnected::PolygonHandle ph = theEditContext.getNearPolygon();
      MeshConnected::PolygonData* pdata = doc.getShape().getPolygonData(ph);

      float area, perimeter;
      computePolygonArea(doc.getShape(), ph, area, perimeter);

      wxString infos = wxString::Format(RS_VIEW_INFORMATIONS, area, perimeter);
      m_owner.SetToolTip( infos );
    }
    else
    {
      m_owner.SetToolTip( _T("") );
    }
  };
};

//----------------------------------------------------------------------------

#endif