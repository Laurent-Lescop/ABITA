#ifndef ABITA_SOLUTION_H
#define ABITA_SOLUTION_H

//----------------------------------------------------------------------------

class Solution
{
public:

  struct Lot
  {
    typedef enum
    {
      COMMON,
      T1,
      T2,
      T3,
      T4,
      T5
    }
    Type;

  public:
    Lot(Type type, std::auto_ptr<MeshConnected> shape, float area, float benefit)
    : m_type(type),
      m_shape(shape),
      m_area(area),
      m_benefit(benefit)
    {}
  
    MeshConnected const& getShape() const { return *m_shape; };
    float getArea() const { return m_area; };
    float getBenefit() const { return m_benefit; };
    Type getType() const { return m_type; };

  private:
    friend Solution;

    Lot() {};
    
    boost::shared_ptr<MeshConnected> m_shape;
    Type m_type;
    float m_area;
    float m_benefit;
  };

  unsigned numLots() const { return m_lots.size(); };
  void addLot( Lot const& lot );
  Lot const& getLot( unsigned index ) const { return m_lots[index]; };

private:

  std::vector<Lot> m_lots;
};

//----------------------------------------------------------------------------

#endif