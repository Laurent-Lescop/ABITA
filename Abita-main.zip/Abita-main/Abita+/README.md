# Abita+

<img src="../logos/logo_abita+.png" alt="Abita+" width="400px"><br><br>

This is the legacy project of Abita+, developped in C++.

## Pour compiler le solveur
* aller dans le dossier `Abita+/Sources/Solveur/` avec la commande `cd`
* exécuter la commande : `g++ -o Releases/solveur *.cpp`
* l'exécutable se trouve dans le dossier `Releases/`
* NB : l'exécutable à la racine de `Abita+` est celui qui était déjà fourni 
avec le code.

## Pour le visualiseur 
* les sources sont partielles voire manquantes a priori, aussi on ne peut 
    pas le compiler


## Licenses