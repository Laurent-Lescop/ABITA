# Abita

Abita est un programme d'architecture destiné à automatiser et optimiser la
répartition de l'espace au sein d'un logement en différents lots.

![](logos/logo_main.png)


## Installation d'Abita4Rhino

*Procédure d'installation rapide pour Rhino 7 uniquement.*

1. Téléchargez la dernière version de l'archive `Abita4Rhino.zip` sur la page
    des releases: [https://github.com/hydrielax/Abita/releases](https://github.com/hydrielax/Abita/releases)
2. Décompressez l'archive
3. Exécutez le script `install.bat` en double-cliquant dessus
4. Vous pouvez alors démarrer Rhino puis Grasshopper : les composants
    d'Abita4Rhino devraient apparaître dans la barre d'outils !

Si jamais cela ne fonctionne pas, référez-vous au manuel
d'[installation détaillée](./Abita4Rhino/README.md).


## Les différents projets

* **Abita+** : version C++ du projet Abita, développé en premier, avec :
    * un programme en ligne de commande `Solveur.exe` pour résoudre le problème ;
    * un programme `visualiseur.exe` pour visualiser de maniègre graphique les
    solutions ;
    * un programme complet `AbitaSE.exe` pour dessiner un ensemble d'éléments.
* **AbitaPy** : nouveau projet Abita développé en Python (3.7), essentiellement 
    basé sur une traduction du code du Solveur d'`Abita+`. Afin d'assurer une 
    comaptibilité avec Rhino, une version en Python 2.7 est aussi disponible
    dans les releases.
* **Abita4Rhino** : version d'Abita sous forme de plugin pour Grasshopper, pour 
    Rhino. Cette version s'appuie sur le code source en python2 d'`AbitaPy`.

Pour plus de détails sur chaque projet, veuillez consulter les fichiers
`README.md` présents dans le dossier de chaque projet.


## Objectif du projet

À partir d'une liste d'**éléments** définis par l'utilisateur et représentants
un logement sous contraintes, le programme doit répartir ces éléments en 
**lots**, où chaque lot représente soit un appartement de type T1, T2, T3, 
etc..., soit un espace commun, en garantissant que tous les appartements soient
reliés à une entrée ou une sortie du logement.

Pour une configuration d'éléments donnés, le programme se charge de trouver
différentes combinaisons possibles de lot, puis de les évaluer afin de ne
conserver que les plus pertienntes.

## Auteurs

Ce projet a été réalisé par 
[Alexandre BOULANGER](https://github.com/Krotho),
[Alexis DELAGE](https://github.com/hydrielax),
[Anne-Sophie JOURLIN](https://github.com/Melpemonia),
[Lénaëlle LE ROY](https://github.com/LenaelleLR) et 
[Louis PAUTRAT](https://github.com/LouisPaut), 
étudiants à l'École Centrale de Nantes en option Informatique (2021-2022).
